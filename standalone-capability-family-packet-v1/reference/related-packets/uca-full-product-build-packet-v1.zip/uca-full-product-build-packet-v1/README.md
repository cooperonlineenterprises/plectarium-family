# Universal Code Audit — Full Product Build Packet v1

**Packet status:** `ESTABLISHED / ACCEPTED project authority`  
**Packet version:** `1.0.0`  
**Generated:** `2026-08-31`  
**Purpose:** repository-ready Product Constitution, executable specification, verification contract, and AI-team build substrate for Universal Code Audit.

This directory is intended to become the initial authoritative context in the root of the Universal Code Audit repository. It is not a prototype implementation and it is not merely a design summary. It defines what UCA is, the contracts that implementations must obey, the evidence required to claim capabilities, and the authority model under which human and AI contributors work.

## Product position

> **Universal Code Audit is an independent, harness-agnostic, production-grade code-audit and repository-intelligence capability. It produces evidence, findings, interpretations, limitations, and recommendations. It does not possess authority over the repository or project. Its findings never authorize changes.**

A compliant UCA implementation remains useful when no agent harness is present, Octon Mini is absent, MCP is absent, AI interpretation is disabled, and network access is denied.

## Authority hierarchy

```text
Product Charter
      ↓
Architectural Invariants
      ↓
Normative Specifications / Schemas
      ↓
Accepted ADRs
      ↓
Capability Matrix / Release Criteria
      ↓
Workstream Plans
      ↓
Individual Task Instructions
      ↓
Agent implementation choices
```

When a lower-level instruction conflicts with a higher-level authority, the conflict **MUST** be surfaced. It **MUST NOT** be resolved by silently weakening the higher-level authority.

## Start here

1. Read [`CHARTER.md`](CHARTER.md).
2. Read [`spec/invariants.md`](spec/invariants.md).
3. Read [`ARCHITECTURE.md`](ARCHITECTURE.md).
4. Read the normative contracts relevant to the assigned subsystem.
5. Read [`agent/BUILD-DIRECTIVE.md`](agent/BUILD-DIRECTIVE.md) and the assigned task packet.
6. Run `python scripts/validate-packet.py` before relying on this packet.

## Normative language

The terms **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** are used in the RFC 2119 / RFC 8174 sense when written in uppercase. They are binding only where the surrounding document is classified as normative.

## Document classes

- **Normative:** defines required product semantics or compatibility commitments.
- **Governance:** defines authority, decision, build, or release process.
- **Reference architecture:** describes a recommended design that may be changed through accepted ADRs while preserving normative contracts.
- **Historical:** preserves conversation, research, and prior reasoning; it is not current authority.
- **Machine-readable normative:** JSON Schemas, YAML capability definitions, dependency graphs, and task metadata that implementations and validation tooling may consume.

The packet manifest identifies the class of every file.

## Development philosophy

UCA is not being developed as a deliberately tiny conventional MVP. The project will build the full-capability product in dependency order:

```text
design the real product architecture
        ↓
stabilize foundational contracts
        ↓
establish a Minimum Complete Architecture
        ↓
rapidly build major capabilities in parallel
        ↓
continuously integrate and verify
        ↓
production hardening
        ↓
mature UCA v1
```

The Minimum Complete Architecture is an integration checkpoint, not the product ambition. AI materially lowers implementation cost, but AI-generated breadth **MUST NOT** outrun the team's ability to understand, verify, maintain, and govern the resulting architecture.

## Package contents

- Product charter and architectural constitution.
- Normative lifecycle, evidence, confidence, completion, finding, reduction, security, interface, and bundle specifications.
- JSON Schema 2020-12 contracts for foundational entities.
- Capability-depth matrix and release gates.
- Accepted decisions and architectural decision records.
- AI-team authority, workstreams, dependency graph, task contract, and initial work packets.
- Canonical `uca-audit` and `uca-simplify` Agent Skills.
- Evaluation specification, test catalog, and claim-to-proof matrix.
- Octon Mini external-provider integration boundary.
- Research, licensing, source, and conversation provenance.
- Packet integrity validator and checksums.

## Product implementation is intentionally absent

This packet does not contain the UCA engine. It contains only the architecture and specification substrate required to build it coherently. The first implementation task is not to improvise new product meaning; it is to validate this authority set, open explicit architecture questions where needed, and then implement against these contracts.
