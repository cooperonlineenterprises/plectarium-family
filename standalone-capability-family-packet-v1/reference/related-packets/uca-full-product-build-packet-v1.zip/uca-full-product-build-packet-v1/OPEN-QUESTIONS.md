# Open Questions

**Authority:** Governance register  
**Status:** `OPEN QUESTION` entries only

These questions are genuinely unresolved. They are not placeholders. Work may proceed only as stated for each item.

## OQ-001 — UCA repository license

**Why open:** The conversation established licensing research requirements but did not select UCA’s own license.  
**Decision affected:** public contribution, adapter ecosystem, commercial embedding, patent terms.  
**Evidence needed:** legal/business goals, desired copyleft/permissive posture, contributor strategy.  
**Decision owner:** Product Owner with legal review.  
**May implementation proceed:** Yes, but no public release or third-party code incorporation should occur until selected.

## OQ-002 — Exact supported platform matrix for production v1

**Why open:** Linux, macOS, and Windows are desired, but minimum OS and architecture versions are not fixed.  
**Decision affected:** process isolation, filesystem behavior, release artifacts, CI cost.  
**Evidence needed:** target-user telemetry or explicit business requirements; process-runner prototypes.  
**Decision owner:** Architecture/Integration Lead and Release Owner.  
**May implementation proceed:** Yes, using Linux x86_64, Linux ARM64, macOS ARM64, and Windows x86_64 as provisional targets.

## OQ-003 — Minimum supported Git behavior and non-Git subjects

**Why open:** UCA must support repositories, but archive/filesystem audits may also be valuable.  
**Decision affected:** repository identity schema and comparison semantics.  
**Evidence needed:** initial user workflows and prototype complexity.  
**Decision owner:** Repository Intelligence Lead.  
**May implementation proceed:** Yes. Git working trees are the required v1 path; archive/filesystem subjects remain an extension point.

## OQ-004 — Exact priority-band thresholds and ordinal weights

**Why open:** The transparent formula is accepted, but constants are not empirically calibrated.  
**Decision affected:** default ordering and gate recommendations.  
**Evidence needed:** real-project finding review, remediation yield, reviewer burden.  
**Decision owner:** Evidence/Finding Lead with Evaluation Lead.  
**May implementation proceed:** Yes, with versioned provisional policy and all inputs visible.

## OQ-005 — OCI runtime requirement for Octon Mini provider execution

**Why open:** OCI is preferred for high assurance, but universal developer availability and profiler compatibility vary.  
**Decision affected:** provider manifest, native fallback, installation burden.  
**Evidence needed:** Octon Mini environment requirements and cross-platform provider prototype.  
**Decision owner:** Octon Mini Architecture Owner and UCA Security Lead.  
**May implementation proceed:** Yes. Contract supports `local_process` and `oci_image`; projects may require OCI.

## OQ-006 — First stable external adapter set beyond SARIF/SBOM importers

**Why open:** Semgrep, OSV, and Syft are strong candidates, but release support burden must be proven.  
**Decision affected:** production-v1 capability matrix and toolboxes.  
**Evidence needed:** adapter conformance results, version volatility, installation weight, license review.  
**Decision owner:** Adapter Lead and Release Owner.  
**May implementation proceed:** Yes, as preview adapters until promotion criteria are met.

## OQ-007 — Remote AI provider support in production v1

**Why open:** AI is optional and valuable, but privacy, retention, cost, reproducibility, and provider volatility remain material.  
**Decision affected:** semantic capability depth and credentials/network policy.  
**Evidence needed:** local-provider baseline, measured incremental value, privacy review.  
**Decision owner:** Semantic Analysis Lead, Security Lead, Product Owner.  
**May implementation proceed:** Deterministic UCA proceeds. Remote AI remains deferred unless explicitly accepted.

## OQ-008 — Public HTTP/hosted service timing

**Why open:** The architecture should permit it, but local product value must be established first.  
**Decision affected:** job store, tenancy, identity, object storage, operational scope.  
**Evidence needed:** sustained local adoption, demand for centralized execution, security/business case.  
**Decision owner:** Product Owner and Architecture Lead.  
**May implementation proceed:** Local abstractions may preserve future substitution; no service implementation is required for v1.
