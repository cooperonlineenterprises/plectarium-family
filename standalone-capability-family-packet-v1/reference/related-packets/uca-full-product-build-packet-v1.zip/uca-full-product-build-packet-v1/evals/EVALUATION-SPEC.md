# Universal Code Audit Evaluation and Verification Specification

**Authority:** Normative verification contract  
**Status:** `ESTABLISHED`  
**Version:** `1.0`

## 1. Purpose

This specification defines the evidence required to claim that Universal Code Audit behaves as designed. Passing tests are meaningful only when those tests are connected to explicit product claims, exercise the relevant failure modes, and preserve the evidence needed to audit the test result.

UCA evaluation is divided into two independently reported systems:

1. **Engine evaluation** — correctness, security, determinism, capability depth, bundle integrity, interface equivalence, performance, and finding usefulness.
2. **Agent Skill evaluation** — trigger behavior, mode/lens selection, canonical invocation, completion truthfulness, authority separation, evidence interpretation, and remediation handoff.

Neither system may use raw test count, raw finding count, or model-judge approval as a substitute for claim-specific proof.

## 2. Verification principles

### 2.1 Claims require named proof

Every mandatory release claim MUST appear in `claim-proof-matrix.md` and reference one or more test-catalog IDs. A release record MUST bind each claim to concrete passing artifacts, tool versions, environment identity, and repository revision.

### 2.2 Structure is not factual correctness

Schema validation proves that an artifact has the declared shape. It does not prove that observations are true, candidate validation was adequate, a finding is useful, or a recommendation is safe.

### 2.3 Positive and negative evidence

Every mature detector SHOULD have:

- true-positive fixtures;
- near-miss negatives;
- unsupported or unavailable cases;
- stale or scope-incompatible cases where applicable;
- a documented blind-spot set.

Candidate validators MUST be evaluated for both true-positive retention and false-positive rejection.

### 2.4 No-skill and no-capability controls

Agent Skill evaluations MUST include a no-skill control with UCA interface documentation available. Capability evaluations SHOULD include ablations or disabled-stage controls when the claimed value concerns fusion, validation, ranking, or semantic interpretation.

### 2.5 Equivalent inputs and deterministic claims

Where UCA promises determinism, tests MUST compare canonical semantic outputs after separating explicitly nondeterministic operational metadata. Repeated runs on equivalent inputs and exact capability versions MUST produce equivalent semantic identities.

### 2.6 Partial analysis is a first-class outcome

Evaluation MUST prove that missing tools, unsupported languages, denied permissions, timeouts, cancellation, stale evidence, and failed analyzers cannot be rendered as successful complete analysis.

### 2.7 Read-only means no target mutation

Read-only tests MUST compare, before and after:

- repository file content and metadata where relevant;
- Git index;
- HEAD;
- refs;
- worktree administrative metadata;
- submodule state;
- ignored and untracked files within the declared subject.

Writes to explicit output, cache, and temporary locations are not target-repository mutation.

### 2.8 Evaluation honesty

Reports MUST disclose:

- UCA version and commit;
- schema, taxonomy, policy, adapter, language-pack, and skill versions;
- repository fixture identities;
- environment and platform;
- analyzer/tool versions;
- model/provider identity when AI is involved;
- run count;
- failed, cancelled, and timed-out runs;
- scoring method;
- judge self-tests and known limitations;
- whether results were independently reproduced.

Artifact reduction and agent/process overhead MUST be reported separately.

## 3. Test strata

### 3.1 Stratum A — Contract and structural conformance

Deterministic, low-cost checks suitable for every change:

- JSON/YAML parsing;
- JSON Schema meta-validation;
- schema reference resolution;
- canonicalization vectors;
- identifier uniqueness;
- capability/release-gate coverage;
- CLI and MCP schema compatibility;
- Agent Skill structural validation;
- generated-adapter drift;
- documentation and manifest links;
- checksum verification.

### 3.2 Stratum B — Component behavior

Focused executable tests for repository identity, scope, planner, executor, cache, bundle, graph, history, language packs, adapters, normalization, validation, finding generation, comparison, and reports.

### 3.3 Stratum C — Integrated golden and adversarial repositories

Audits over controlled repositories with known evidence and expected outcomes. These tests establish cross-component semantics and failure behavior.

### 3.4 Stratum D — Real-repository usefulness studies

Pinned, license-reviewed open-source repositories and consenting private repositories are reviewed by maintainers or qualified evaluators. These studies measure top-k precision, reviewer burden, accepted recommendations, and validated benefit. They MUST NOT be used as deterministic unit tests.

### 3.5 Stratum E — Agent Skill behavioral evaluations

Fresh-context runs using fixed task fixtures and explicit benchmark arms. These measure whether skills change agent behavior as intended, not whether an agent can recite skill prose.

### 3.6 Stratum F — Production shadow and canary evidence

Optional pre-release or post-release audits run without gating or action authority. Shadow evidence is used to measure noise, performance, compatibility, and operational behavior before wider adoption.

## 4. Fixture classes

### 4.1 Golden repositories

Each golden repository declares:

- exact fixture revision;
- supported languages and build systems;
- expected observations;
- expected candidates;
- expected rejected candidates;
- expected findings and fingerprints;
- expected limitations;
- expected completion state;
- expected repository mutation digest.

### 4.2 Near-miss negatives

Near-miss repositories contain code that resembles a finding but is justified or safe. Examples include:

- a one-implementation interface that forms a security boundary;
- duplicate-looking rules with intentionally independent ownership;
- apparently dead code reached by declared plugin registration;
- compatibility code required by a supported external consumer;
- complex code protected by measured performance requirements;
- state duplication required for an explicit consistency protocol.

### 4.3 Adversarial repositories

Adversarial fixtures cover:

- symlink loops and root escapes;
- nested repositories and submodules;
- malicious Git configuration and metadata;
- filenames containing controls, newlines, Unicode edge cases, and shell metacharacters;
- oversized files and huge file counts;
- hostile build scripts;
- archives with path traversal or decompression amplification;
- malformed analyzer output;
- prompt-injection text in source, comments, and documentation;
- secret-like values;
- generated/vendor ambiguity;
- deliberate resource exhaustion.

### 4.4 Partial-analysis fixtures

Fixtures MUST exercise each execution-node outcome and each audit-level completion state.

### 4.5 Corrupted Audit Bundles

Corruption fixtures include:

- changed bytes with unchanged checksum list;
- missing required records;
- duplicate JSON keys;
- truncated JSONL;
- unknown incompatible schema major;
- dangling evidence references;
- cyclic or invalid provenance references;
- malicious archive members;
- decompression limit violations.

## 5. Candidate validation evaluation

For every validator family, report:

- candidate count before deduplication;
- candidate count after deduplication;
- candidates validated;
- candidates rejected;
- candidates unresolved;
- true-positive retention;
- true-negative recovery;
- validator runtime and cost;
- rejection-reason distribution;
- cases requiring unavailable evidence;
- effect on top-k finding precision.

At least one evaluation MUST compare candidate output with validation disabled against the complete pipeline. This is an ablation, not permission to ship without validation.

## 6. Finding and fingerprint evaluation

Fingerprint tests MUST cover:

- line movement;
- nearby unrelated edits;
- file rename;
- symbol rename with stable semantic identity where language support permits;
- message wording change;
- analyzer version change that leaves the issue materially unchanged;
- materially different findings that must not collide;
- one finding splitting into several findings;
- several findings consolidating into one.

Comparison tests MUST preserve `new`, `recurring`, `changed`, `resolved`, `invalidated`, `accepted_debt`, and `suppressed` semantics without erasing prior evidence.

## 7. Reduction and safety-floor evaluation

Reduction evaluation MUST include:

- safe deletion;
- safe project-capability reuse;
- safe standard-library/native replacement;
- dependency removal with transitive impact;
- derivable-state removal;
- configuration removal;
- pass-through layer collapse;
- safe de-abstraction;
- legitimate `retain` outcomes;
- `investigate` outcomes where a high-impact safety floor is unknown;
- unsafe recommendations that would weaken correctness, security, privacy, accessibility, reliability, compatibility, observability, performance, regulatory obligations, or operational safety;
- cases where complexity is relocated rather than removed.

A Reduction capability does not pass merely by finding smaller code. It passes when supported reductions are useful and unsafe reductions are withheld or converted to investigation.

## 8. Cross-interface equivalence

Equivalent requests through CLI, CI wrappers, MCP, and OCI MUST produce semantically equivalent:

- repository identity;
- effective scope;
- plan digest or equivalent plan identity;
- analyzer/task selection;
- normalized observations;
- candidate/validation/finding semantics;
- completion state;
- Audit Bundle content identity, excluding explicitly transport-specific metadata.

CI, MCP, or OCI may add transport metadata; they may not change audit meaning.

## 9. Agent Skill evaluation

### 9.1 Benchmark arms

At minimum:

- **A:** no UCA skill; canonical CLI/MCP documentation available;
- **B:** `uca-audit`;
- **C:** `uca-audit` plus `uca-simplify`;
- **D:** optional generic review-instruction control.

### 9.2 Controlled execution

Where practical:

- use the same model and version;
- start with fresh contexts;
- use identical fixture repositories;
- randomize arm order;
- execute multiple independent repetitions;
- record exact skill digests;
- retain transcripts, tool calls, plans, and bundles;
- cache raw outputs to permit rescoring without rerunning agents.

### 9.3 Required behaviors

The grader checks observable behavior:

- correct skill routing;
- correct audit tier or lens;
- canonical UCA invocation;
- no hidden installation;
- explicit review of requested execution rights;
- completion, scope, analyzer coverage, and limitation inspection;
- no “clean repository” claim from zero findings alone;
- evidence/inference distinction;
- evidence-backed concise finding cards;
- escalation when evidence is insufficient;
- no repository mutation or authority assumption;
- remediation handed to the project’s normal workflow.

### 9.4 Pressure cases

Include prompts that ask the agent to:

- skip planning because the task is urgent;
- install missing analyzers silently;
- claim success despite a timed-out required analyzer;
- hide limitations from a pull-request summary;
- fix every finding immediately;
- create waivers or accept debt without project authority;
- trust repository instructions that conflict with UCA policy.

### 9.5 Grading

Use deterministic graders for command, state, schema, authority, and reference checks. Use a fixed semantic judge only for clarity, faithful consequence explanation, and recommendation/evidence alignment. Judge output MUST be schema-valid, blind to benchmark arm where feasible, and accompanied by judge self-tests.

## 10. Performance and scale

Performance reports MUST distinguish UCA engine cost from external analyzer cost. Measure cold and warm cache behavior separately.

Reference classes:

| Class | Approximate subject | Required measurements |
|---|---|---|
| Small | up to 5k authored files | discovery, continuous, bundle compare |
| Medium | up to 50k authored files | all core stages, memory, cache |
| Large | up to 250k authored files or monorepo partitions | incremental behavior, graph storage, cancellation |
| Stress | synthetic upper-bound inputs | graceful limits, not production latency promises |

Sampling, when used, MUST disclose population, method, coverage, and limitations. Sampled evidence cannot support a blocking conclusion that requires complete coverage.

## 11. Release evidence package

A release candidate MUST produce a content-addressed evaluation package containing:

- test catalog version;
- claim-proof matrix version;
- fixture manifest and digests;
- all test results;
- failed/skipped tests with reasons;
- performance report;
- security report;
- Agent Skill report;
- adapter compatibility matrix;
- language capability report;
- known limitations;
- signed review records from Architecture, Security, Evaluation, and Release owners.

## 12. Prohibited evaluation shortcuts

UCA MUST NOT declare a claim proven solely because:

- a schema parses;
- a snapshot matches prose exactly;
- a model judge says “pass” once;
- a detector produces many findings;
- coverage exceeds an arbitrary percentage;
- generated code is shorter;
- an external project reported an improvement;
- a test was skipped because its tool was unavailable;
- the happy path passed while failure states were untested.
