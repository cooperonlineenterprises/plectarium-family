# Claim–Proof Matrix

**Authority:** Normative release evidence index  
**Status:** `ESTABLISHED`

A mandatory UCA v1 claim is satisfied only when the named test-catalog records have passing, content-addressed evidence under the release candidate. `Planned` means that this build packet defines the proof obligation; it does not claim the UCA implementation already passes it.

## Product-wide claims

| Claim ID | Mandatory claim | Minimum proof | Test catalog IDs | Release state |
|---|---|---|---|---|
| CLAIM-PRODUCT-001 | UCA operates without Octon Mini, MCP, AI, hosted service, or network access | Standalone clean-room install and local audit | SYS-STANDALONE-001, SYS-OFFLINE-001 | Planned |
| CLAIM-PRODUCT-002 | All public interfaces use one authoritative engine semantics | Cross-interface semantic equivalence on identical request | XIF-EQUIV-001 | Planned |
| CLAIM-AUTH-001 | Findings and recommendations grant no mutation or project authority | Authority-pressure skill tests and interface permission tests | AUTH-NONAUTH-001, SKILL-AUTH-001 | Planned |
| CLAIM-READONLY-001 | Default audits do not mutate the target repository or Git state | Before/after repository and Git digests | SEC-READONLY-001 | Planned |
| CLAIM-NET-001 | Network access is denied by default | Network-canary test in native and OCI modes | SEC-NETWORK-001 | Planned |
| CLAIM-INSTALL-001 | UCA never silently installs analyzers or dependencies | Missing-tool tests and process observation | SEC-NOINSTALL-001 | Planned |
| CLAIM-COMPLETION-001 | Unavailable, failed, denied, timed-out, unsupported, stale, and partial states remain truthful | Completion-state matrix and all projections | COMPLETE-MATRIX-001, XIF-COMPLETION-001 | Planned |
| CLAIM-AI-001 | AI evidence cannot masquerade as deterministic evidence or independently gate by default | Schema, fusion, report, CI, and skill tests | AI-CLASS-001, AI-GATE-001 | Planned |
| CLAIM-REDUCTION-001 | Reduction cannot bypass applicable safety floors | Positive, negative, retain, and investigate fixtures | REDUCE-FLOOR-001 | Planned |
| CLAIM-BUNDLE-001 | Audit Bundles are verifiable and corruption-detecting | Round trip, corruption, reference, and archive tests | BUNDLE-INTEGRITY-001, BUNDLE-CORRUPT-001 | Planned |
| CLAIM-SKILL-001 | Agent Skills orchestrate UCA rather than reimplement it | Structural and behavioral skill evaluation | SKILL-STRUCT-001, SKILL-BEHAVIOR-001 | Planned |
| CLAIM-SUPPLY-001 | Production release artifacts carry checksums, SBOM, provenance, and signatures | Release artifact verification | SUPPLY-RELEASE-001 | Planned |

## Capability release gates

The following table is generated from `spec/capability-matrix.yaml`. Every capability gate MUST have a corresponding catalog record and passing release artifact.

<!-- CAPABILITY_GATE_TABLE_START -->
| Capability ID | V1 target depth | Release gate | Test catalog IDs |
|---|---|---|---|
| `repo.identity` | `deep` | `CP-IDENTITY-001` | `CAP-IDENTITY-001` |
| `repo.scope` | `deep` | `CP-SCOPE-001` | `CAP-SCOPE-001` |
| `repo.discovery` | `useful` | `CP-DISCOVERY-001` | `CAP-DISCOVERY-001` |
| `audit.capability-resolution` | `deep` | `CP-PLAN-001` | `CAP-PLAN-001` |
| `audit.planning` | `deep` | `CP-PLAN-002` | `CAP-PLAN-002` |
| `audit.execution` | `deep` | `CP-EXEC-001` | `CAP-EXEC-001` |
| `audit.cache` | `useful` | `CP-CACHE-001` | `CAP-CACHE-001` |
| `evidence.raw` | `deep` | `CP-EVIDENCE-001` | `CAP-EVIDENCE-001` |
| `evidence.normalization` | `deep` | `CP-EVIDENCE-002` | `CAP-EVIDENCE-002` |
| `evidence.graph` | `deep` | `CP-EVIDENCE-003` | `CAP-EVIDENCE-003` |
| `candidate.generation` | `useful` | `CP-CANDIDATE-001` | `CAP-CANDIDATE-001` |
| `candidate.validation` | `deep` | `CP-CANDIDATE-002` | `CAP-CANDIDATE-002` |
| `finding.generation` | `deep` | `CP-FINDING-001` | `CAP-FINDING-001` |
| `finding.comparison` | `deep` | `CP-COMPARE-001` | `CAP-COMPARE-001` |
| `finding.priority` | `useful` | `CP-PRIORITY-001` | `CAP-PRIORITY-001` |
| `bundle.write-read` | `deep` | `CP-BUNDLE-001` | `CAP-BUNDLE-001` |
| `report.projections` | `useful` | `CP-REPORT-001` | `CAP-REPORT-001` |
| `history.churn` | `deep` | `CP-HISTORY-001` | `CAP-HISTORY-001` |
| `history.cochange` | `useful` | `CP-HISTORY-002` | `CAP-HISTORY-002` |
| `history.ownership` | `useful` | `CP-HISTORY-003` | `CAP-HISTORY-003` |
| `history.reverts-defects` | `basic` | `CP-HISTORY-004` | `CAP-HISTORY-004` |
| `structure.file-module-graph` | `deep` | `CP-GRAPH-001` | `CAP-GRAPH-001` |
| `structure.symbol-graph` | `useful` | `CP-GRAPH-002` | `CAP-GRAPH-002` |
| `structure.call-type-dataflow` | `basic` | `CP-GRAPH-003` | `CAP-GRAPH-003` |
| `structure.cycles-centrality` | `deep` | `CP-GRAPH-004` | `CAP-GRAPH-004` |
| `structure.complexity` | `useful` | `CP-STRUCT-001` | `CAP-STRUCT-001` |
| `structure.hotspots` | `deep` | `CP-HOTSPOT-001` | `CAP-HOTSPOT-001` |
| `duplication.exact` | `deep` | `CP-DUP-001` | `CAP-DUP-001` |
| `duplication.near` | `useful` | `CP-DUP-002` | `CAP-DUP-002` |
| `duplication.semantic` | `preview` | `CP-DUP-003` | `CAP-DUP-003` |
| `architecture.rules` | `deep` | `CP-ARCH-001` | `CAP-ARCH-001` |
| `architecture.drift` | `useful` | `CP-ARCH-002` | `CAP-ARCH-002` |
| `deadweight.reachability` | `useful` | `CP-DEAD-001` | `CAP-DEAD-001` |
| `dependency.inventory` | `deep` | `CP-DEP-001` | `CAP-DEP-001` |
| `dependency.vulnerability` | `useful` | `CP-DEP-002` | `CAP-DEP-002` |
| `dependency.lifecycle` | `useful` | `CP-DEP-003` | `CAP-DEP-003` |
| `testing.coverage` | `deep` | `CP-TEST-001` | `CAP-TEST-001` |
| `testing.mutation` | `useful` | `CP-TEST-002` | `CAP-TEST-002` |
| `testing.flakiness-cost` | `useful` | `CP-TEST-003` | `CAP-TEST-003` |
| `security.sast-import` | `useful` | `CP-SEC-001` | `CAP-SEC-001` |
| `reliability.failure-paths` | `useful` | `CP-REL-001` | `CAP-REL-001` |
| `state.ownership-flow` | `basic` | `CP-STATE-001` | `CAP-STATE-001` |
| `api.domain-model` | `basic` | `CP-API-001` | `CAP-API-001` |
| `runtime.profile` | `useful` | `CP-RUNTIME-001` | `CAP-RUNTIME-001` |
| `runtime.trace-query` | `useful` | `CP-RUNTIME-002` | `CAP-RUNTIME-002` |
| `investigation.race-fuzz-fault` | `preview` | `CP-INV-001` | `CAP-INV-001` |
| `reduction.lens` | `deep` | `CP-REDUCE-001` | `CAP-REDUCE-001` |
| `debt.reconsideration` | `useful` | `CP-DEBT-001` | `CAP-DEBT-001` |
| `semantic.ai` | `preview` | `CP-AI-001` | `CAP-AI-001` |
| `context.projection` | `useful` | `CP-CONTEXT-001` | `CAP-CONTEXT-001` |
| `interface.cli` | `deep` | `CP-CLI-001` | `CAP-CLI-001` |
| `interface.ci` | `deep` | `CP-CI-001` | `CAP-CI-001` |
| `interface.mcp` | `deep` | `CP-MCP-001` | `CAP-M001` |
| `distribution.oci` | `deep` | `CP-OCI-001` | `CAP-OCI-001` |
| `interface.agent-skills` | `deep` | `CP-SKILL-001` | `CAP-SKILL-001` |
| `integration.external-provider` | `useful` | `CP-PROVIDER-001` | `CAP-PROVIDER-001` |
<!-- CAPABILITY_GATE_TABLE_END -->

## Interpretation

- A capability gate may reference several executable tests and one human usefulness review.
- Preview capabilities MAY remain nonblocking if the capability matrix marks them as preview and release criteria do not require stable depth.
- A skipped required test is not passing evidence.
- A tool-unavailable test can pass only when it correctly produces the required explicit unavailable/partial semantics; it cannot prove the tool-backed capability itself.
