# Repository Identity and Scope

**Authority:** Normative  
**Status:** `ESTABLISHED`

## 1. Required question

Every audit **MUST** answer:

> **What exact repository state did this result describe?**

No observation or finding exists without a repository identity and scope.

## 2. Subject kinds

Initial UCA supports at least:

```text
git_worktree
git_commit
git_archive
filesystem_tree
```

`filesystem_tree` depth and production-v1 support remain subject to `OPEN-QUESTION-003`; schemas support the identity without implying full capability depth.

## 3. Git identity

For a Git subject, record as applicable:

- repository root canonical path or redacted locator;
- object format;
- HEAD/ref and commit ID;
- merge base or diff base;
- index identity;
- tracked modifications;
- staged modifications;
- untracked files included/excluded;
- deletions and renames;
- submodule identities and dirty states;
- nested repository boundaries;
- sparse checkout and partial clone state;
- relevant ignore policy;
- repository content-manifest digest.

A commit ID alone does not identify a dirty worktree.

## 4. Working-tree overlay

UCA creates a deterministic overlay manifest over the base commit/index including:

- path;
- status;
- content digest or deletion marker;
- executable/type metadata where material;
- classification;
- symlink target metadata without unsafe traversal.

Operational absolute paths **SHOULD** be separable from portable content identity.

## 5. Submodules and nested repositories

Each submodule/nested repository is one of:

```text
excluded
identity_only
analyzed_as_component
flattened_prohibited
```

UCA **MUST NOT** silently flatten boundaries. A parent audit records exact child identity and analysis relationship.

## 6. Scope model

Scope states:

- include patterns;
- exclude patterns;
- changed-against baseline;
- affected-entity expansion rules;
- generated/vendor/test/fixture/migration policy;
- sensitive paths;
- maximum file/byte/depth limits;
- language/subproject selectors;
- external mounted inputs;
- exclusions imposed by security policy;
- coverage population.

## 7. Classification

Files/entities may be classified as:

```text
authored
generated
vendored
third_party
test
fixture
migration
configuration
documentation
binary
build_output
sensitive
unknown
```

Classifications include producer/rule and confidence. Generated and vendored code are generally analyzed separately rather than mixed into authored metrics.

## 8. Ignored and untracked files

The request/config determines whether ignored and untracked content is eligible. UCA **MUST** state what was omitted. Sensitive ignored paths are excluded by default unless explicitly authorized.

## 9. Symlinks and special files

- Paths **MUST** be resolved relative to the repository root without escaping it.
- Untrusted symlinks **MUST NOT** cause reads outside approved roots.
- Device files, FIFOs, sockets, and other non-regular files are excluded by default.
- Symlink identity and target text may be recorded without dereferencing.

## 10. Binary and large files

Binary/large files may receive metadata-only analysis. Skipped content records size, digest where feasible, classification, and limitation. Decompression is not implicit.

## 11. Scope changes and comparison

Two audits are comparison-compatible only if repository lineage, relevant scope populations, classifications, and methodology can be mapped. Otherwise comparison reports partial compatibility or incompatibility.

## 12. External inputs

SBOMs, profiles, traces, specifications, and human evidence supplied outside the repository receive independent material identities and are linked to the subject; they do not become repository content implicitly.
