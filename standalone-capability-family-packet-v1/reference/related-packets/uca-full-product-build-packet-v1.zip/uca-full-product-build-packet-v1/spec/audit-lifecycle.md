# Canonical Audit Lifecycle

**Authority:** Normative  
**Status:** `ESTABLISHED`

## Governing flow

```mermaid
flowchart TD
    R[AuditRequest] --> V{Request validation}
    V -->|invalid or prohibited| RF[Refusal / failed completion]
    V --> RI[RepositoryIdentity + Scope]
    RI --> D[Discovery]
    D --> C[Capability resolution]
    C --> P[AuditPlan]
    P --> E[Execution DAG]
    E --> AR[AnalyzerRun + RawEvidence]
    AR --> N[NormalizedObservation]
    N --> G[EvidenceGraph]
    G --> CA[Candidate generation]
    CA --> CV[Validation + attempted refutation]
    CV -->|rejected| RC[RejectedCandidate + reason + evidence]
    CV -->|unresolved| UI[Investigation-required record]
    CV -->|survives| F[Finding]
    F --> CP[Consequence + Recommendation + Confidence + Priority]
    RC --> B[Audit Bundle]
    UI --> B
    CP --> B
    B --> I[Inspect / Compare / Report]
```

## Lifecycle phases

### 1. Receive

The engine accepts an `audit-request` document or equivalent typed input. The request states desired behavior and permission ceilings; it does not select undeclared tools or grant authority outside the request.

### 2. Validate

UCA validates:

- schema and version;
- subject/root safety;
- requested tier and lens;
- scope syntax;
- permission compatibility with host policy;
- output and cache paths;
- resource budgets;
- baseline references;
- required versus optional capabilities.

Invalid or prohibited requests produce a refusal or failed completion. UCA **MUST NOT** silently narrow a material request and call it complete; any safe narrowing is explicit in the effective scope.

### 3. Identify repository and scope

UCA creates repository and scope records before analysis. The identity includes revision and working-tree overlay where applicable. Scope classifies authored, generated, vendored, test, fixture, migration, binary, ignored, sensitive, and excluded content.

### 4. Discover

Discovery detects languages, frameworks, manifests, lockfiles, build systems, test systems, public surfaces, entry points, generated outputs, subprojects, and candidate native tools. Discovery produces observations and declared uncertainty; it does not execute project code by default.

### 5. Resolve capabilities

The engine compares requested capabilities, tier defaults, language-pack depth, adapter registry, installed/trusted tool availability, permissions, and budgets. Every capability receives an applicability and availability result.

### 6. Plan

Planning creates a deterministic DAG where possible. Every execution node declares:

- capability and producer;
- exact version/digest;
- inputs and scope;
- dependencies;
- direct argv or built-in operation;
- environment allowlist;
- permission requirements;
- sandbox requirement;
- resource/output limits;
- cache key inputs;
- required/optional status;
- continuation policy;
- expected output/normalizer.

The plan has a canonical digest. A caller may require explicit acceptance of that digest before execution.

### 7. Execute

The scheduler runs nodes subject to dependency and resource constraints. Node outcomes are `succeeded`, `failed`, `unavailable`, `skipped`, `timed_out`, or `cancelled`. Independent optional nodes may continue after isolated failure.

### 8. Capture raw evidence

Exact output bytes or content-addressed references are recorded with media type, producer, sensitivity, retention policy, and digest. Tool output is untrusted until parsed and validated.

### 9. Normalize

Versioned normalizers convert raw outputs and built-in analysis results into UCA observations. Normalization **MUST NOT** erase producer identity, scope, limitations, or source locations.

### 10. Build evidence graph

The evidence graph represents support, contradiction, derivation, applicability, identity, and scope relationships. It permits traceability and targeted context projection.

### 11. Generate candidates

Deterministic violations may yield candidates with high initial strength. Heuristic, historical, semantic, and AI analyses may intentionally nominate permissive candidates. Candidate generation remains separate from validation.

### 12. Validate and attempt refutation

Applicable validators seek confirming and contradicting evidence, verify subject identity and scope, examine safety floors, and challenge plausible false-positive explanations. Outcomes are rejected, unresolved, or surviving.

### 13. Generate findings

Only surviving candidates or direct deterministic contract violations may become findings. The finding preserves evidence references, interpretation, consequence, recommendation, confidence vector, risk, validation strategy, lifecycle, priority inputs, and provenance.

### 14. Determine completion

Completion is derived from the request, plan, node outcomes, scope coverage, evidence freshness, and required-capability policy. Finding count is not an input to whether analysis was complete.

### 15. Finalize Audit Bundle

UCA atomically finalizes the canonical bundle, checks references and hashes, records completion, and emits projections. An interrupted bundle remains explicitly incomplete.

### 16. Inspect, compare, and report

Inspect and report operations read canonical bundle records. Comparison first verifies subject, scope, schema, taxonomy, and methodology compatibility before classifying changes.

## Audit state machine

```text
received
→ validated
→ identified
→ discovered
→ planned
→ executing
→ normalizing
→ validating_candidates
→ generating_findings
→ finalizing
→ complete | complete_with_limitations | partial | failed | cancelled
```

State transitions **MUST** be monotonic except for explicit resume from a persisted checkpoint. Resume **MUST** verify repository identity, plan digest, producer versions, and cache integrity.
