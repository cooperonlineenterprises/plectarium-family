# Canonical CLI Contract

**Authority:** Normative public interface  
**Status:** `ACCEPTED`

## 1. Role

The CLI is UCA's canonical local human and automation interface. It is a thin application surface over the authoritative engine, not a separate implementation.

## 2. Command hierarchy

```text
uca
├── discover
├── plan
├── audit
├── inspect
│   ├── finding
│   ├── candidate
│   ├── module
│   ├── entity
│   ├── hotspot
│   ├── graph
│   └── bundle
├── explain
├── compare
├── report
├── adapters
│   ├── list
│   ├── describe
│   └── probe
├── cache
│   ├── status
│   ├── verify
│   ├── prune
│   └── gc
├── schema
│   ├── list
│   ├── show
│   ├── validate
│   └── migrate
├── doctor
└── version
```

Command names may evolve through public-interface ADRs; semantics may not diverge from engine contracts.

## 3. Core examples

```bash
uca discover --repo . --format json

uca plan --repo . --tier continuous --output audit-plan.json

uca audit \
  --plan audit-plan.json \
  --accept-plan-digest sha256:... \
  --bundle-out ./uca-output

uca inspect finding FND-01J... --bundle ./uca-output --format json
uca compare ./baseline ./uca-output --format json
uca report ./uca-output --format html --output report.html
```

## 4. Request representation

Non-interactive automation **SHOULD** use a schema-valid `audit-request` document. CLI flags map to the same request fields. The effective request, configuration sources, and plan are preserved in the bundle.

## 5. Configuration precedence

```text
host-enforced security policy
→ explicit audit request
→ CLI flags within policy
→ repository uca.toml
→ user configuration
→ defaults
```

Lower-precedence sources may narrow access but may not enable a capability denied above.

## 6. Stdout and stderr

### Stdout

Only the selected primary output:

- human summary;
- JSON document;
- JSONL/NDJSON event stream;
- schema/report content;
- stable output path reference.

### Stderr

- progress;
- diagnostics;
- warnings;
- adapter logs when explicitly requested;
- refusal explanation.

Machine JSON mode **MUST NOT** be contaminated by progress text.

## 7. Output modes

```text
--format human
--format json
--format jsonl
--format markdown
--format sarif      where applicable
```

Progress:

```text
--progress auto
--progress human
--progress json
--progress none
```

JSON progress is NDJSON with versioned event types and no semantic result substitution.

## 8. Exit codes

The v1 accepted classes are:

| Code | Meaning |
|---:|---|
| `0` | Engine operation completed and configured gates passed |
| `10` | Audit completed, but one or more configured project gates failed |
| `20` | Audit completed partially beyond allowed completeness policy |
| `30` | Invalid arguments, request, configuration, or schema |
| `40` | Required capability/tool/language/environment unavailable |
| `50` | Trust, sandbox, access, or security refusal |
| `60` | Internal engine, bundle-integrity, or adapter-protocol failure |
| `70` | Cancelled or overall deadline exceeded |

A gate failure (`10`) is distinct from audit execution failure. Exit-code changes are public-interface changes.

## 9. Failure semantics

- Invalid input fails before analysis.
- Required unavailability produces `40` or `20` according to whether a partial bundle is valid under request policy.
- Optional unavailability may still produce `0` with `complete_with_limitations` when gates pass.
- A bundle finalized before a gate failure remains valid.
- Fatal integrity error produces `60`; UCA must not present the bundle as trusted.

## 10. Non-interactive behavior

Automation mode:

- never prompts;
- never installs or changes permissions;
- requires explicit plan acceptance when policy says so;
- writes only declared paths;
- emits stable machine formats;
- uses deterministic ordering where promised;
- supports cancellation/signals and atomic bundle finalization.

## 11. `doctor`

`uca doctor` diagnoses UCA version, platform, cache, schemas, registered adapters, underlying tool versions, sandbox/container availability, and configuration. It does not install or repair without a separately authorized external workflow.

## 12. `inspect` and `explain`

Inspection reads canonical bundle records and progressively discloses evidence. Explanation **MUST** distinguish observation from interpretation and state completion/scope limitations.

## 13. Security

Repository paths, request files, outputs, adapters, and baselines are untrusted inputs. CLI convenience flags do not bypass execution-security policy.
