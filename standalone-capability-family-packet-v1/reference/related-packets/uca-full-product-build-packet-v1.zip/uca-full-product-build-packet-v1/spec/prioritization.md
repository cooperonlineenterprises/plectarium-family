# Transparent Prioritization

**Authority:** Normative semantics / proposed calibration  
**Status:** `ACCEPTED` with calibration `OPEN QUESTION`

## 1. Purpose

Priority ranks decision-support work. It does not grant authority and is not an aggregate code-quality score.

## 2. Inputs

Expected benefit considers ordinal inputs such as:

```text
Impact
Breadth
Recurrence
StrategicLeverage
```

Delivery burden considers:

```text
Effort
MigrationRisk
RegressionRisk
Coordination
Rollout
```

Evidence confidence derives transparently from the confidence vector.

## 3. Reference relationship

A reference policy may use:

```text
ExpectedBenefit =
  Impact × Breadth × Recurrence × (1 + 0.25 × StrategicLeverage)

DeliveryBurden =
  Effort × (1
    + 0.25 × MigrationRisk
    + 0.25 × RegressionRisk
    + 0.15 × Coordination
    + 0.15 × Rollout)

PriorityIndex =
  ExpectedBenefit × EvidenceConfidence ÷ DeliveryBurden
```

These constants are not empirically calibrated product truth. The active policy **MUST** be versioned and its inputs preserved. Changing it requires ADR/evaluation.

## 4. Bands

```text
P0           active or imminent high-consequence evidence requiring urgent project attention
P1           confirmed broad or recurring risk/opportunity
P2           strong evidence suitable for planned work
P3           opportunistic improvement during adjacent work
INVESTIGATE  potentially material but insufficient/conflicting evidence
ACCEPTED     project-owned accepted-debt disposition
```

`P0` means high-priority evidence/recommendation. It does not authorize modification, merge blocking, or deployment action.

## 5. Hard constraints

- Active safety/security/data-integrity evidence cannot be offset by a low effort estimate.
- Unknown/violated high-impact safety floors force reject or `INVESTIGATE` for reduction.
- AI confidence alone cannot supply evidence confidence.
- Missing consequence/cost inputs may produce an ordinal recommendation without a numeric index.
- Every presented index includes policy version and component inputs.
- No repository-wide composite health score is required or preferred.

## 6. Tie breakers

When expected priority is similar, prefer work that is:

- reversible;
- easily validated;
- deletion/reduction oriented;
- located in active hotspots;
- prerequisite to strategic work;
- capable of improving several dimensions;
- low coordination burden.

## 7. Evaluation

Calibration should use actual maintainer judgments, remediation yield, validated benefit, false-positive burden, and delivery outcomes. `OPEN-QUESTION-004` governs initial constants/bands.
