# Canonical Terminology

**Authority:** Normative  
**Status:** `ESTABLISHED`

These terms have one canonical meaning across code, schemas, reports, skills, and integrations.

| Term | Definition |
|---|---|
| **Audit** | One bounded UCA analysis of an exact repository identity and scope under an immutable request and plan. |
| **Audit request** | The caller's desired tier, scope, capabilities, permissions, budgets, baseline, and outputs. It is not the execution plan. |
| **Audit plan** | The validated immutable DAG of analysis nodes, exact producers, permissions, dependencies, limits, cache inputs, and failure policy. |
| **Audit tier** | Continuous, Periodic, or Investigative operating profile. A tier selects defaults; it does not silently grant permissions. |
| **Lens** | A focused capability and reporting view, such as Reduction, over shared evidence. A lens is not a separate engine. |
| **Repository identity** | The exact subject of analysis: repository locator/type, revision, worktree overlay, submodule/nested-repository state, and content identity. |
| **Scope** | The included and excluded files, entities, revisions, generated/vendor/test classifications, and affected-set rules. |
| **Capability** | A named analysis or evidence-processing function with declared inputs, outputs, depth, permissions, limitations, and proof. |
| **Analyzer** | A producer that performs a specific analysis. It may be built into UCA or external. |
| **Adapter** | An explicit out-of-process or OCI integration that describes, probes, invokes, and normalizes an external analyzer. |
| **Analyzer run** | One execution attempt of a producer under an audit plan node, including outcome, identity, resources, and raw outputs. |
| **Raw evidence** | Exact or content-addressed analyzer output retained before UCA normalization. |
| **Observation** | A normalized, source-bound statement about a subject, including evidence class, scope, producer, assumptions, limitations, and confidence components. |
| **Evidence** | One or more observations or raw artifacts used to support, contradict, or bound a claim. Evidence is not authority. |
| **Evidence graph** | Nodes and edges connecting repositories, entities, runs, observations, candidates, validation outcomes, findings, and conflicts. |
| **Candidate** | A possible issue, opportunity, gap, or interpretation nominated for validation. It is not yet a finding. |
| **Validation** | Structured evaluation of a candidate against confirming, contradicting, applicability, scope, and safety evidence. |
| **Attempted refutation** | Deliberate search for evidence that invalidates, narrows, or weakens a candidate. |
| **Rejected candidate** | A candidate that did not survive validation, with preserved reason and evidence. |
| **Finding** | A validated decision-support record describing an observed condition, interpretation, consequences, recommendations, confidence, risk, and validation strategy. |
| **Interpretation** | The meaning inferred from observations. It must not be presented as direct observation. |
| **Consequence** | Why a finding matters in this repository across correctness, security, reliability, maintainability, performance, cost, or productivity. |
| **Recommendation** | A proposed response. It does not authorize work or claim remediation. |
| **Expected benefit** | The improvement anticipated if a recommendation is implemented and validated. |
| **Confidence** | A transparent vector describing evidence strength, detector precision, coverage, freshness, reproducibility, inference distance, independent sources, and conflicts. |
| **Priority** | A transparent recommendation band based on expected benefit, evidence confidence, and delivery burden. It is not authority. |
| **Waiver** | A scoped, owned, reasoned, expiring disposition that suppresses or accepts a finding without erasing it. |
| **Accepted debt** | A consciously retained finding or limitation with current ceiling, owner, review conditions, and reconsideration triggers. |
| **Reconsideration trigger** | An observable event or threshold that reopens accepted debt or a retained design for review. |
| **Completion** | Audit-level or node-level state describing what executed and whether the requested evidence was produced. |
| **Audit Bundle** | The durable canonical directory artifact containing request, plan, repository, scope, runs, observations, candidates, findings, completion, provenance, and projections. |
| **Baseline** | A prior compatible Audit Bundle or repository reference used for comparison or ratcheting. |
| **Comparison** | A compatibility-aware classification of findings/evidence as new, recurring, changed, resolved, stale, or incomparable. |
| **Reduction** | The UCA lens for safely removing or consolidating behavior, code, dependencies, state, configuration, surfaces, abstractions, layers, processes, or concepts. |
| **Safety floor** | The required behavior and non-reducible correctness, integrity, security, privacy, accessibility, reliability, compatibility, observability, performance, legal, and operational constraints applicable to a reduction. |
| **Justified complexity** | Complexity retained because evidence establishes a necessary responsibility or floor. |
| **Language pack** | Versioned language-specific discovery, syntax, semantic, graph, identity, and native-tool integration capability. |
| **Provider** | A separately versioned external capability implementation exposed through a declared interface. UCA may be a provider to a harness. |
| **Agent Skill** | Portable instructions teaching an agent when and how to invoke and interpret UCA. It is not an analyzer or engine. |
| **External capability** | A standalone product that remains useful outside the consuming harness and exposes explicit plan, execution, completion, and result contracts. |
| **Authority** | Permission to cause effects or make project decisions. UCA has no repository or project authority by default. |
| **Gate** | A project-configured policy that maps specific UCA completion/evidence conditions to CI or workflow outcomes. The project owns the gate. |
| **Content identity** | A digest over canonical semantic inputs or artifacts. It differs from an operational run ID. |
| **Projection** | A presentation or interoperability view, such as SARIF or a finding card, derived from canonical bundle records. |

## Prohibited ambiguities

- “Issue” **SHOULD NOT** replace candidate or finding when lifecycle distinction matters.
- “Clean” **MUST NOT** mean zero findings without a complete compatible scope statement.
- “Passed” **MUST NOT** describe an unavailable or skipped check.
- “Confidence score” **SHOULD NOT** imply calibrated probability unless the producer documents calibration.
- “Supported language” **MUST** be accompanied by capability depth.
- “Fix” **MUST NOT** mean a recommendation; remediation is external to UCA.
