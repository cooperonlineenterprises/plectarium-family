# Evidence Model

**Authority:** Normative  
**Status:** `ESTABLISHED`

## 1. Purpose

The evidence model preserves what was observed, by whom, under what scope and conditions, with what limits, and how that observation participates in candidates and findings. Evidence is descriptive and non-authorizing.

## 2. Evidence classes

| Class | Meaning | Typical reproducibility | Can establish | Cannot establish alone |
|---|---|---|---|---|
| `deterministic_static` | UCA-owned deterministic analysis of repository bytes/structure | Deterministic for declared inputs | Syntax, exact relationships, metrics within detector model | Runtime reachability, intent, external consumers |
| `deterministic_contract` | Direct violation or satisfaction of an explicit rule/contract | Deterministic | Rule conformance within modeled scope | Whether the rule itself is appropriate |
| `external_tool_deterministic` | Deterministic or declared-stable output from an identified external tool | Tool/environment dependent | Tool-specific analysis result | More than the tool's extraction model supports |
| `heuristic_static` | Reproducible heuristic or approximate inference | Usually reproducible | Candidate likelihood, ranking, suspicious structure | Confirmed defect or required remediation |
| `historical` | Observation derived from version-control, incidents, ownership, or change records | Deterministic for history/filter inputs | Churn, co-change, concentration, recurrence | Causality by itself |
| `runtime_observed` | Measurement from a declared workload/environment/time window | Workload/environment dependent | Behavior observed under those conditions | Universal behavior outside the sample |
| `imported_human` | Human-supplied judgment, requirement, decision, or evidence | Source dependent | Declared intent, policy, domain context | Machine-verifiable truth unless corroborated |
| `ai_interpretation` | Structured model-derived interpretation over a bounded context | Model dependent | Semantic candidate or explanation | Deterministic fact, authority, exhaustive analysis |
| `derived_fusion` | UCA-derived relationship or interpretation based on referenced observations | Rule/algorithm dependent | Combined support, conflict, ranking | Independent new observation |
| `absence_or_unavailability` | Missing capability, denied permission, no matching evidence, or unavailable producer | Deterministic as a state | Analysis limitation or evidence gap | Proof that the underlying issue is absent |

## 3. Observation envelope

Every observation **MUST** include:

- schema version and stable observation ID;
- evidence class and observation type;
- producer identity/version/digest;
- repository and subject identity;
- scope reference;
- observed/produced time and valid revision;
- typed payload;
- raw-evidence references where applicable;
- assumptions;
- limitations and blind spots;
- confidence vector or reference;
- sensitivity and retention classification;
- provenance.

## 4. Scope and coverage

Evidence **MUST** state the population it covers. Coverage may be complete, partial, sampled, unknown, or not applicable. Sampling **MUST** record population, method, sample size, and restrictions on blocking conclusions.

“No match” means only that the producer found no match in its analyzed scope. It **MUST NOT** be normalized as universal absence.

## 5. Freshness

Evidence freshness includes:

- repository revision validity;
- configuration and rule-set identity;
- producer/tool version;
- runtime workload and environment;
- external database snapshot identity;
- production time;
- reuse basis.

Reused evidence retains its original production identity. Cache reuse does not make evidence newly produced.

## 6. Provenance

Every evidence item **MUST** be traceable to:

- subject(s);
- material inputs;
- producing operation;
- producer/tool/model identity;
- configuration, rules, queries, and normalizer;
- parent evidence for derived items;
- bundle and audit run.

## 7. Evidence relationships

The evidence graph supports at least:

```text
supports
contradicts
narrows
invalidates
validates
derived_from
observes
applies_to
produced_by
covers
excludes
supersedes
reuses
```

Relationship identity and producer are explicit. A relationship may itself carry confidence and limitations.

## 8. Conflicts

Conflicting observations **MUST** remain present. A fusion rule may decide disposition only when it records:

- the conflicting evidence IDs;
- precedence or resolution rule;
- rationale;
- residual uncertainty;
- effect on candidate/finding.

Example: a static dead-code candidate may be rejected when current runtime evidence observes execution, while retaining the limitation that the workload is incomplete.

## 9. Raw and normalized separation

Raw evidence is preserved or content-addressed independently of normalized observations. Normalizers **MUST** be versioned. A normalization change may create different observations from the same raw evidence and must be visible in comparison/provenance.

## 10. Sensitivity

Evidence and bundle artifacts classify sensitivity, such as:

```text
public
project_internal
project_confidential
secret_redacted
restricted
```

Secret values **MUST NOT** be stored in ordinary findings or reports. A secret detector reports a redacted fingerprint and location, while raw secret-bearing source remains subject to repository access policy.

## 11. Evidence and authority

Evidence may support a CI gate configured by the project or a decision made by a human/harness. Evidence itself grants no authority.
