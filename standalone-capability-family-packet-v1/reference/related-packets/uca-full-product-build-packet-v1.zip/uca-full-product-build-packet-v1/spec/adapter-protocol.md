# External Analyzer Adapter Protocol

**Authority:** Normative  
**Status:** `ACCEPTED`  
**Protocol family:** `uca.adapter.v1`

## 1. Boundary

External analyzers **SHOULD** run out of process or in OCI containers. UCA core **MUST NOT** load arbitrary third-party dynamic libraries into its process.

```text
UCA planner
  → trusted adapter manifest
  → static capability selection
  → probe exact implementation/tool
  → constrained run
  → untrusted raw output
  → schema validation
  → versioned normalization
  → UCA observations
```

## 2. Adapter commands

A local-process adapter implements direct-argv commands:

```text
uca-adapter-<id> describe --output <file>
uca-adapter-<id> probe --request <file> --output <file>
uca-adapter-<id> run --request <file> --output-dir <dir>
```

`describe` returns static metadata and **MUST NOT** access the repository or network. Static discovery preferably reads a signed/hashed manifest without execution.

`probe` verifies adapter/tool availability, exact version, environment, and permission needs. It **MUST NOT** install or update anything.

`run` performs one planned capability operation and writes only to task output/temp paths.

## 3. Manifest requirements

An adapter manifest includes:

- schema/protocol version;
- adapter ID, version, digest, implementation kind, executable/image identity;
- underlying tool name, version constraint, identity probe, optional binary digest;
- capabilities and maturity;
- language/framework applicability;
- accepted inputs and produced output schemas/formats;
- repository, Git, project-execution, process, network, credential, and write requirements;
- sandbox minimum;
- resource class/default limits;
- cache safety and key inputs;
- normalizer identity;
- known limitations;
- license/distribution class;
- maintainer/owner.

## 4. Capability discovery

UCA selects only adapters explicitly registered and trusted by host/user policy. Filesystem presence is not trust. States include:

```text
unregistered
registered_untrusted
trusted_disabled
enabled
deprecated
removed
```

Availability is separate:

```text
trusted + missing tool = unavailable
installed + untrusted = prohibited
trusted + incompatible version = incompatible
trusted + capability absent = unsupported
```

## 5. Invocation safety

- UCA passes direct argv; shell interpolation is prohibited by default.
- Environment is deny-by-default and allowlisted.
- HOME, credentials, proxy variables, Git hooks, pagers, and external diff/filter commands are removed unless explicitly needed.
- The engine owns process groups, timeouts, cancellation, PID limits, stdout/stderr capture, and output byte limits.
- Repository mounts/access follow the plan.
- Network follows explicit endpoint/purpose policy.
- Project code execution is separately declared.

## 6. Result contract

An adapter run returns a machine-readable result containing:

- run ID and request digest;
- adapter/tool identities;
- start/end/resource data;
- outcome and exit-code mapping;
- output artifact declarations with media types/digests;
- scope coverage;
- warnings/limitations;
- raw-evidence references;
- normalization readiness;
- redaction report.

All adapter output is untrusted. UCA validates JSON depth, counts, strings, paths, sizes, references, and schemas before use.

## 7. Tool unavailability

Missing, incompatible, denied, or unsupported tooling yields an explicit capability/node state and limitation. UCA may provide documentation guidance but **MUST NOT**:

- invoke a package manager;
- download a binary;
- accept a repository-provided executable without trust;
- mutate lockfiles;
- enable network;
- treat the check as passed.

## 8. Offline behavior

Adapters declare whether they can operate:

```text
offline
with_cached_database
network_required
```

External advisory database identity and freshness are part of provenance/cache keys. Network-required optional analysis may be unavailable in local-first operation without invalidating unrelated capabilities.

## 9. Cache behavior

An adapter declares:

```text
safe
safe_with_conditions
unsupported
```

Cache keys include repository/scope identity, adapter and tool identity, rule/query/config digest, external database identity, material environment, and normalizer version. Tool output cannot choose its own cache identity.

## 10. Normalization

Normalizers are UCA-owned or separately trusted, versioned components. They preserve original producer identities and never strengthen evidence class beyond the source and validation support.

## 11. Adapter categories

Initial protocol must support:

- generic SARIF import;
- CycloneDX and SPDX import;
- coverage/test-result import;
- Semgrep, CodeQL, OSV, Syft, Trivy;
- compiler/linter/native-indexer integration;
- test and mutation tools;
- profiler/trace/query-plan import;
- race detectors, fuzzers, property testing;
- commercial/static-analysis exports.

The v1 stable adapter set remains an open release decision.

## 12. Testing and maturity

Every stable adapter requires:

- manifest/schema validation;
- mock-tool contract tests;
- golden output fixtures;
- oldest/newest supported tool version jobs;
- invalid/oversized/malicious output tests;
- timeout/cancellation/process-tree tests;
- network-denied and write-boundary tests;
- redaction tests;
- cache-key tests;
- cross-platform tests where claimed;
- named owner;
- published limitations.

Only high-precision, stable, evaluated adapters may support default blocking gates.
