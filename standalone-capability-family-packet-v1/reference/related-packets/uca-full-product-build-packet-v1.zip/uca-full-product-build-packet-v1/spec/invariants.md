# Architectural Invariants

**Authority:** Normative  
**Status:** `ESTABLISHED`  
**Version:** `1.0`

These invariants define the architectural boundary of Universal Code Audit. Implementations, work plans, adapters, interfaces, and Agent Skills **MUST** comply. A change requires an accepted ADR that identifies migration and compatibility consequences. Implementation convenience is not sufficient reason to violate an invariant.

## INV-001 — Product independence

**Rule.** UCA **MUST** be independently usable. UCA core **MUST NOT** depend on Octon Mini or any agent harness. UCA **MUST NOT** require MCP, a hosted service, AI, or network access for core local operation.

**Rationale.** Harness neutrality preserves portability and prevents a consumer from becoming the product runtime.

**Compliant examples**

- A developer installs the UCA binary and runs `uca audit --repo .` with no agent present.
- Octon Mini invokes an exact UCA OCI image but UCA remains unaware of Octon state.
- An MCP server translates requests into calls to the same UCA engine library.

**Violations**

- UCA core reads Octon task files to determine audit semantics.
- Audit execution fails because an agent runtime is absent.
- The CLI delegates analysis to a prompt-only agent implementation.

## INV-002 — One authoritative engine

**Rule.** CLI, CI, MCP, OCI/container, and future HTTP surfaces **MUST** use the same authoritative engine semantics. They **MUST NOT** independently implement discovery, planning, normalization, candidate validation, finding generation, confidence, priority, or completion.

**Rationale.** Multiple engines create incompatible meanings and non-reproducible results.

**Compliant examples**

- The CLI and MCP server call shared application services and emit semantically equivalent bundles.
- A GitHub Action installs and invokes the CLI rather than translating tool output itself.

**Violations**

- The MCP server performs its own prompt-based audit.
- CI maps analyzer severities to UCA priorities independently of the engine.

## INV-003 — Evidence, not authority

**Rule.** UCA outputs are evidence, interpretations, findings, limitations, and recommendations. They **MUST NOT** authorize repository mutation, policy change, deployment, publication, issue creation, dependency installation, or external action.

**Rationale.** Audit truth and project authority are different concerns.

**Compliant examples**

- A finding recommends removing an abstraction; a separate project decision authorizes work.
- A CI policy blocks a merge because the project explicitly configured that gate; the finding did not grant the policy.

**Violations**

- `P0` automatically permits an agent to edit or push code.
- A finding creates an issue without separate authorization.

## INV-004 — Read-only by default

**Rule.** UCA **MUST** be read-only with respect to the target repository by default. Writes are limited to explicit output, cache, and temporary locations. Repository, Git index, refs, and worktree metadata writes are prohibited unless a future, separately governed product surface is explicitly created.

**Rationale.** Auditing must not alter the subject it is observing.

**Compliant examples**

- Project builds execute in a copied sandbox.
- A container mounts `/workspace` read-only and `/out`, `/cache`, `/tmp` writable.

**Violations**

- An analyzer formats source files in place.
- UCA creates `.uca/` in the repository without explicit output configuration.

## INV-005 — No hidden capabilities

**Rule.** UCA **MUST NOT** silently install tools, enable network, execute project code, mutate files or Git state, acquire credentials, widen scope, or increase permissions.

**Rationale.** Hidden effects undermine reproducibility, consent, and security.

**Compliant examples**

- Missing Semgrep produces `unavailable` plus setup guidance.
- A coverage task declares the exact project command, sandbox, and write paths in the plan.

**Violations**

- UCA invokes a package manager to install a missing analyzer.
- A project configuration file can override a host network denial.

## INV-006 — Explicit execution rights

**Rule.** Project execution, external process execution, network access, credentials, repository access, and writable paths **MUST** be declared in the audit plan and inspectable before execution.

**Rationale.** An audit plan is both an analysis plan and an effect declaration.

**Compliant examples**

- A mutation-test task declares `project_execution: required` and `network: denied`.
- An OSV database refresh declares allowed endpoints and cache effects.

**Violations**

- An adapter invokes arbitrary scripts discovered in the repository.
- An analyzer follows network links without a declared endpoint policy.

## INV-007 — Truthful completion

**Rule.** Unavailable analyzers, denied permissions, timeouts, failures, unsupported languages, stale evidence, and incomplete scope **MUST NOT** be represented as successful complete analysis. No findings is not equivalent to a clean repository.

**Rationale.** Completeness is an evidence claim, not a pleasant presentation choice.

**Compliant examples**

- An audit returns `complete_with_limitations` when optional runtime evidence was not requested.
- A required analyzer timeout returns `partial` or `failed` according to plan policy.

**Violations**

- A missing security scanner is treated as zero security findings.
- A changed-code audit claims the repository is clean.

## INV-008 — Distinguishable evidence classes

**Rule.** Deterministic, heuristic, historical, runtime, imported-human, AI, derived, and absence/unavailability evidence **MUST** remain distinguishable through normalization, fusion, findings, reports, and interfaces.

**Rationale.** Different evidence classes support different claims and reproducibility guarantees.

**Compliant examples**

- A compiler-confirmed edge and a tree-sitter-inferred edge use different resolution metadata.
- AI interpretation cites observations and remains `ai_interpretation`.

**Violations**

- A model assertion is stored as deterministic static evidence.
- Runtime evidence from one workload is presented as universal behavior.

## INV-009 — Determinism where promised

**Rule.** When UCA labels an operation deterministic, equivalent repository bytes, scope, configuration, capability versions, rule/query sets, and material environment inputs **MUST** yield semantically equivalent results. Operational timestamps and run IDs **MUST** be separable from content identity.

**Rationale.** Reproducibility is necessary for comparison, cache correctness, and trust.

**Compliant examples**

- Canonical JSON and stable ordering are used for content IDs.
- A model-dependent result is not labeled deterministic.

**Violations**

- Filesystem iteration order changes finding identity.
- A cache key omits analyzer version.

## INV-010 — AI is optional and subordinate

**Rule.** AI **MUST NOT** become the canonical engine, only source of findings, authorization system, project executor, or mutation mechanism. AI-only findings **MUST NOT** independently fail a pull request by default.

**Rationale.** UCA must remain local-first, reproducible where promised, and useful without a model provider.

**Compliant examples**

- AI proposes semantic-duplication candidates from a bounded context manifest.
- A local model and remote model produce separately identified evidence.

**Violations**

- `uca audit` cannot operate without an API key.
- A model installs tools or expands its own repository scope.

## INV-011 — Conflicts remain visible

**Rule.** Supporting and contradicting evidence **MUST** remain visible. Fusion **MUST NOT** silently average contradictory evidence into false certainty.

**Rationale.** Disagreement is often the most important audit result.

**Compliant examples**

- Static reachability says unused while runtime traces show execution; the conflict is recorded and the dead-code candidate is rejected.
- Two semantic analyses disagree and the finding becomes `needs_investigation`.

**Violations**

- Conflicting signals are reduced to a medium confidence score with no explanation.

## INV-012 — Recommendation and remediation are distinct

**Rule.** A recommendation **MUST** describe a possible change and validation strategy. It **MUST NOT** perform, authorize, or imply completion of that change.

**Rationale.** Advice, project decision, implementation, and validation are separate lifecycles.

## INV-013 — Prefer safe simplification

**Rule.** UCA **SHOULD** identify deletion, reuse, consolidation, de-abstraction, dependency removal, state/configuration reduction, and layer collapse when evidence supports them. The applicable safety floor **MUST** be evaluated first.

**Rationale.** Less system to own is often the highest-leverage improvement, but necessary complexity is not waste.

## INV-014 — No metric gaming

**Rule.** UCA **MUST NOT** make raw finding count, LOC removed, complexity score, coverage percentage, or a single opaque health score its governing quality measure.

**Rationale.** Metrics are evidence, not objectives. Optimizing the measure can make the codebase worse.

## INV-015 — External tools are untrusted, bounded evidence producers

**Rule.** Adapter executables and analyzer outputs **MUST** be treated as untrusted across a process or OCI boundary. UCA **MUST** validate identity, permissions, limits, output schemas, and provenance.

## INV-016 — Scope and repository identity precede conclusions

**Rule.** Every observation and finding **MUST** be bound to a repository identity and scope. UCA **MUST** be able to state what repository state the result describes.

## INV-017 — Suppression does not erase evidence

**Rule.** Waivers and accepted debt **MUST** alter disposition, not delete the finding or source evidence. They **MUST** be scoped, owned, reasoned, and time- or trigger-bounded.

## INV-018 — The skill is not the product

**Rule.** Agent Skills **MUST** teach agents when and how to invoke and interpret UCA. They **MUST NOT** duplicate substantial engine logic or claim prompt-only review is equivalent to UCA.

## Changing an invariant

A proposed change **MUST**:

1. create an ADR marked `PROPOSED`;
2. identify the invariant and motivating evidence;
3. assess product-boundary, security, compatibility, schema, bundle, interface, and migration consequences;
4. specify transition and rollback;
5. update every affected normative artifact and test;
6. receive approval from the Architecture / Integration Lead and designated human product authority;
7. be accepted before dependent implementation proceeds.

An agent encountering an inconvenient invariant **MUST** surface the conflict. It **MUST NOT** weaken the invariant locally.
