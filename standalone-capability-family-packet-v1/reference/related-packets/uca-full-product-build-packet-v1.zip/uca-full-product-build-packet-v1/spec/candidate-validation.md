# Candidate Validation and Attempted Refutation

**Authority:** Normative  
**Status:** `ESTABLISHED`

## 1. Fundamental distinction

A **candidate** is a possible condition nominated for evaluation. A **finding** is a candidate that survived applicable validation and attempted refutation, or a direct deterministic contract violation whose applicability is established.

Heuristic or AI suspicion **MUST NOT** automatically become a finding.

## 2. Lifecycle

```mermaid
stateDiagram-v2
    [*] --> generated
    generated --> deduplicated
    deduplicated --> validating
    validating --> refuting
    refuting --> rejected
    refuting --> unresolved
    refuting --> survives
    survives --> finding_generated
    rejected --> [*]
    unresolved --> [*]
    finding_generated --> [*]
```

Canonical candidate states:

```text
generated
deduplicated
validating
refuting
rejected
unresolved
survives
promoted
```

## 3. Candidate generation

Candidate producers may be permissive when the cost of validation is acceptable. Every candidate **MUST** identify:

- candidate taxonomy/type;
- subject and scope;
- generating producer;
- source observations;
- proposed interpretation;
- validation requirements;
- expected false-positive explanations;
- requested safety-floor checks where relevant;
- estimated validation cost class.

## 4. Deduplication before validation

UCA **SHOULD** consolidate candidates that represent the same root condition before expensive validation. Deduplication **MUST** preserve:

- all contributing producer/evidence references;
- differing interpretations;
- original candidate IDs;
- merge rationale;
- material differences that prevent merging.

## 5. Validation

Validation checks applicability and support, including as relevant:

- repository/revision identity;
- subject still exists;
- scope coverage;
- rule applicability;
- caller/consumer paths;
- framework or platform protections;
- generated/vendor/test classification;
- architecture intent;
- history and known decisions;
- runtime evidence;
- external consumers;
- safety floors;
- counterexamples;
- alternative explanations.

## 6. Attempted refutation

The validator **MUST** actively seek evidence that would invalidate or narrow the candidate. It must not merely restate supporting evidence.

Examples:

- For dead code, search reflection, configuration, public exports, plugin roots, generated registrations, and runtime traces.
- For duplication, test whether concepts are independently owned or expected to diverge.
- For a performance candidate, determine whether the path is executed frequently and whether profiling confirms cost.
- For a security candidate, trace source-to-sink and protective transformations.
- For de-abstraction, test for independent security, test, runtime, ownership, compatibility, or policy boundaries.

## 7. Outcomes

### Rejected

The candidate is invalid, inapplicable, adequately protected, already superseded, or unsupported. A rejected-candidate record **MUST** preserve reason, validator, evidence, scope, and future invalidation conditions.

### Unresolved

Evidence is insufficient or conflicting. The record **MUST** name missing evidence and recommended investigation. It may yield an `investigation_required` or `evidence_gap` finding, but not the original asserted defect.

### Survives

The candidate has adequate support and applicable refutations did not invalidate it. It may be promoted to a finding.

## 8. Independent verification

High-impact heuristic or AI candidates **SHOULD** require an independent verifier when practical. Independence may mean:

- different deterministic method;
- distinct external analyzer;
- targeted runtime experiment;
- human review;
- separately bounded model/provider;
- reproduction test.

Multiple prompts to the same model over the same context are not automatically independent.

## 9. Unavailable validation

If required validation cannot run, the candidate **MUST NOT** be silently promoted. The outcome is unresolved, and completion/confidence must reflect the missing capability.

## 10. Evaluation value

Rejected candidates are first-class evaluation evidence. They support:

- detector precision analysis;
- recurring-noise suppression;
- validation-rule improvement;
- model/provider evaluation;
- cache reuse where the rejection remains applicable.

## 11. Structure versus factual correctness

Schema-valid candidate or finding output proves only structure. Factual correctness requires evidence validation.
