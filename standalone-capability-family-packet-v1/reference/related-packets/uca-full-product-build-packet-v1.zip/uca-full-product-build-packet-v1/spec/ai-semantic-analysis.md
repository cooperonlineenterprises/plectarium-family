# Optional AI and Semantic Interpretation

**Authority:** Normative boundary / reference architecture  
**Status:** `ACCEPTED`

## 1. Position

AI is an optional structured interpretation provider over bounded, cited evidence. It is not UCA's canonical audit engine, an autonomous coding agent, a repository authority, or a substitute for deterministic/runtime evidence.

## 2. Candidate uses

- semantic duplication;
- responsibility analysis;
- conceptual complexity/vocabulary;
- domain modeling;
- architecture interpretation;
- obsolete compatibility machinery;
- unnecessary abstraction/de-abstraction;
- stale documentation;
- terminology inconsistency;
- API usability;
- recommendation alternatives.

## 3. Provider classes

```text
local_process
local_server
remote_api
organization_managed
```

Provider identity includes model, model version/digest where possible, client/adapter, prompt/template digest, parameters, network/data-retention policy, and structured output schema.

## 4. Context construction

Inputs are selected through a deterministic context manifest where practical. The manifest records exact source ranges, entities, tests, architecture documents, evidence, byte/token budget, exclusions, and digests.

Whole-repository upload is not the default. Sensitive paths and secrets are excluded unless explicitly authorized and appropriate.

## 5. Security and prompt injection

Repository content is untrusted quoted data. The semantic provider:

- receives no repository mutation tools;
- cannot expand its own scope;
- cannot enable network;
- cannot follow repository links;
- cannot install tools;
- cannot create waivers/tasks;
- cannot mark its output deterministic;
- must return schema-valid structured output;
- must cite evidence/source IDs for material claims.

Uncited claims are rejected or marked unsupported.

## 6. Evidence semantics

AI output is `ai_interpretation`. Model self-confidence is metadata only. UCA confidence derives from cited evidence, context coverage, provider evaluation, independent corroboration, and conflicts.

An AI candidate follows the ordinary candidate-validation/refutation lifecycle. AI-only findings are advisory by default and do not independently fail CI.

## 7. Remote providers

Remote use requires explicit authorization for:

- network destinations;
- data classes and source scope;
- credentials;
- provider retention/training policy;
- jurisdiction/residency where relevant;
- output retention;
- cost/budget.

Local/offline UCA remains fully functional without remote providers.

## 8. Reproducibility

Model-dependent evidence records parameters and exact context, but UCA does not promise deterministic reproduction unless a provider can establish it. Multiple samples from the same model are not automatically independent evidence.

## 9. Human review

High-impact AI-derived recommendations require human or independent evidence review before project adoption. UCA records `human_review_required` where policy requires.

## 10. Production-v1 scope

Whether remote AI providers are included in production v1 is an open question. Schemas and boundaries may be implemented before release inclusion.
