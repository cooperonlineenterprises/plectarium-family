# Non-Reducible Safety Floor

**Authority:** Normative  
**Status:** `ACCEPTED`

## Purpose

The safety floor prevents simplification analysis from mistaking essential complexity for waste. Each reduction candidate evaluates only applicable floor dimensions, but high-impact unknowns block a direct reduction recommendation.

## Floor dimensions

| Dimension | Required question |
|---|---|
| Required behavior | Is the capability required by users, product policy, contract, supported workflow, or project decision? |
| Correctness | Are domain invariants, valid/invalid outcomes, ordering, error behavior, and edge cases preserved? |
| Data integrity | Could removal create loss, duplication, corruption, partial state, or unsafe migration? |
| Security | Does the mechanism enforce validation, authentication, authorization, trust separation, least privilege, or isolation? |
| Privacy | Does it enforce minimization, retention, consent, redaction, residency, or separation? |
| Accessibility | Does it preserve supported accessible behavior and assistive interaction? |
| Reliability | Does it provide timeout, retry control, cancellation, cleanup, rollback, backpressure, recovery, or fault containment? |
| Compatibility | Do supported consumers, versions, protocols, platforms, or migration paths still require it? |
| Observability | Would removal materially reduce diagnosis, auditability, incident response, or required telemetry? |
| Performance | Would the replacement violate a measured budget or restore a known bottleneck? |
| Legal/regulatory | Is it required for compliance, licensing, evidence retention, or audit obligations? |
| Operational safety | Does it support rollout, rollback, deployment sequencing, resource isolation, or emergency response? |

## Status values

```text
verified_preserved
strongly_indicated_preserved
unknown
violated
not_applicable
```

- `verified_preserved`: direct tests, contracts, measurements, or authoritative evidence establish preservation.
- `strongly_indicated_preserved`: meaningful evidence supports preservation, with explicit validation still required.
- `unknown`: material evidence is missing or conflicting.
- `violated`: proposed reduction would weaken or remove the floor.
- `not_applicable`: the dimension does not apply, with an applicability basis when material.

## Decision rules

```text
violated
→ reject the reduction candidate; do not recommend it

unknown + high impact
→ investigation_required

strongly_indicated_preserved
→ recommendation may proceed with explicit validation and risk

verified_preserved
→ strongest basis, still subject to implementation validation
```

A candidate may have mixed statuses. UCA **MUST** present material unknowns and violations; it **MUST NOT** average them into a single favorable score.

## Evidence ownership

The floor check references ordinary UCA observations and may require additional validators. AI interpretation may identify a potential floor but cannot independently mark high-impact security, correctness, or compatibility preservation as verified.

## Scope

A floor status is bound to:

- exact reduction candidate;
- subject and repository revision;
- affected consumers and platforms;
- proposed replacement;
- validation environment;
- evidence freshness.

A floor established for an internal call path does not automatically cover external library consumers.

## Examples

### Apparent wrapper

A one-method interface with one implementation appears removable. Validation discovers it is the only authorization boundary for third-party plugins. Security status is `violated`; candidate rejected and complexity recorded as justified.

### Native replacement

A custom path parser appears replaceable with the standard library. Error semantics and supported runtime versions match; tests and benchmarks establish preservation. Correctness and compatibility are `verified_preserved`; recommendation survives.

### Dead compatibility path

No internal callers exist, but external consumer inventory is unavailable. Compatibility is `unknown` and high impact; outcome is investigate, not delete.

### Performance-critical implementation

An unrolled loop appears harder to read. A benchmark shows the straightforward loop violates a release budget. Performance would be `violated`; current complexity is justified unless a different replacement meets the budget.
