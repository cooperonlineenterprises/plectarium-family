# Completion Semantics

**Authority:** Normative  
**Status:** `ESTABLISHED`

## 1. Principle

Completion states describe execution and evidence coverage. They are not derived from finding count.

> **No findings in analyzed scope is not equivalent to “the codebase is clean.”**

> **An unavailable check is never equivalent to a passed check.**

## 2. Audit-level states

### `complete`

All required capabilities completed successfully; effective scope equals the accepted scope; evidence is compatible/current under policy; no material undeclared limitation prevents the requested claim.

A complete focused lens is complete only for that lens, not for a full-spectrum audit.

### `complete_with_limitations`

All required capabilities completed according to policy, but declared optional omissions, known blind spots, sampling, unsupported non-required areas, or workload limits materially qualify interpretation.

### `partial`

One or more required capabilities, required scope segments, or required evidence classes did not complete, but the bundle contains usable partial evidence.

### `failed`

The audit could not produce a trustworthy usable result for the request, such as failure to establish repository identity, invalid plan, bundle-integrity failure, or required execution-policy refusal.

### `cancelled`

The caller or host cancelled execution before completion. Produced evidence may be retained but the audit is not complete.

## 3. Execution-node states

```text
succeeded
failed
unavailable
skipped
timed_out
cancelled
```

- `succeeded`: declared operation completed and output passed protocol validation.
- `failed`: operation ran but failed or produced invalid output.
- `unavailable`: trusted compatible producer/tool/environment was not available.
- `skipped`: plan intentionally did not run the node, with a reason such as inapplicability or budget policy.
- `timed_out`: wall/resource deadline was exceeded.
- `cancelled`: cancellation interrupted the node.

A node may succeed while producing zero observations. That differs from unavailable or skipped.

## 4. Required distinctions

Completion records **MUST** distinguish:

| Condition | Required representation |
|---|---|
| No findings | Finding count zero plus actual completion state and scope |
| Analyzer unavailable | Node `unavailable`; limitation; required/optional effect |
| Analyzer intentionally disabled | Capability disabled by effective configuration; not “passed” |
| Denied permission | Node/refusal reason `permission_denied`; effect on completion |
| Failed analyzer | Node `failed`; captured diagnostics and provenance |
| Partial scope | Coverage record and `partial` or qualified state |
| Stale evidence | Freshness `stale`; completion policy effect |
| Missing runtime evidence | Explicit not-requested/unavailable state; no runtime conclusion |
| Timeout | Node `timed_out`; retained partial output only if validated |
| Unsupported language | Capability-depth/unavailable observation, not zero findings |
| External-tool absence | `unavailable`, never successful clean result |
| Corrupt bundle | `failed` integrity result; bundle must not be trusted |

## 5. Completion derivation

The completion engine evaluates:

```text
accepted request
+ effective scope
+ required/optional capability policy
+ plan node outcomes
+ coverage
+ freshness
+ evidence compatibility
+ integrity validation
+ declared limitations
```

Finding severity or count does not determine completion. A complete audit may have critical findings; an incomplete audit may have none.

## 6. Completion truth protocol for consumers

Before making an outcome claim, a consumer **MUST** inspect:

1. audit-level completion state;
2. repository identity and revision;
3. effective scope and coverage;
4. required-capability outcomes;
5. optional omissions and analyzer coverage;
6. limitations and blind spots;
7. freshness and baseline compatibility.

Truthful language:

- “The requested Continuous audit completed for the changed and affected scope.”
- “No findings were produced in the analyzed scope.”
- “The audit completed with limitations because runtime profiling was not requested.”
- “The audit is partial because the required TypeScript indexer timed out.”

Prohibited language absent extraordinary explicitly scoped proof:

- “The repository is clean.”
- “All security issues are resolved.”
- “The check passed” when it was unavailable, skipped, or denied.

## 7. Completion and CI exit behavior

The CLI exit code may separately represent:

- engine completion failure/partiality;
- configured gate failure due to findings;
- invalid request;
- unavailable required capability;
- security refusal;
- cancellation.

A gate failure does not mean the audit failed to complete. These dimensions remain separate.
