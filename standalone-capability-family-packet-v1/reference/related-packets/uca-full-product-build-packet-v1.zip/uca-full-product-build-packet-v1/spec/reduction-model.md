# Reduction / Simplification Model

**Authority:** Normative  
**Status:** `ACCEPTED`

## 1. Governing question

> **What behavior, code, dependencies, state, configuration, surfaces, abstractions, layers, processes, or concepts can this system safely stop carrying?**

Reduction is a first-class UCA lens over shared repository, history, graph, dependency, test, runtime, security, and semantic evidence. It is not code golf, automatic refactoring, or a separate audit engine.

## 2. Decision ladder

The ladder is evaluated in order after required behavior and safety floors are established:

```text
0. Establish required behavior, consumers, invariants, and safety floors.
1. Remove behavior that is no longer required.
2. Delete unreachable, obsolete, duplicated, or superseded implementation.
3. Reuse an existing project capability.
4. Prefer a standard-library/runtime capability where appropriate.
5. Prefer a native platform capability where appropriate.
6. Reuse an already-adopted dependency when it lowers total ownership.
7. Consolidate duplicated knowledge, rules, schemas, transformations, or configuration.
8. Remove dependencies made unnecessary.
9. Eliminate unnecessary, duplicated, or derivable state.
10. Eliminate unnecessary configuration.
11. Collapse pass-through layers lacking independent responsibility.
12. De-abstract concepts whose separation creates cost without independent value.
13. Simplify the remaining implementation.
14. Retain the current design when complexity is justified.
15. Add new abstraction, dependency, configuration, or infrastructure only when evidence warrants it.
```

The first valid outcome may be `retain` or `investigate`; UCA is not required to recommend a cut.

## 3. Compositional taxonomy

### Action

```text
remove
reuse
consolidate
collapse
simplify
retain
investigate
```

### Target

```text
behavior
code
dependency
state
configuration
api-surface
abstraction
layer
build-step
deployment-unit
compatibility
schema
rule
transformation
concept
```

### Replacement

```text
none
project-capability
standard-library
runtime
native-platform
already-adopted-dependency
```

Presentation labels such as `delete`, `use-stdlib`, `remove-dependency`, `remove-state`, `collapse-layer`, and `de-abstract` are derived projections, not the canonical ontology.

## 4. Reduction candidate requirements

Every candidate **MUST** identify:

- current behavior/responsibility;
- target and proposed action;
- requirement and consumer evidence;
- relevant history and ownership;
- proposed replacement or absence of replacement;
- applicable safety floors and current status;
- expected benefit vector;
- change/migration risk;
- validation requirements;
- uncertainty and missing evidence.

## 5. Typical evidence patterns

### Remove behavior

Requirement inventory, consumer inventory, compatibility policy, usage/traffic evidence where available, ownership/policy evidence, and removal validation.

### Dead code

Static reachability plus public/exported consumer, reflection, dynamic registration, configuration, generated wiring, and runtime uncertainty.

### Reuse existing project capability

Semantic equivalence, support contract, ownership, error semantics, performance implications, and change coupling.

### Standard-library/runtime/native replacement

Supported version/platform matrix, semantic compatibility, error and resource behavior, security properties, performance, and deployment consequences.

### Dependency removal

Direct and transitive imports/use, build/test/runtime/operational use, SBOM impact, security and license implications, artifact impact, and fallback behavior.

### State/configuration removal

Source of truth, derivability, writers/readers, consistency, migration, rollback, environment use, and default semantics.

### Layer collapse/de-abstraction

Caller topology, implementation count, pass-through ratio, and independent security, ownership, test, runtime, compatibility, policy, or deployment role.

### Compatibility removal

Consumer/traffic evidence, support policy, version window, migration status, fallback, and rollback.

## 6. Justified complexity

UCA **MUST** recognize complexity as justified when it carries a demonstrated responsibility such as:

- trust or authorization boundary;
- compatibility contract;
- runtime isolation;
- independent ownership/deployment;
- measured performance requirement;
- resilience or recovery;
- accessibility or regulatory requirement;
- meaningful domain invariant;
- proven variation.

A `retain` result is a valid positive audit outcome when evidence explains the role.

## 7. Benefit vector

Reduction value is descriptive and multidimensional:

```text
authored_files_removed
authored_lines_removed_estimate
dependencies_removed
transitive_dependencies_removed
public_symbols_removed
config_keys_removed
mutable_state_stores_removed
serialization_boundaries_removed
layers_removed
build_steps_removed
deployment_units_removed
duplicated_rules_consolidated
concepts_removed
change_surface_reduction
```

These dimensions **MUST NOT** be collapsed into an opaque simplicity score. Raw LOC is secondary.

## 8. Priority

Reduction findings use the ordinary transparent priority model. Expected removable weight may increase benefit, but unknown or violated safety floors force `INVESTIGATE` or rejection.

## 9. Validation

A reduction recommendation **MUST** specify proof such as:

- behavior/contract equivalence;
- public API and external-consumer check;
- tests including failure paths;
- performance budget;
- security and authorization verification;
- migration and rollback;
- bundle or artifact size comparison;
- dependency/SBOM comparison;
- state/data reconciliation;
- post-change audit comparison.

## 10. No mutation

The Reduction lens produces evidence and recommendations. Initial UCA **MUST NOT** apply the reduction.
