# Language-Agnostic Core and Language Packs

**Authority:** Normative boundary / reference architecture  
**Status:** `ACCEPTED`

## 1. Principle

UCA remains cross-language by separating universal repository/evidence capabilities from language-specific semantic depth. It **MUST NOT** collapse to a lowest-common-denominator claim or imply equal depth.

## 2. Universal core

The universal core may own:

- repository identity, path safety, file/content inventory;
- Git history, churn, ownership, reverts, co-change;
- repository/project topology;
- exact text/token duplication where language-independent;
- manifest/lockfile discovery;
- generic file/module graph primitives;
- imported SARIF/SBOM/coverage/test/profile evidence;
- evidence normalization/fusion, candidates, findings, comparison, bundles;
- generic reporting and prioritization.

## 3. Language-pack responsibilities

A language pack may provide:

- file and subproject detection;
- generated/vendor conventions;
- grammar/parser bindings;
- symbol and semantic entity identity;
- definitions/references/imports;
- function/class/module metrics;
- type, call, and data-flow edges;
- entry points and reachability roots;
- public API/export semantics;
- native compiler/indexer/linter/test/coverage adapters;
- framework detection/knowledge;
- known blind spots and capability depth;
- conformance fixtures.

## 4. Syntax versus semantic evidence

Tree-sitter or similar parsing may provide broad tolerant syntax structure. Such edges are labeled parser-derived. Compiler, type-checker, language-server, bytecode, or native indexer semantics are preferred for stronger claims.

UCA **MUST NOT** represent approximate text/syntax references as compiler-resolved calls without validation.

## 5. Initial maturity direction

```text
Rust                  deep v1 support
Python                deep v1 support
TypeScript/JavaScript useful v1 support
Go                    useful v1 support
future languages      generic fallback or later packs
```

Depth is defined per capability matrix, not by a single support flag.

## 6. Generic fallback

Unsupported languages can still receive:

- identity/scope;
- file inventory/topology;
- history/hotspots/ownership/co-change;
- exact duplication;
- manifests/SBOM/dependency evidence;
- imported SARIF/coverage/test/profile evidence;
- structure and reduction candidates whose evidence is valid.

Completion and reports name missing semantic capabilities.

## 7. Framework packs

Framework knowledge may add entry points, dependency-injection edges, generated-code rules, routes, lifecycle methods, ORM relationships, and public-surface conventions. It is versioned, explicitly detected, disableable, bounded to a language/version, and separate from core identity.

## 8. Pack maturity

```text
experimental
preview
stable
gate_capable
```

Stable packs require capability fixtures, near-miss negatives, version matrix, owner, documented limitations, and cross-platform evidence where claimed. Gate-capable rules require high precision and stable identity.

## 9. Agent freedom

Internal parser/indexer/library choices are implementation decisions unless they affect evidence semantics, identity, compatibility, or permissions. Those changes require ADR review.
