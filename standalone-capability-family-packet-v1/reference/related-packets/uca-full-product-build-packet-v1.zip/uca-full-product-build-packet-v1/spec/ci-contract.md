# CI Integration Contract

**Authority:** Normative responsibility boundary  
**Status:** `ACCEPTED`

## 1. Ownership

### UCA owns

- repository/scope semantics after checkout;
- audit request/plan semantics;
- baseline compatibility and comparison;
- observations, candidates, findings, confidence, priority;
- gate evaluation according to explicit project policy;
- completion;
- Audit Bundle;
- SARIF/report projection;
- cache key identity and finding fingerprints.

### CI platform owns

- checkout and clone depth;
- credentials and permissions;
- job scheduling/matrix;
- runner/container isolation;
- persistent cache/artifact storage;
- SARIF/artifact upload;
- merge protection;
- notifications;
- secret management.

A CI wrapper **MUST NOT** reinterpret UCA findings independently.

## 2. Integration shape

A first-party CI integration should be a thin setup/invocation wrapper:

```text
checkout
→ install/verify exact UCA artifact
→ invoke uca audit
→ upload selected bundle/report/SARIF artifacts
→ let platform apply exit code / configured gate
```

The Action or wrapper must not reimplement discovery, planning, findings, priority, or comparison.

## 3. Pull-request audits

Inputs include:

- exact base/head/merge basis;
- checkout depth and history availability;
- changed-file set;
- UCA and config digest;
- baseline bundle/reference;
- trust context (same-repo or fork);
- permissions and cache class.

Missing history is not silently fetched unless network and remote/refspec are authorized. It produces a limitation or required failure.

## 4. Ratchet behavior

Recommended policy:

```text
legacy findings          visible, not automatically blocking
new deterministic issues gateable when policy selects them
recurring findings       advisory unless worsened or selected
heuristic/AI findings    advisory
resolved findings        recorded
required analysis absent fail closed or partial according to project policy
```

“Tightening is silent, loosening is loud”: lowering a gate, suppressing a checker, weakening a test, or widening a waiver **SHOULD** be explicitly visible and reviewable.

## 5. Fork pull requests

Defaults:

- no secrets;
- read-only token;
- no trusted-cache writes;
- no remote/private analyzers;
- no unsafe project execution;
- no artifact publication containing sensitive raw evidence;
- sanitized SARIF/summary only.

Privileged follow-up jobs require explicit trusted maintainer action and must not execute untrusted fork code with secrets.

## 6. Artifacts

- Full bundle sensitivity is declared.
- SARIF contains only suitable location/rule findings and redacts secrets.
- Summary does not include source snippets by default.
- Profiles, semantic contexts, and raw tool output use restricted retention.
- Artifact upload does not alter bundle content identity.

## 7. Cache

CI cache identity includes repository/scope, UCA, adapter/tool/rule/config, platform, and permission context. Forks **MUST NOT** poison trusted caches. Cache restoration is verified before use.

## 8. Gating requirements

A finding may participate in merge gating only when:

- the project explicitly selects the rule/policy;
- required audit completion and scope are satisfied;
- the rule is deterministic or demonstrably high precision and gate-capable;
- stable identity and false-positive handling exist;
- waivers are scoped/owned/expiring;
- gate semantics are documented.

AI-only or unresolved candidates do not block by default.

## 9. Scheduled audits

Typical schedule:

```text
pull request      continuous
nightly           dependency advisory / affected graph
weekly            periodic
release candidate periodic + selected investigative benchmarks
incident          investigative
```

## 10. Interface equivalence

CI invocation must produce the same engine semantics as local CLI/OCI under equivalent inputs. Platform annotations are projections only.
