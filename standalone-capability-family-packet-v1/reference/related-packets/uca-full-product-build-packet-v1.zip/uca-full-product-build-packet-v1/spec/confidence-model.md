# Confidence Model

**Authority:** Normative  
**Status:** `ESTABLISHED`

## Principle

UCA confidence is a transparent multidimensional description, not an invented probability. A scalar probability **MAY** be included only when a producer has documented calibration semantics and evaluation evidence.

## Required dimensions

```text
evidence_strength
detector_precision
scope_coverage
freshness
reproducibility
inference_distance
independent_sources
conflicts
```

### Evidence strength

```text
speculative
indicated
strong
confirmed
```

- `speculative`: plausible hypothesis with weak or indirect support.
- `indicated`: at least one meaningful source supports the claim.
- `strong`: multiple material signals or one highly direct source supports the claim.
- `confirmed`: direct contract violation, reproduction, runtime measurement, test, incident, or equivalent proof within declared scope.

### Detector precision

```text
unknown
low
medium
high
calibrated
```

`calibrated` requires a named corpus, methodology, version, and measured precision/recall or other appropriate calibration evidence.

### Scope coverage

```text
unknown
partial
complete
sampled
not_applicable
```

Coverage may additionally include numerator, denominator, population definition, and sample method.

### Freshness

```text
current
stale
incompatible
unknown
```

### Reproducibility

```text
deterministic
environment_dependent
workload_dependent
model_dependent
human_dependent
```

### Inference distance

A non-negative integer or ordinal description of how many interpretive/derived transitions separate the claim from direct observations. Higher distance does not automatically invalidate a claim but must remain visible.

### Independent sources

Count and identify materially independent producers or evidence classes. Multiple outputs from the same underlying tool/rule set are not automatically independent.

### Conflicts

Count and reference unresolved material conflicts. A finding with unresolved conflict **SHOULD** normally become `needs_investigation` unless a documented precedence rule resolves it.

## Presentation rules

- Reports **MUST** show evidence strength, coverage, freshness, and reproducibility for consequential findings.
- AI model self-confidence **MUST NOT** be used as UCA evidence strength.
- A high-precision detector with partial scope **MUST NOT** be presented as complete.
- Runtime-confirmed behavior under one workload **MUST** disclose workload dependence.
- A stale finding may remain relevant but **MUST** be labeled stale.

## Use in prioritization

Priority may use a policy-defined `evidence_confidence` weight derived from this vector, but the vector **MUST** remain available. The derivation **MUST** be versioned and inspectable; conflicts or incomplete high-impact floors may force `INVESTIGATE` regardless of aggregate weight.

## Example

```json
{
  "evidence_strength": "strong",
  "detector_precision": "high",
  "scope_coverage": {
    "status": "partial",
    "analyzed": 82,
    "population": 100,
    "unit": "modules"
  },
  "freshness": {
    "status": "current",
    "valid_for_revision": "sha256:..."
  },
  "reproducibility": "deterministic",
  "inference_distance": 1,
  "independent_sources": 3,
  "conflicts": []
}
```
