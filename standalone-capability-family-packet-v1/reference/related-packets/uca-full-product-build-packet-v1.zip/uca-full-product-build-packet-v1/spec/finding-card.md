# Concise Finding-Card Projection

**Authority:** Normative presentation contract  
**Status:** `ACCEPTED`

## Purpose

The card is a progressive-disclosure projection for terminals, agents, reports, and MCP. It is not canonical evidence; the Audit Bundle finding remains canonical.

## Required high-signal fields

```text
Priority · concise reduction/finding label
Finding
Evidence
Scope / completion qualification
Consequence
Recommendation
Expected benefit or reduction
Safety floor (when applicable)
Confidence
Risk
Validate
```

Material limitations **MUST** appear in the card rather than being hidden behind a link.

## Example

```text
P1 · collapse abstraction

Finding
PaymentProvider is a pass-through interface with one implementation,
one consumer, and no independent security, test, runtime, ownership,
or compatibility boundary.

Evidence
FND-01J… · ARCH-17 · CALL-8 · HIST-42

Scope
Current repository coverage complete.
External consumer status unknown.

Consequence
The interface, registry, and factory add navigation and change surface
while changing with the implementation.

Recommendation
Use StripePaymentProvider directly and remove the registry and factory.

Expected reduction
3 files · 1 interface · 1 registry · 2 factory paths · 2 concepts

Safety floor
Contract behavior strongly indicated preserved. Authorization unchanged.
External-library consumer status requires confirmation.

Confidence
Strong evidence · deterministic structure/history · current revision

Risk
Medium

Validate
Public API check · contract tests · full build · external-consumer review
```

## Rules

- Title/label **MUST NOT** substitute for taxonomy/finding ID.
- Evidence references **MUST** resolve in the bundle.
- Scope qualification **MUST** mention partial/stale/unknown material states.
- Recommendation **MUST** remain non-authorizing.
- Expected reduction **MUST** be described as estimated unless measured after implementation.
- `retain` and `investigate` cards are valid.
- Cards should be ordered by project-relevant priority, not raw severity or LOC.
- Full evidence is available through `uca inspect`/MCP references rather than copied into every card.
