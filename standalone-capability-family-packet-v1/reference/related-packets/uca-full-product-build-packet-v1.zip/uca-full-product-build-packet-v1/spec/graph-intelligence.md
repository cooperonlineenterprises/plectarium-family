# Graph Intelligence and Context Projection

**Authority:** Normative graph semantics / reference architecture  
**Status:** `ACCEPTED`

## 1. Graph families

UCA may construct:

```text
FileGraph
ModuleGraph
PackageGraph
SymbolGraph
CallGraph
TypeGraph
DataFlowGraph
CoChangeGraph
OwnershipGraph
EvidenceGraph
```

Each graph is versioned and records extraction method, scope, producer, resolution strength, limitations, and node/edge identities.

## 2. Node and edge requirements

Nodes identify semantic entities or artifacts with repository/scope binding. Edges include:

- source and target IDs;
- edge kind;
- producer/resolver;
- confidence/resolution;
- conditional/dynamic status;
- source evidence/location;
- applicability and limitations.

Example:

```json
{
  "source":"symbol:checkout.calculate",
  "target":"symbol:pricing.apply_policy",
  "kind":"calls",
  "producer":"rust-indexer@1.0.0",
  "resolution":"compiler_semantic",
  "confidence":"confirmed"
}
```

## 3. Analyses

Graph algorithms may include:

- strongly connected components and cycles;
- in/out degree and transitive fan-in/out;
- centrality and bridge/articulation analysis;
- communities/clustering;
- reachability;
- dependency direction/instability;
- blast radius;
- architecture rule evaluation;
- graph comparison across revisions.

Algorithms generate observations/candidates, not automatic architecture verdicts. Centrality may represent a healthy platform core or a dangerous bottleneck; history, defects, ownership, and intended architecture provide context.

## 4. Multiplex evidence

Structural, historical, semantic, runtime, and ownership graphs may disagree. UCA preserves each source and may fuse them without flattening provenance.

## 5. Deterministic context projection

UCA **SHOULD** provide a deterministic evidence-graph-guided context projection for agents and semantic analyzers. It is a view, not the canonical repository model.

Projection inputs include:

- repository and scope identity;
- finding/candidate/hypothesis;
- referenced entities;
- graph neighborhood rules;
- tests and relevant history;
- supporting/contradicting evidence;
- token/byte budget;
- projection algorithm/version.

Ranking may consider:

- direct evidence relevance;
- callers/callees/dependencies;
- centrality and affected paths;
- co-change and ownership;
- tests/contracts;
- recent material changes;
- explicit user focus.

## 6. Projection output

A context manifest records:

- included artifact/range/entity with digest;
- inclusion reason and rank;
- excluded candidate context due to budget/policy;
- budget and measured size;
- sensitive material exclusions;
- algorithm/config/version;
- limitations.

Agents/models receive only the selected content, with repository text framed as untrusted data.

## 7. Omission risk

Projection cannot establish exhaustive understanding. High-impact semantic conclusions may require widening context or independent validation. A low-context result records the limitation rather than claiming full-repository semantic review.
