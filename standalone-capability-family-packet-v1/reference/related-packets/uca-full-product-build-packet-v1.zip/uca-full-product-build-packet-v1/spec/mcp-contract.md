# MCP Contract

**Authority:** Normative interface boundary  
**Status:** `ACCEPTED`

## 1. Role

The MCP server is a thin protocol interface over the authoritative UCA engine and bundle reader. It **MUST NOT** implement a second planner, audit methodology, cache, finding engine, semantic prompt system, or authority model.

## 2. Initial tools

```text
uca_plan_audit
uca_run_audit
uca_get_audit
uca_list_findings
uca_get_finding
uca_explain_finding
uca_list_hotspots
uca_inspect_module
uca_compare_audits
uca_get_capabilities
```

Names may be refined while preserving these operations.

## 3. Resources

```text
uca://audits/{audit-id}/manifest
uca://audits/{audit-id}/completion
uca://audits/{audit-id}/findings
uca://audits/{audit-id}/findings/{finding-id}
uca://audits/{audit-id}/candidates/{candidate-id}
uca://audits/{audit-id}/hotspots
uca://audits/{audit-id}/reports/summary
```

Large results are paginated or returned by immutable reference. Raw sensitive evidence is not automatically exposed.

## 4. Long-running operations

Audit execution returns a run/task reference and supports:

- progress events;
- status retrieval;
- cancellation;
- final bundle reference/content ID;
- completion/limitations.

The normal Audit Bundle remains the result. MCP task state is not canonical audit evidence.

## 5. Prohibited operations

The MCP surface **MUST NOT** expose:

- arbitrary shell;
- arbitrary file read/write;
- repository mutation;
- adapter/tool installation;
- silent network enablement;
- credential retrieval/configuration;
- waiver creation;
- issue/task creation;
- remediation execution;
- unbounded model or audit execution.

## 6. Roots and scope

The server validates client-provided roots against configured allowed roots. Symlink/path escape is prohibited. The MCP client cannot expand scope or permissions beyond server/host policy.

## 7. Interface equivalence

Equivalent schema-valid CLI and MCP requests under the same engine/product/config/tool identities **MUST** produce semantically equivalent plan, evidence, findings, completion, and bundle content identity, excluding interface operational metadata.

Cross-interface conformance tests are release gates.

## 8. Transport

Initial target is stdio for local clients. Streamable HTTP or future transport requires explicit authentication, origin/session controls, network policy, and equivalent semantics. Transport choice does not change audit authority.

## 9. Error mapping

MCP errors preserve UCA categories:

```text
invalid_request
policy_refusal
required_capability_unavailable
partial_completion
internal_error
cancelled
```

A transport success does not imply an audit completed.

## 10. Agent interpretation

MCP descriptions should state that findings are non-authorizing evidence. Agent Skills may teach tool selection but do not replace the server/engine.
