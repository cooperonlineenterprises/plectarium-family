# Audit Tiers and Focused Lenses

**Authority:** Normative  
**Status:** `ACCEPTED`

## 1. Tier semantics

A tier is a named set of scope, capability, budget, caching, and presentation defaults. It **MUST NOT** silently widen permissions. Requests and host policy remain authoritative ceilings.

## 2. Continuous

**Typical use:** pull requests, local changes, changed and affected code.

Default posture:

- changed/affected scope;
- network denied;
- project execution denied unless explicitly requested;
- high cache reuse;
- low-noise output;
- deterministic new regressions may be gateable;
- target wall budget 120 seconds; published corpus determines actual target.

Typical capabilities:

- repository/scope identity;
- changed entity discovery;
- compiler/type/lint import where already available;
- changed-function structure metrics;
- new exact clones;
- new unused/unreachable local code;
- architecture rules and new cycles;
- public API diff;
- secrets/high-confidence SAST import;
- dependency-manifest delta;
- changed-code coverage evidence;
- explicit performance budgets;
- baseline comparison.

Blocking eligibility is limited to project-selected deterministic high-precision rules and required-completion failures. Heuristic or AI-only findings are advisory.

## 3. Periodic

**Typical use:** full repository/subsystem scheduled architectural maintenance.

Default posture:

- repository or named subsystem scope;
- network denied unless capability-specific policy permits;
- project execution selectively authorized;
- target typical wall time under 30 minutes for reference medium repository; default ceiling 60 minutes;
- findings ranked and bounded rather than exhaustive warning dump.

Adds capabilities such as:

- full complexity and size distributions;
- complexity × churn;
- defect/revert concentration;
- temporal coupling and ownership concentration;
- full module graph, SCCs, centrality, communities, architecture drift;
- near duplication;
- dead code/unused exports/dependencies candidates;
- feature-flag and migration age;
- dependency lifecycle/SBOM/vulnerability review;
- mutation sampling and test-duration/flakiness;
- build critical path;
- documentation/terminology drift;
- Reduction lens and reconsideration triggers.

Periodic findings are normally advisory and become planned work through project governance.

## 4. Investigative

**Typical use:** explicit hypothesis, hotspot, finding, incident, security concern, concurrency issue, or performance regression.

The request **MUST** identify:

- trigger finding/hypothesis;
- exact subject;
- required capabilities;
- workload/scenario;
- resource budget;
- execution/network rights;
- success/stop conditions;
- validation method.

May include when authorized:

- CPU/memory/allocation/I/O/database/network profiling;
- tracing and query plans;
- race/deadlock/lock analysis;
- fuzzing/property/model-based tests;
- fault injection/cancellation/shutdown analysis;
- semantic or architecture deep review;
- root-cause-guided variant analysis.

Investigative execution never inherits broader rights merely because it is deeper.

## 5. Escalation

UCA may recommend escalation, producing:

- source tier and triggering findings;
- recommended tier/lens;
- required capabilities/evidence;
- expected cost class;
- permission requirements;
- reason and limitations.

Escalation is a recommendation. UCA **MUST NOT** automatically run deeper project code, network, or model analysis.

## 6. Focused lenses

Initial lenses may include:

```text
full-spectrum
reduction
architecture
dependency-health
testing
reliability
security
performance
dead-weight
api-domain-modeling
state-concurrency
```

A lens changes capability selection and report ordering over one shared evidence model. It **MUST** declare:

- included capabilities;
- required cross-checks/safety floors;
- omitted areas;
- whether findings from other domains remain visible;
- completion wording;
- escalation conditions.

A focused security or reduction audit is not a full-spectrum audit.
