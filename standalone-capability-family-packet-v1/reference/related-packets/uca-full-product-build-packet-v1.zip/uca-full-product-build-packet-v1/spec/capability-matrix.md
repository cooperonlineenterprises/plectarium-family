# Capability Matrix

**Authority:** Normative release-depth contract  
**Status:** `ACCEPTED`  
**Machine source:** [`capability-matrix.yaml`](capability-matrix.yaml)

## Meaning

The matrix defines how deeply each capability is expected to work. It is not a yes/no marketing list. The YAML record is canonical for automation; this document explains the semantics and presents a generated overview.

### Depth

- `none`: capability is not claimed.
- `generic`: language-neutral metadata or imported evidence only.
- `basic`: useful bounded capability with material documented gaps.
- `useful`: dependable developer value across intended common cases.
- `deep`: production-grade intended semantics, validation, edge cases, and integration.
- `preview`: present but not a stable release claim or default gate.

### Evidence kind

The field identifies the dominant source; capabilities may emit multiple evidence classes. Permission and tool requirements are explicit.

## V1 overview

| Capability | V1 depth | Mature depth | Dominant evidence | Network | Project execution | Release proof |
|---|---:|---:|---|---|---|---|
| `repo.identity` | deep | deep | deterministic_contract | denied | denied | `CP-IDENTITY-001` |
| `repo.scope` | deep | deep | deterministic_contract | denied | denied | `CP-SCOPE-001` |
| `repo.discovery` | useful | deep | deterministic_static | denied | denied | `CP-DISCOVERY-001` |
| `audit.capability-resolution` | deep | deep | deterministic_contract | denied | denied | `CP-PLAN-001` |
| `audit.planning` | deep | deep | deterministic_contract | denied | denied | `CP-PLAN-002` |
| `audit.execution` | deep | deep | deterministic_contract | denied | denied | `CP-EXEC-001` |
| `audit.cache` | useful | deep | deterministic_contract | denied | denied | `CP-CACHE-001` |
| `evidence.raw` | deep | deep | deterministic_contract | denied | denied | `CP-EVIDENCE-001` |
| `evidence.normalization` | deep | deep | deterministic_contract | denied | denied | `CP-EVIDENCE-002` |
| `evidence.graph` | deep | deep | derived_fusion | denied | denied | `CP-EVIDENCE-003` |
| `candidate.generation` | useful | deep | mixed | denied | denied | `CP-CANDIDATE-001` |
| `candidate.validation` | deep | deep | derived_fusion | denied | denied | `CP-CANDIDATE-002` |
| `finding.generation` | deep | deep | derived_fusion | denied | denied | `CP-FINDING-001` |
| `finding.comparison` | deep | deep | deterministic_contract | denied | denied | `CP-COMPARE-001` |
| `finding.priority` | useful | deep | heuristic_static | denied | denied | `CP-PRIORITY-001` |
| `bundle.write-read` | deep | deep | deterministic_contract | denied | denied | `CP-BUNDLE-001` |
| `report.projections` | useful | deep | deterministic_contract | denied | denied | `CP-REPORT-001` |
| `history.churn` | deep | deep | historical | denied | denied | `CP-HISTORY-001` |
| `history.cochange` | useful | deep | historical | denied | denied | `CP-HISTORY-002` |
| `history.ownership` | useful | deep | historical | denied | denied | `CP-HISTORY-003` |
| `history.reverts-defects` | basic | deep | historical | denied | denied | `CP-HISTORY-004` |
| `structure.file-module-graph` | deep | deep | deterministic_static | denied | denied | `CP-GRAPH-001` |
| `structure.symbol-graph` | useful | deep | deterministic_static | denied | denied | `CP-GRAPH-002` |
| `structure.call-type-dataflow` | basic | deep | external_tool_deterministic | denied | denied | `CP-GRAPH-003` |
| `structure.cycles-centrality` | deep | deep | derived_fusion | denied | denied | `CP-GRAPH-004` |
| `structure.complexity` | useful | deep | deterministic_static | denied | denied | `CP-STRUCT-001` |
| `structure.hotspots` | deep | deep | derived_fusion | denied | denied | `CP-HOTSPOT-001` |
| `duplication.exact` | deep | deep | deterministic_static | denied | denied | `CP-DUP-001` |
| `duplication.near` | useful | deep | heuristic_static | denied | denied | `CP-DUP-002` |
| `duplication.semantic` | preview | deep | ai_interpretation | denied | denied | `CP-DUP-003` |
| `architecture.rules` | deep | deep | deterministic_contract | denied | denied | `CP-ARCH-001` |
| `architecture.drift` | useful | deep | heuristic_static | denied | denied | `CP-ARCH-002` |
| `deadweight.reachability` | useful | deep | mixed | denied | denied | `CP-DEAD-001` |
| `dependency.inventory` | deep | deep | external_tool_deterministic | denied | denied | `CP-DEP-001` |
| `dependency.vulnerability` | useful | deep | external_tool_deterministic | optional_declared | denied | `CP-DEP-002` |
| `dependency.lifecycle` | useful | deep | heuristic_static | denied | denied | `CP-DEP-003` |
| `testing.coverage` | deep | deep | external_tool_deterministic | denied | optional_declared | `CP-TEST-001` |
| `testing.mutation` | useful | deep | runtime_observed | denied | required_declared | `CP-TEST-002` |
| `testing.flakiness-cost` | useful | deep | runtime_observed | denied | optional_declared | `CP-TEST-003` |
| `security.sast-import` | useful | deep | external_tool_deterministic | denied | denied | `CP-SEC-001` |
| `reliability.failure-paths` | useful | deep | mixed | denied | denied | `CP-REL-001` |
| `state.ownership-flow` | basic | deep | heuristic_static | denied | denied | `CP-STATE-001` |
| `api.domain-model` | basic | deep | ai_interpretation | denied | denied | `CP-API-001` |
| `runtime.profile` | useful | deep | runtime_observed | denied | required_declared | `CP-RUNTIME-001` |
| `runtime.trace-query` | useful | deep | runtime_observed | optional_declared | optional_declared | `CP-RUNTIME-002` |
| `investigation.race-fuzz-fault` | preview | deep | runtime_observed | denied | required_declared | `CP-INV-001` |
| `reduction.lens` | deep | deep | derived_fusion | denied | denied | `CP-REDUCE-001` |
| `debt.reconsideration` | useful | deep | deterministic_contract | denied | denied | `CP-DEBT-001` |
| `semantic.ai` | preview | deep | ai_interpretation | optional_declared | denied | `CP-AI-001` |
| `context.projection` | useful | deep | derived_fusion | denied | denied | `CP-CONTEXT-001` |
| `interface.cli` | deep | deep | deterministic_contract | denied | denied | `CP-CLI-001` |
| `interface.ci` | deep | deep | deterministic_contract | denied | denied | `CP-CI-001` |
| `interface.mcp` | deep | deep | deterministic_contract | denied | denied | `CP-MCP-001` |
| `distribution.oci` | deep | deep | deterministic_contract | denied | denied | `CP-OCI-001` |
| `interface.agent-skills` | deep | deep | ai_interpretation | denied | denied | `CP-SKILL-001` |
| `integration.external-provider` | useful | deep | deterministic_contract | denied | denied | `CP-PROVIDER-001` |

## Release use

A mature UCA v1 may be declared only when every non-preview v1 capability meets its named claim-proof gate, documented language depth, completion semantics, and known-limitations requirements. `preview` capabilities may ship only when they are clearly labeled, off or advisory by default, and do not weaken required completion.

## Change control

Changing a capability ID, meaning, v1 depth, evidence semantics, required permission, or release gate requires architecture review and synchronization with `RELEASE-CRITERIA.md`, the evaluation claim-proof matrix, schemas, and task graph.
