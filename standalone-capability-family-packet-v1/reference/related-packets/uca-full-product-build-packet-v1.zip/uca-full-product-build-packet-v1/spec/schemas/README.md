# UCA Schema Catalog

**Classification:** Human-readable companion to machine-readable normative schemas  
**Schema dialect:** JSON Schema Draft 2020-12

Each schema has an immutable major-version URI under `https://schemas.uca.dev/v1/`. Product releases and schema versions are independent. Breaking semantic changes require a new schema major and migration analysis.

## Foundation

| Schema | Purpose |
|---|---|
| `common-definitions` | Shared identifiers, digests, references, timestamps, entities, producers, and permission values |
| `audit-request` | Requested subject, tier/lens, scope, capabilities, execution rights, budgets, baseline, and outputs |
| `repository-identity` | Exact repository/working-tree subject identity |
| `scope` | Included/excluded/classified population and diff/affected expansion |
| `discovery` | Detected languages, projects, entry points, generated/vendor roots, and limitations |
| `capability` | Capability identity, target depth, evidence, permissions, maturity, and proof |
| `audit-tier` | Continuous, Periodic, or Investigative defaults and lens |

## Planning and execution

| Schema | Purpose |
|---|---|
| `audit-plan` | Immutable content-addressed execution plan |
| `execution-node` | One DAG node, producer, scope, direct execution contract, budget, cache, and continuation |
| `execution-permission` | Effective permission set and governing policy digest |
| `analyzer-manifest` | Built-in or external analyzer identity and declared behavior |
| `adapter-manifest` | Out-of-process adapter protocol, tool, permissions, resources, normalization, and ownership |
| `analyzer-run` | Actual task outcome, timing, outputs, coverage, diagnostics, and limitations |

## Evidence and findings

| Schema | Purpose |
|---|---|
| `raw-evidence-reference` | Exact raw artifact digest, media type, location, sensitivity, and retention |
| `observation` | Normalized evidence envelope |
| `evidence-node` / `evidence-edge` | Evidence graph records |
| `confidence` | Transparent multidimensional confidence vector |
| `candidate` | Unvalidated concern or opportunity |
| `candidate-validation` | Confirming, contradicting, and refutation evidence plus outcome |
| `rejected-candidate` | Preserved candidate rejection record |
| `finding-fingerprint` | Stable semantic finding identity method and quality |
| `finding` | Decision-oriented, non-authorizing final finding |
| `reduction-finding` | Structured Reduction action/target/replacement/benefit extension |
| `safety-floor` | Required behavior and non-reducible preservation assessment |
| `reconsideration-trigger` | Predicate for reopening accepted debt or justified complexity |
| `waiver` | Owned, reasoned, expiring disposition—not deletion of evidence |

## Results and comparison

| Schema | Purpose |
|---|---|
| `completion` | Truthful audit completion and per-capability/node summary |
| `audit-bundle-manifest` | Canonical bundle index and content identity |
| `comparison` | Compatible/incompatible audit comparison and finding lifecycle changes |
| `provenance` | Subjects, materials, activities, agents, and attestations |
| `report-summary` | Presentation projection; never the canonical evidence store |
| `language-capability` | Declared depth by language and capability |

## Extensibility

Schemas use `extensions` maps at defined boundaries. Implementations MUST NOT place foundational semantics only in unversioned extension keys. Unknown required semantics fail compatibility; unknown optional observations may be retained without interpretation.

## Validation

Run:

```bash
python scripts/validate-packet.py
```

The packet validator parses every schema and performs Draft 2020-12 meta-schema validation. Product implementation SHOULD add positive and negative instance test vectors under `spec/examples/` as schemas stabilize during FOUNDATION-002.
