# Execution Permission and Security Contract

**Authority:** Normative  
**Status:** `ESTABLISHED`

## 1. Trust boundaries

```mermaid
flowchart LR
    E[Trusted UCA engine] --- R[Untrusted repository]
    E --- C[Untrusted project configuration]
    E --- A[Trusted-but-constrained adapter executable]
    E --- O[Untrusted analyzer output]
    E --- N[Optional network service]
    E --- M[Optional model provider]
    E --- K[Local cache/artifact store]
    E --- H[Host / consumer]
```

UCA assumes repositories, project metadata, source comments, generated files, analyzer output, and model output may be malicious.

## 2. Permission vocabulary

Every plan/node declares applicable permissions:

```text
repository_read
repository_write
git_read
git_write
project_execution
external_process_execution
network
output_write
cache_write
temporary_write
credentials
```

Values are deny/allow with scope and constraints, not a single broad boolean.

### Defaults

```text
repository_read: scoped allow
repository_write: deny
git_read: scoped allow when needed
git_write: deny
project_execution: deny
external_process_execution: only exact planned trusted executables
network: deny
output_write: explicit path allow
cache_write: explicit cache allow
temporary_write: bounded allow
credentials: deny
```

## 3. Policy precedence

```text
host-enforced security policy
→ accepted audit request
→ CLI options within policy
→ repository configuration
→ user configuration
→ defaults
```

Lower-precedence configuration may narrow rights but **MUST NOT** widen a higher-level denial.

## 4. Project execution

Project builds, tests, code generation, package scripts, hooks, and repository-defined commands are project code execution. A node requiring them records:

- exact argv;
- reason/capability;
- sandbox;
- repository/copy mode;
- network;
- writes;
- environment;
- resource limits;
- risk classification.

Project execution is never inferred from “run tests” without a plan.

## 5. Process execution

- Direct argv only; no shell by default.
- Executable identity/version/digest is verified when policy requires.
- Child process trees inherit or reduce permissions.
- Cancellation and timeout terminate the full process group.
- Stdout/stderr and produced files are byte bounded.
- Exit codes are mapped by adapter contract, not guessed.

## 6. Filesystem

- Root and output paths are canonicalized safely.
- Repository paths cannot escape approved roots through symlinks or traversal.
- Special files are excluded.
- Native read-only mode performs pre/post identity checks but is weaker than an actual read-only mount.
- High-assurance mode uses a copied workspace, OS sandbox, or OCI read-only mount.

## 7. Container target

Preferred mounts:

```text
/workspace   read-only repository
/out         writable result
/cache       writable content-addressed cache
/tmp         bounded writable temporary storage
```

Hardening target:

- non-root;
- read-only root filesystem;
- dropped Linux capabilities;
- no privileged mode;
- no Docker socket;
- no host home;
- no inherited credentials;
- network none by default;
- PID, CPU, memory, file, and wall limits;
- seccomp or equivalent where available.

## 8. Network

Network permission records:

- purpose;
- protocol;
- destination allowlist or managed provider;
- credential reference;
- data classes allowed to leave host;
- retention/policy;
- timeout/size limits;
- cache/provenance implications.

Repository-provided URLs cannot expand the allowlist.

## 9. Credentials

Credentials are references supplied by the host, not values stored in UCA config/bundles. They are injected only into the node requiring them and removed from logs and provenance. Fork-PR operation defaults to no credentials.

## 10. Malicious-repository controls

Threats and required controls include:

| Threat | Controls |
|---|---|
| Hostile build scripts | Project execution denied by default; isolated copied/OCI workspace |
| Symlink/path escape | Root containment and non-following policy |
| Binaries/special files | Metadata-only or excluded; no implicit execution |
| Archive/decompression bomb | No implicit expansion; count/depth/byte limits |
| Parser exploit | Memory-safe parsers where practical, fuzzing, isolation, limits |
| Command injection | Direct argv, no shell |
| Crafted Git history/config | Bounded history, disable hooks/pagers/filters, library parsing where possible |
| Malicious analyzer output | Schema and resource validation, raw/normalized separation |
| Secret exposure | Sensitive-path policy, redaction, no secret values in reports |
| Network exfiltration | Network deny and destination/data policy |
| Cache poisoning | Content addressing, producer identity, validation, quarantine |
| Prompt injection | Repository text treated as data; model has no tools/scope expansion |
| Resource exhaustion | File/graph/process/memory/time/output limits |
| TOCTOU mutation | Snapshot/read-only mount or identity before/after |

## 11. Security refusals

If the requested capability cannot satisfy host security policy, UCA returns a refusal or unavailable node. It **MUST NOT** silently downgrade sandbox, enable network, or switch to a repository executable.

## 12. Evidence retention and privacy

Bundles classify sensitivity. Remote providers receive only explicit context manifests. Raw source, secrets, profiles, and proprietary tool outputs follow configured retention and export policies.
