# UCA Audit Bundle Format

**Authority:** Normative  
**Status:** `ESTABLISHED`  
**Bundle major:** `uca.audit-bundle.v1`

## 1. Role

The UCA Audit Bundle is the durable canonical result. Reports, SARIF, MCP responses, and CI annotations are projections. The bundle preserves request, plan, subject, execution, evidence, candidate validation, findings, limitations, completion, comparison, and provenance.

## 2. Canonical directory layout

```text
uca-audit/
├── manifest.json
├── request.json
├── plan.json
├── completion.json
├── repository.json
├── scope.json
├── discovery.json
├── capabilities.json
├── analyzers.json
├── analyzer-runs.jsonl
├── candidates.jsonl
├── rejected-candidates.jsonl
├── findings.jsonl
├── waivers-applied.jsonl
│
├── observations/
│   ├── metrics.jsonl
│   ├── structure.jsonl
│   ├── history.jsonl
│   ├── security.jsonl
│   ├── dependencies.jsonl
│   ├── tests.jsonl
│   ├── runtime.jsonl
│   ├── reduction.jsonl
│   ├── semantic.jsonl
│   └── limitations.jsonl
│
├── graphs/
│   ├── module-graph.json.zst
│   ├── symbol-graph.json.zst
│   ├── cochange-graph.json.zst
│   ├── ownership-graph.json.zst
│   └── evidence-graph.json.zst
│
├── raw/
│   └── <adapter-or-producer>/<run-id>/...
│
├── interoperability/
│   ├── results.sarif
│   ├── sbom.cdx.json
│   ├── sbom.spdx.json
│   └── coverage/
│
├── comparison/
│   └── baseline-comparison.json
│
├── reports/
│   ├── summary.json
│   ├── summary.md
│   └── report.html
│
├── provenance/
│   ├── subjects.json
│   ├── materials.json
│   └── attestations/
│
└── checksums.sha256
```

Only applicable optional files/directories are present. `manifest.json`, request, plan, completion, repository, scope, capability/analyzer inventories, findings (possibly empty), and checksums are required for a finalized v1 bundle.

## 3. Identity

### Audit run ID

An operational, unique, time-sortable identity. It may differ between equivalent runs.

### Audit content ID

A SHA-256 digest over canonical semantic identities including:

- repository identity and scope;
- request and accepted plan;
- UCA product/schema/taxonomy versions;
- capability and producer identities;
- normalized canonical outputs;
- completion and limitations;
- referenced artifact digests.

Timestamps and run IDs that do not affect semantics are excluded from content identity.

### Archive identity

A `.tar.zst` or `.zip` transport has its own file digest. Archive identity is not bundle content identity because ordering and compression metadata may differ.

## 4. Canonical serialization

Hash-bearing JSON documents use UTF-8 and RFC 8785 JSON Canonicalization Scheme semantics. Producers **MUST** reject duplicate JSON keys and non-finite numbers. JSONL entries are individually valid JSON objects and canonically ordered by stable ID where deterministic output is promised.

## 5. Checksums and validation

`checksums.sha256` covers every finalized bundle file except itself. Validation checks:

- required files;
- schema compatibility;
- file digests;
- internal references;
- ID uniqueness;
- graph endpoint existence;
- completion consistency;
- content ID recomputation;
- path safety;
- decompression/resource limits.

A corrupt or truncated bundle is not partially trusted without an explicit salvage operation that produces a new provenance record and limitation.

## 6. Atomic finalization

Execution writes to a staging directory. Finalization:

1. closes writers;
2. validates records/references;
3. writes manifest and completion;
4. computes checksums/content identity;
5. marks finalized state;
6. atomically moves or renames where supported.

Interrupted staging output is labeled incomplete and not presented as a finalized bundle.

## 7. Raw evidence retention

Raw evidence policy values:

```text
none
hash_only
local_only
bundle
external_reference
```

Sensitivity, size, licensing, and secret policy determine retention. Normalized evidence remains valid only when provenance says whether raw output was retained or hashed.

## 8. Compression and large graphs

Large graphs use deterministic JSON representation compressed with zstd or a future versioned encoding. Compression parameters and uncompressed digest are recorded. Readers enforce compressed/uncompressed size and nesting limits.

## 9. Interoperability

- SARIF is a projection for location/rule-oriented findings, not the canonical UCA model.
- CycloneDX/SPDX are retained as imported/generated artifacts and normalized into dependency evidence.
- Coverage, test, profile, trace, and tool-native outputs retain original formats where useful.
- OpenTelemetry/pprof records require workload/environment identity.

## 10. Compatibility and migration

- Bundle major changes for breaking semantic/layout requirements.
- Additive optional records may evolve within v1 through schema/product minor versions.
- Production UCA **SHOULD** read current and previous bundle major.
- `uca schema migrate` performs deterministic documented migrations.
- Lossy migrations require explicit limitations and new bundle identity.
- Taxonomy IDs are not reused.

## 11. Manifest

The manifest indexes all artifacts with path, media type, schema, digest, required/optional status, sensitivity, compression, and logical role. It includes product, bundle, taxonomy, priority-policy, repository, scope, completion, and content identity.
