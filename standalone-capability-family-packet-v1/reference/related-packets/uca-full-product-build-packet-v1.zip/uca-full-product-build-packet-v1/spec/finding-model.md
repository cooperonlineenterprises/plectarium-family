# Finding Model

**Authority:** Normative  
**Status:** `ESTABLISHED`

## 1. Purpose

A UCA finding is a durable decision-support record. It separates observation, interpretation, consequence, recommendation, expected benefit, confidence, change risk, validation, priority, suppression, provenance, and lifecycle.

A finding is not an authorization, issue-tracker item, patch, or proof that remediation has occurred.

## 2. Finding eligibility

A record may become a finding when:

1. a deterministic rule violation is applicable and supported; or
2. a candidate survives required validation and attempted refutation; or
3. an evidence gap, limitation, or investigation need is itself material and accurately described.

`heuristic_candidate` is **not** a final finding class. Heuristic records remain candidates until promoted. This clarifies earlier exploratory terminology.

## 3. Finding classes

```text
deterministic_violation
deterministic_regression
runtime_confirmed
historical_hotspot
semantic_interpretation
investigation_required
evidence_gap
tool_or_scope_limitation
simplification_opportunity
```

A finding may also carry domain facets such as architecture, security, dependency, testing, reliability, performance, or reduction.

## 4. Required semantic sections

### Finding

A factual statement of what was observed or established. It must avoid embedding the recommendation.

### Evidence

References to observations, raw artifacts, candidate validation, and conflicts.

### Interpretation

Why the evidence is believed to represent a structural, behavioral, operational, or simplification concern.

### Consequence

Why the condition matters in the audited repository. Consequences may address correctness, security, reliability, maintainability, performance, cost, operability, or developer productivity.

### Recommendation

The smallest plausible response, with alternatives where material. Recommendations are non-authorizing.

### Expected benefit

The outcomes expected if the recommendation is implemented and validated.

### Confidence

A reference or inline confidence vector.

### Scope

Affected repository identity, entities, locations, and coverage limits.

### Change risk

Possible regression, compatibility, migration, performance, operational, or coordination hazards introduced by remediation.

### Validation strategy

How to demonstrate that remediation preserves required behavior and produces the expected benefit.

### Priority

A transparent band and policy version with inspectable inputs.

### Suppression/waiver behavior

Whether and how the finding may be dispositioned. Safety-critical deterministic findings may have stricter waiver policy, but UCA itself does not approve waivers.

### Provenance

The finding generator, taxonomy, fusion/validation rules, and source evidence identities.

## 5. Lifecycle

```text
new
recurring
changed
needs_investigation
accepted_debt
suppressed
resolved
invalidated
```

- `new`: first compatible appearance.
- `recurring`: same stable condition appears again.
- `changed`: same condition materially changed in evidence, scope, or consequence.
- `needs_investigation`: current evidence cannot support remediation.
- `accepted_debt`: project-owned disposition retains the condition intentionally.
- `suppressed`: scoped waiver hides it from selected projections without erasing it.
- `resolved`: compatible later audit no longer observes the condition and resolution criteria are satisfied.
- `invalidated`: later evidence establishes that the finding was incorrect or inapplicable.

## 6. Stable identity and fingerprinting

A finding has an operational ID and a stable fingerprint.

The stable fingerprint **SHOULD** use:

```text
taxonomy ID
+ normalized semantic entity identity
+ applicable rule or graph-edge identity
+ normalized primary structural context
+ material evidence signature
```

It **MUST NOT** depend primarily on:

- line number;
- current message wording;
- timestamp;
- audit run ID;
- priority;
- recommendation prose.

Fingerprint fallback quality levels:

1. compiler/indexer semantic identity;
2. language-pack symbol identity;
3. file plus syntax-path/context fingerprint;
4. file plus normalized token context;
5. path plus location as last resort.

The finding records fingerprint quality and method version. Comparison tests must verify stability through line movement and nearby refactoring while preventing collision between materially different conditions.

## 7. Duplicate findings

Finding deduplication may combine multiple candidate/evidence sources when they represent one root condition. It **MUST** preserve all supporting and conflicting evidence, not discard “duplicate” producers.

## 8. Recurrence and comparison

A finding is recurring only across compatible subject, scope, taxonomy, fingerprint method, and methodology. If compatibility cannot be established, comparison reports `incomparable` rather than new/resolved.

## 9. Example

```json
{
  "schema_version": "uca.finding.v1",
  "finding_id": "FND-01J...",
  "stable_fingerprint": {
    "value": "sha256:...",
    "method": "uca.fingerprint.semantic-edge.v1",
    "quality": "semantic"
  },
  "taxonomy_id": "UCA.ARCH.BOUNDARY_BYPASS",
  "finding_class": "deterministic_violation",
  "title": "Checkout bypasses the customer-policy boundary",
  "finding": "Checkout imports customer-policy storage directly.",
  "evidence_refs": ["OBS-...", "VAL-..."],
  "interpretation": "The declared policy API does not contain change.",
  "consequences": [{"dimension":"changeability","description":"Policy changes propagate into checkout."}],
  "recommendations": [{"description":"Route eligibility through the policy API."}],
  "confidence_ref": "CNF-...",
  "priority": {"band":"P1","policy_version":"uca.priority.v1"},
  "lifecycle": {"status":"new"},
  "authority_effect": "none"
}
```
