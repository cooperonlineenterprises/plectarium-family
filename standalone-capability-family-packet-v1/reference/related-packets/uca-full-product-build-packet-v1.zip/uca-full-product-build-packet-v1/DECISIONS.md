# UCA Decisions

**Authority:** Governance index  
**Canonical detailed source:** [`design/decision-ledger.md`](design/decision-ledger.md) and [`design/decisions.yaml`](design/decisions.yaml)

## Counts

- **ACCEPTED:** 16
- **DEFERRED:** 4
- **ESTABLISHED:** 22
- **REJECTED:** 6
- **SUPERSEDED:** 1

## Decision index

| ID | Status | Title | Decision |
|---|---|---|---|
| `DEC-001` | ESTABLISHED | Standalone harness-agnostic product | UCA is an independently usable product and has no Octon Mini or agent-harness runtime dependency. |
| `DEC-002` | ESTABLISHED | Evidence and recommendations are non-authorizing | UCA findings never authorize repository or project actions. |
| `DEC-003` | ESTABLISHED | One authoritative engine | CLI, CI, MCP, OCI, and future HTTP use one engine semantics. |
| `DEC-004` | ACCEPTED | Canonical local CLI | The CLI is the canonical human and automation interface. |
| `DEC-005` | ESTABLISHED | Audit Bundle as durable canonical result | The content-addressed UCA Audit Bundle is the canonical audit result; reports and SARIF are projections. |
| `DEC-006` | ESTABLISHED | Read-only repository default | UCA does not mutate the target repository or Git state by default. |
| `DEC-007` | ESTABLISHED | No hidden tool installation | UCA diagnoses but never silently installs or updates analyzers or dependencies. |
| `DEC-008` | ESTABLISHED | Explicit execution and network rights | Project execution, network, credentials, processes, and writable paths are declared in the plan and bounded by policy. |
| `DEC-009` | ESTABLISHED | Truthful completion semantics | Unavailable, denied, timed-out, stale, unsupported, or incomplete analysis never appears complete/passed. |
| `DEC-010` | ESTABLISHED | Evidence-class separation | Deterministic, heuristic, historical, runtime, human, AI, fusion, and unavailability evidence remain distinct. |
| `DEC-011` | ESTABLISHED | AI is optional evidence | AI is an optional structured interpretation source, not the canonical engine, executor, or authority. |
| `DEC-012` | ACCEPTED | Integrate mature specialist analyzers | UCA owns orchestration and evidence fusion and integrates mature tools rather than recreating deep specialist engines. |
| `DEC-013` | ESTABLISHED | Candidate before finding | Heuristic and AI suspicions enter a candidate lifecycle and cannot bypass validation/refutation. |
| `DEC-014` | ACCEPTED | Preserve rejected candidates | Rejected candidates and rejection evidence are stored in the Audit Bundle. |
| `DEC-015` | ESTABLISHED | Stable semantic finding identity | Finding fingerprints use taxonomy/entity/rule/context/evidence signatures rather than line/message/time. |
| `DEC-016` | ESTABLISHED | Vector confidence model | Confidence remains a transparent vector, not an invented universal probability. |
| `DEC-017` | ACCEPTED | Transparent priority, no health score | Priority uses visible benefit/confidence/burden inputs and bands; UCA has no default single health score. |
| `DEC-018` | ACCEPTED | First-class Reduction lens | UCA has an explicit Reduction/Simplification lens over shared evidence. |
| `DEC-019` | ESTABLISHED | Non-reducible safety floor | Every material reduction candidate evaluates applicable behavior, correctness, integrity, security, privacy, accessibility, reliability, compatibility, observability, performance, legal, and operational floors. |
| `DEC-020` | ACCEPTED | Reconsideration triggers | Accepted debt and retained complexity support explicit ceilings, triggers, successor action, and expiry. |
| `DEC-021` | ESTABLISHED | Three audit tiers | Continuous, Periodic, and Investigative tiers define bounded defaults; escalation is recommendation only. |
| `DEC-022` | ACCEPTED | Focused lenses share one evidence model | Architecture, security, performance, testing, reduction, and other lenses change planning/reporting but not engine truth. |
| `DEC-023` | ACCEPTED | Language maturity strategy | Rust and Python target deep v1 support; TypeScript/JavaScript and Go target useful v1 support; generic fallback remains useful. |
| `DEC-024` | ESTABLISHED | Out-of-process/OCI adapter boundary | External adapters run as explicit processes or OCI artifacts, not arbitrary in-process dynamic plugins. |
| `DEC-025` | ACCEPTED | OCI high-assurance distribution | UCA ships hardened minimal/toolbox OCI images; OCI is preferred/required by policy, not universally mandatory. |
| `DEC-026` | ESTABLISHED | MCP as thin interface | MCP exposes typed UCA operations/resources over the engine and no generic shell/write authority. |
| `DEC-027` | ESTABLISHED | CI as thin invocation/presentation layer | CI owns checkout/permissions/infrastructure; UCA owns audit semantics and gates. |
| `DEC-028` | ACCEPTED | Two canonical Agent Skills initially | Ship `uca-audit` and `uca-simplify`; keep review/investigate/explain/compare as modes unless routing evidence justifies more skills. |
| `DEC-029` | ACCEPTED | Generated platform adapters | One canonical Agent Skills source generates thin host-specific packages with drift/conformance tests. |
| `DEC-030` | ESTABLISHED | Octon Mini external evidence-provider boundary | Octon consumes UCA through a narrow read-only evidence-provider workflow and durable bundle reference. |
| `DEC-031` | ACCEPTED | Use Octon Mini to help build UCA | Octon Mini may govern UCA development tasks/decisions/evidence while UCA repository remains independent. |
| `DEC-032` | ACCEPTED | UCA as standalone-capability proving ground | UCA should validate reusable outer conventions for future standalone capabilities. |
| `DEC-033` | ESTABLISHED | Do not prebuild universal capability framework | Generalize only after UCA and a second real capability demonstrate stable common needs. |
| `DEC-034` | ESTABLISHED | Build full product in dependency order | Target a comprehensive production-shaped v1; Minimum Complete Architecture is an integration checkpoint, not product ambition. |
| `DEC-035` | ACCEPTED | Rust 2024 engine direction | Use a Rust 2024 workspace for the authoritative engine, CLI, schemas/types, execution, bundle, and interfaces unless an ADR proves a better choice. |
| `DEC-036` | ACCEPTED | Graph-guided context projection | Provide deterministic budgeted evidence-graph context projections for agents/semantic providers. |
| `DEC-037` | ESTABLISHED | No-skill controlled Agent Skill evaluation | Agent Skills require structural, routing, and behavioral tests with no-skill controls and pressure cases. |
| `DEC-038` | ACCEPTED | Separate artifact reduction from process overhead | Evaluation reports code/concept reduction separately from turns, tokens, tool calls, latency, and human review burden. |
| `DEC-039` | DEFERRED | Hosted service | Design local abstractions that permit a future hosted service, but do not require or build it before local product maturity. |
| `DEC-040` | DEFERRED | Remote AI verifier in production v1 | Schemas support remote providers, but production-v1 inclusion awaits privacy/evaluation evidence. |
| `DEC-041` | DEFERRED | Root-cause-guided variant analysis | Add exact-to-general variant search in Investigative mode after core findings/adapters are stable. |
| `DEC-042` | DEFERRED | Additional UCA Agent Skills | Do not add `uca-review`, `uca-investigate`, `uca-explain`, or `uca-compare` unless routing/behavioral evaluation demonstrates benefit. |
| `DEC-043` | REJECTED | Always-on persistent audit mode | UCA will not inject audit behavior into every coding turn. |
| `DEC-044` | REJECTED | Prompt-only UCA | A prompt or skill cannot substitute for the engine and Audit Bundle. |
| `DEC-045` | REJECTED | Automatic remediation | Initial UCA does not edit, refactor, commit, issue, publish, or deploy. |
| `DEC-046` | REJECTED | Mandatory multi-agent topology | UCA semantics do not require specialist subagents; independent verification is a capability, not an agent topology. |
| `DEC-047` | REJECTED | Raw LOC as simplification objective | LOC is one descriptive observation, never the governing Reduction objective. |
| `DEC-048` | REJECTED | Single aggregate code-health score | UCA does not default to one opaque repository health score. |
| `DEC-049` | SUPERSEDED | Tiny MVP as product target | The earlier smallest non-throwaway kernel is retained only as the Minimum Complete Architecture integration checkpoint. |

Statuses follow the packet source-precedence model. Historical conversation wording does not override this ledger.
