#!/usr/bin/env python3
"""Validate and finalize the UCA Full Product Build Packet v1.

The validator is intentionally packet-scoped. It checks the constitution and
specification package; it does not implement or validate the future UCA engine.

Usage:
  python scripts/validate-packet.py
  python scripts/validate-packet.py --json
  python scripts/validate-packet.py --refresh-derived
  python scripts/validate-packet.py --write-manifest --refresh-derived
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Iterable

try:
    import yaml
except ImportError as exc:  # pragma: no cover
    raise SystemExit("PyYAML is required to validate this packet") from exc

try:
    from jsonschema import Draft202012Validator
except ImportError as exc:  # pragma: no cover
    raise SystemExit("jsonschema is required to validate this packet") from exc

PACKET_NAME = "uca-full-product-build-packet-v1"
PACKET_VERSION = "1.0.0"
MANIFEST_NAME = "PACKET-MANIFEST.json"
CHECKSUM_NAME = "PACKET-CHECKSUMS.sha256"

REQUIRED_FILES = {
    "README.md",
    "CHARTER.md",
    "ARCHITECTURE.md",
    "SECURITY.md",
    "ROADMAP.md",
    "RELEASE-CRITERIA.md",
    "DECISIONS.md",
    "OPEN-QUESTIONS.md",
    "spec/invariants.md",
    "spec/terminology.md",
    "spec/capability-matrix.md",
    "spec/capability-matrix.yaml",
    "spec/audit-lifecycle.md",
    "spec/evidence-model.md",
    "spec/confidence-model.md",
    "spec/candidate-validation.md",
    "spec/finding-model.md",
    "spec/completion-semantics.md",
    "spec/reduction-model.md",
    "spec/safety-floor.md",
    "spec/bundle-format.md",
    "spec/adapter-protocol.md",
    "spec/execution-security.md",
    "spec/repository-identity.md",
    "spec/cli-contract.md",
    "spec/mcp-contract.md",
    "spec/ci-contract.md",
    "agent/BUILD-DIRECTIVE.md",
    "agent/authority.md",
    "agent/workstreams.md",
    "agent/workstreams.yaml",
    "agent/implementation-dependency-graph.md",
    "agent/implementation-dependency-graph.yaml",
    "agent/task-contract.md",
    "agent/validation-contract.md",
    "agent/change-control.md",
    "agent/research-decisions.md",
    "agent/tasks/index.yaml",
    "skills/uca-audit/SKILL.md",
    "skills/uca-simplify/SKILL.md",
    "evals/EVALUATION-SPEC.md",
    "evals/test-catalog.yaml",
    "evals/claim-proof-matrix.md",
    "integrations/octon-mini.md",
    "docs/standalone-capability-pattern.md",
    "research/source-register.md",
    "research/licensing.md",
    "reference/conversation-thread.md",
    "reference/transcript-coverage.md",
    "reference/conversation-decision-map.md",
    "reference/source-map.md",
    "reference/internal-consistency-review.md",
    "fixtures/README.md",
    "scripts/validate-packet.py",
    MANIFEST_NAME,
    CHECKSUM_NAME,
}

REQUIRED_SCHEMAS = {
    "audit-request.schema.json",
    "repository-identity.schema.json",
    "scope.schema.json",
    "discovery.schema.json",
    "capability.schema.json",
    "audit-plan.schema.json",
    "execution-node.schema.json",
    "analyzer-manifest.schema.json",
    "analyzer-run.schema.json",
    "raw-evidence-reference.schema.json",
    "observation.schema.json",
    "evidence-node.schema.json",
    "evidence-edge.schema.json",
    "candidate.schema.json",
    "candidate-validation.schema.json",
    "rejected-candidate.schema.json",
    "finding.schema.json",
    "confidence.schema.json",
    "waiver.schema.json",
    "completion.schema.json",
    "comparison.schema.json",
    "provenance.schema.json",
    "reduction-finding.schema.json",
    "safety-floor.schema.json",
    "audit-bundle-manifest.schema.json",
    "adapter-manifest.schema.json",
}

REQUIRED_OCTON_SCHEMAS = {
    "external-provider-manifest.schema.json",
    "external-provider-registry.schema.json",
    "external-provider-request.schema.json",
    "external-provider-result-ref.schema.json",
}

DERIVED_BEGIN = "<!-- CAPABILITY_GATE_TABLE_START -->"
DERIVED_END = "<!-- CAPABILITY_GATE_TABLE_END -->"


@dataclass
class Finding:
    level: str  # error | warning | info
    code: str
    message: str
    path: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {"level": self.level, "code": self.code, "message": self.message, "path": self.path}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def all_packet_files(root: Path, *, include_integrity: bool = True) -> list[Path]:
    excluded_dirs = {".git", "__pycache__"}
    result: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if any(part in excluded_dirs for part in path.relative_to(root).parts):
            continue
        if path.suffix == ".pyc":
            continue
        if not include_integrity and path.name in {MANIFEST_NAME, CHECKSUM_NAME}:
            continue
        result.append(path)
    return sorted(result, key=lambda p: p.relative_to(root).as_posix())


def strict_json_load(path: Path) -> Any:
    def reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        obj: dict[str, Any] = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError(f"duplicate JSON key: {key}")
            obj[key] = value
        return obj

    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh, object_pairs_hook=reject_duplicates)


def yaml_load(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def classification_for(rel: str) -> str:
    if rel.startswith("spec/schemas/") or rel in {
        "spec/capability-matrix.yaml",
        "agent/workstreams.yaml",
        "agent/implementation-dependency-graph.yaml",
        "agent/tasks/index.yaml",
        "evals/test-catalog.yaml",
    }:
        return "machine-readable-normative"
    if rel.startswith("integrations/octon-mini-schemas/"):
        return "machine-readable-proposed-integration"
    if rel == "CHARTER.md" or rel == "RELEASE-CRITERIA.md" or rel.startswith("spec/"):
        return "normative"
    if rel.startswith("design/") or rel.startswith("agent/") or rel in {"DECISIONS.md", "OPEN-QUESTIONS.md", "ROADMAP.md"}:
        return "governance"
    if rel.startswith("skills/"):
        return "agent-interface-contract"
    if rel.startswith("evals/") or rel.startswith("fixtures/"):
        return "verification"
    if rel.startswith("research/") or rel.startswith("reference/"):
        return "historical-reference"
    if rel.startswith("integrations/"):
        return "integration-boundary"
    if rel.startswith("docs/") or rel == "ARCHITECTURE.md":
        return "reference-architecture"
    if rel == "SECURITY.md":
        return "security-governance"
    if rel.startswith("scripts/"):
        return "validation-tooling"
    if rel in {MANIFEST_NAME, CHECKSUM_NAME}:
        return "packet-integrity"
    return "project-context"


def build_manifest(root: Path) -> dict[str, Any]:
    files = []
    for path in all_packet_files(root, include_integrity=False):
        rel = path.relative_to(root).as_posix()
        files.append({
            "path": rel,
            "sha256": sha256_file(path),
            "bytes": path.stat().st_size,
            "classification": classification_for(rel),
        })

    decisions = yaml_load(root / "design/decisions.yaml")
    capabilities = yaml_load(root / "spec/capability-matrix.yaml")
    workstreams = yaml_load(root / "agent/workstreams.yaml")
    tasks = yaml_load(root / "agent/tasks/index.yaml")
    open_questions = (root / "OPEN-QUESTIONS.md").read_text(encoding="utf-8").count("## OQ-")
    transcript_turns = len(re.findall(r"^## Turn \d{3}\s*$", (root / "reference/conversation-thread.md").read_text(encoding="utf-8"), re.M))

    return {
        "schema_version": "uca.build-packet-manifest.v1",
        "packet": {
            "name": PACKET_NAME,
            "version": PACKET_VERSION,
            "generated_date": "2026-08-31",
            "purpose": "Product Constitution, executable specification, verification contract, and AI-team build substrate for Universal Code Audit.",
        },
        "authority_hierarchy": [
            "CHARTER.md",
            "spec/invariants.md",
            "normative specifications and schemas",
            "accepted ADRs",
            "spec/capability-matrix.yaml and RELEASE-CRITERIA.md",
            "agent/workstreams.yaml",
            "agent/tasks/index.yaml and task packets",
            "agent implementation choices",
        ],
        "source_thread_coverage": {
            "transcript": "reference/conversation-thread.md",
            "coverage_statement": "reference/transcript-coverage.md",
            "visible_turns_preserved": transcript_turns,
            "excludes": ["system messages", "developer messages", "hidden reasoning", "tool calls and raw tool output"],
        },
        "contract_versions": {
            "json_schema_dialect": "https://json-schema.org/draft/2020-12/schema",
            "capability_matrix": capabilities.get("matrix_version"),
            "decision_ledger": decisions.get("schema_version"),
            "workstreams": workstreams.get("schema_version"),
            "task_index": tasks.get("schema_version"),
            "agent_skills": "Agent Skills-compatible SKILL.md packages",
        },
        "counts": {
            "content_files": len(files),
            "json_schemas": len(list((root / "spec/schemas").glob("*.schema.json"))),
            "octon_integration_schemas": len(list((root / "integrations/octon-mini-schemas").glob("*.schema.json"))),
            "capabilities": len(capabilities.get("capabilities", [])),
            "decisions": len(decisions.get("decisions", [])),
            "decision_statuses": dict(Counter(d.get("status") for d in decisions.get("decisions", []))),
            "adrs": len(list((root / "design/adr").glob("adr-*.md"))),
            "workstreams": len(workstreams.get("workstreams", [])),
            "tasks": len(tasks.get("tasks", [])),
            "open_questions": open_questions,
            "conversation_turns": transcript_turns,
        },
        "key_relationships": [
            {"from": "CHARTER.md", "to": "spec/invariants.md", "meaning": "Product constitution governs invariants."},
            {"from": "spec/invariants.md", "to": "spec/schemas/", "meaning": "Machine contracts cannot weaken invariants."},
            {"from": "spec/capability-matrix.yaml", "to": "evals/test-catalog.yaml", "meaning": "Each capability release gate requires named proof."},
            {"from": "RELEASE-CRITERIA.md", "to": "evals/claim-proof-matrix.md", "meaning": "Release claims require fresh passing evidence."},
            {"from": "skills/", "to": "spec/cli-contract.md and spec/mcp-contract.md", "meaning": "Skills orchestrate canonical interfaces rather than implement audit logic."},
            {"from": "integrations/octon-mini.md", "to": "spec/bundle-format.md", "meaning": "Octon consumes a durable UCA result reference without UCA core dependency."},
        ],
        "integrity": {
            "manifest_scope": "All content files except PACKET-MANIFEST.json and PACKET-CHECKSUMS.sha256.",
            "checksums_scope": "All packet files except PACKET-CHECKSUMS.sha256, including PACKET-MANIFEST.json.",
            "algorithm": "SHA-256",
        },
        "files": files,
    }


def write_manifest_and_checksums(root: Path) -> None:
    manifest = build_manifest(root)
    (root / MANIFEST_NAME).write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = []
    for path in all_packet_files(root, include_integrity=True):
        if path.name == CHECKSUM_NAME:
            continue
        rel = path.relative_to(root).as_posix()
        lines.append(f"{sha256_file(path)}  {rel}")
    (root / CHECKSUM_NAME).write_text("\n".join(lines) + "\n", encoding="utf-8")


def refresh_capability_gate_table(root: Path) -> None:
    matrix = yaml_load(root / "spec/capability-matrix.yaml")
    catalog = yaml_load(root / "evals/test-catalog.yaml")
    tests_by_gate: dict[str, list[str]] = defaultdict(list)
    for test in catalog.get("tests", []):
        gate = test.get("release_gate")
        if gate:
            tests_by_gate[gate].append(test["id"])

    rows = [
        "| Capability ID | V1 target depth | Release gate | Test catalog IDs |",
        "|---|---|---|---|",
    ]
    for capability in matrix.get("capabilities", []):
        gate = capability.get("release_gate", "")
        tests = ", ".join(f"`{x}`" for x in tests_by_gate.get(gate, [])) or "**MISSING**"
        rows.append(
            f"| `{capability['id']}` | `{capability.get('v1_target_depth', 'unspecified')}` | `{gate}` | {tests} |"
        )
    replacement = DERIVED_BEGIN + "\n" + "\n".join(rows) + "\n" + DERIVED_END
    path = root / "evals/claim-proof-matrix.md"
    text = path.read_text(encoding="utf-8")
    if DERIVED_BEGIN not in text or DERIVED_END not in text:
        raise SystemExit("claim-proof matrix lacks generated-table markers")
    text = re.sub(re.escape(DERIVED_BEGIN) + r".*?" + re.escape(DERIVED_END), replacement, text, flags=re.S)
    path.write_text(text, encoding="utf-8")


def validate(root: Path) -> list[Finding]:
    out: list[Finding] = []

    def error(code: str, message: str, path: str | None = None) -> None:
        out.append(Finding("error", code, message, path))

    def warning(code: str, message: str, path: str | None = None) -> None:
        out.append(Finding("warning", code, message, path))

    # Required paths.
    for rel in sorted(REQUIRED_FILES):
        if not (root / rel).is_file():
            error("required-file-missing", f"Required file is missing: {rel}", rel)
    for name in sorted(REQUIRED_SCHEMAS):
        rel = f"spec/schemas/{name}"
        if not (root / rel).is_file():
            error("required-schema-missing", f"Required schema is missing: {rel}", rel)
    for name in sorted(REQUIRED_OCTON_SCHEMAS):
        rel = f"integrations/octon-mini-schemas/{name}"
        if not (root / rel).is_file():
            error("required-octon-schema-missing", f"Required proposed integration schema is missing: {rel}", rel)

    # Empty/placeholder files.
    for path in all_packet_files(root):
        rel = path.relative_to(root).as_posix()
        if path.stat().st_size == 0:
            error("empty-file", "File is empty", rel)
        if path.suffix.lower() in {".md", ".yaml", ".yml", ".json"} and path.name not in {CHECKSUM_NAME}:
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if re.search(r"(?im)^\s*TODO:\s*(define|write|fill|later|tbd)?\s*$", text):
                error("meaningless-placeholder", "Meaningless TODO placeholder found", rel)

    # Parse JSON/YAML strictly.
    parsed_json: dict[str, Any] = {}
    for path in sorted(root.rglob("*.json")):
        rel = path.relative_to(root).as_posix()
        try:
            parsed_json[rel] = strict_json_load(path)
        except Exception as exc:
            error("json-parse", str(exc), rel)
    parsed_yaml: dict[str, Any] = {}
    yaml_paths = sorted(set(root.rglob("*.yaml")) | set(root.rglob("*.yml")))
    for path in yaml_paths:
        rel = path.relative_to(root).as_posix()
        try:
            parsed_yaml[rel] = yaml_load(path)
        except Exception as exc:
            error("yaml-parse", str(exc), rel)

    # JSON Schema structural checks and ID/reference resolution.
    schema_paths = sorted(list((root / "spec/schemas").glob("*.schema.json")) + list((root / "integrations/octon-mini-schemas").glob("*.schema.json")))
    schema_ids: dict[str, str] = {}
    for path in schema_paths:
        rel = path.relative_to(root).as_posix()
        schema = parsed_json.get(rel)
        if not isinstance(schema, dict):
            continue
        try:
            Draft202012Validator.check_schema(schema)
        except Exception as exc:
            error("schema-invalid", str(exc), rel)
        schema_id = schema.get("$id")
        if not schema_id:
            error("schema-id-missing", "Schema lacks $id", rel)
        elif schema_id in schema_ids:
            error("schema-id-duplicate", f"Duplicate $id also used by {schema_ids[schema_id]}", rel)
        else:
            schema_ids[schema_id] = rel
        if schema.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
            error("schema-dialect", "Schema must declare JSON Schema Draft 2020-12", rel)

    def walk_refs(value: Any) -> Iterable[str]:
        if isinstance(value, dict):
            for key, child in value.items():
                if key == "$ref" and isinstance(child, str):
                    yield child
                yield from walk_refs(child)
        elif isinstance(value, list):
            for child in value:
                yield from walk_refs(child)

    for rel, schema in parsed_json.items():
        if not rel.endswith(".schema.json") or not isinstance(schema, dict):
            continue
        for ref in walk_refs(schema):
            base = ref.split("#", 1)[0]
            if not base or base.startswith("#"):
                continue
            if base.startswith("https://schemas.uca.dev/") or base.startswith("https://schemas.octon.dev/"):
                if base not in schema_ids:
                    error("schema-ref-unresolved", f"Unresolved schema reference: {ref}", rel)

    # Decisions and ADRs.
    decisions = parsed_yaml.get("design/decisions.yaml")
    if isinstance(decisions, dict):
        ids = [d.get("id") for d in decisions.get("decisions", [])]
        for dup, count in Counter(ids).items():
            if dup is None or count > 1:
                error("decision-id", f"Invalid or duplicate decision ID: {dup}", "design/decisions.yaml")
        valid_statuses = {"ESTABLISHED", "ACCEPTED", "PROPOSED", "DEFERRED", "REJECTED", "SUPERSEDED", "OPEN QUESTION"}
        for d in decisions.get("decisions", []):
            if d.get("status") not in valid_statuses:
                error("decision-status", f"Invalid status for {d.get('id')}: {d.get('status')}", "design/decisions.yaml")
    adr_ids = []
    for path in sorted((root / "design/adr").glob("adr-*.md")):
        match = re.search(r"adr-(\d{4})\.md$", path.name)
        if not match:
            error("adr-name", "ADR filename does not match adr-NNNN.md", path.relative_to(root).as_posix())
        else:
            adr_ids.append(match.group(1))
    for dup, count in Counter(adr_ids).items():
        if count > 1:
            error("adr-id-duplicate", f"Duplicate ADR number: {dup}")

    # Workstreams and tasks.
    workstreams_doc = parsed_yaml.get("agent/workstreams.yaml") or {}
    workstreams = workstreams_doc.get("workstreams", []) if isinstance(workstreams_doc, dict) else []
    ws_ids = [w.get("id") for w in workstreams]
    if len(ws_ids) != len(set(ws_ids)) or any(x is None for x in ws_ids):
        error("workstream-id", "Workstream IDs must be present and unique", "agent/workstreams.yaml")
    ws_set = set(ws_ids)
    for w in workstreams:
        for dep in w.get("depends_on", []):
            if dep not in ws_set:
                error("workstream-dependency", f"{w.get('id')} depends on unknown workstream {dep}", "agent/workstreams.yaml")

    task_doc = parsed_yaml.get("agent/tasks/index.yaml") or {}
    tasks = task_doc.get("tasks", []) if isinstance(task_doc, dict) else []
    task_ids = [t.get("id") for t in tasks]
    if len(task_ids) != len(set(task_ids)) or any(x is None for x in task_ids):
        error("task-id", "Task IDs must be present and unique", "agent/tasks/index.yaml")
    task_set = set(task_ids)
    for task in tasks:
        tid = task.get("id")
        if task.get("workstream") not in ws_set:
            error("task-workstream", f"{tid} references unknown workstream {task.get('workstream')}", "agent/tasks/index.yaml")
        for dep in task.get("dependencies", []):
            if dep not in task_set:
                error("task-dependency", f"{tid} depends on unknown task {dep}", "agent/tasks/index.yaml")
        packet = root / "agent/tasks" / f"{tid}.md"
        if not packet.is_file():
            error("task-packet-missing", f"Missing task packet for {tid}", packet.relative_to(root).as_posix())

    # Stage graph.
    graph_doc = parsed_yaml.get("agent/implementation-dependency-graph.yaml") or {}
    stages = graph_doc.get("stages", []) if isinstance(graph_doc, dict) else []
    stage_ids = [s.get("id") for s in stages]
    stage_set = set(stage_ids)
    if len(stage_ids) != len(stage_set):
        error("stage-id", "Stage IDs must be unique", "agent/implementation-dependency-graph.yaml")
    for stage in stages:
        for dep in stage.get("depends_on", []):
            if dep not in stage_set:
                error("stage-dependency", f"{stage.get('id')} depends on unknown stage {dep}", "agent/implementation-dependency-graph.yaml")
    for item in graph_doc.get("critical_path", []) if isinstance(graph_doc, dict) else []:
        if item not in stage_set:
            error("critical-path", f"Critical path references unknown stage {item}", "agent/implementation-dependency-graph.yaml")

    # Capability matrix and test-catalog release-gate resolution.
    matrix = parsed_yaml.get("spec/capability-matrix.yaml") or {}
    capabilities = matrix.get("capabilities", []) if isinstance(matrix, dict) else []
    cap_ids = [c.get("id") for c in capabilities]
    if len(cap_ids) != len(set(cap_ids)) or any(x is None for x in cap_ids):
        error("capability-id", "Capability IDs must be present and unique", "spec/capability-matrix.yaml")
    gates = [c.get("release_gate") for c in capabilities]
    if any(not x for x in gates):
        error("capability-gate-missing", "Every capability requires a release_gate", "spec/capability-matrix.yaml")
    if len(gates) != len(set(gates)):
        warning("capability-gate-shared", "Multiple capabilities share a release gate; verify this is intentional", "spec/capability-matrix.yaml")

    catalog = parsed_yaml.get("evals/test-catalog.yaml") or {}
    tests = catalog.get("tests", []) if isinstance(catalog, dict) else []
    test_ids = [t.get("id") for t in tests]
    if len(test_ids) != len(set(test_ids)) or any(x is None for x in test_ids):
        error("test-id", "Test IDs must be present and unique", "evals/test-catalog.yaml")
    tests_by_gate: dict[str, list[str]] = defaultdict(list)
    for test in tests:
        if test.get("release_gate"):
            tests_by_gate[test["release_gate"]].append(test.get("id"))
    for cap in capabilities:
        gate = cap.get("release_gate")
        if gate and gate not in tests_by_gate:
            error("release-gate-unresolved", f"Capability {cap.get('id')} gate {gate} has no test-catalog record", "spec/capability-matrix.yaml")
    required_suites = set(catalog.get("required_release_suites", [])) if isinstance(catalog, dict) else set()
    required_gates = {c.get("release_gate") for c in capabilities if c.get("v1_target_depth") not in {"preview", "deferred", "none"}}
    missing_required = {ids[0] for gate, ids in tests_by_gate.items() if gate in required_gates and ids} - required_suites
    if missing_required:
        warning("required-suite-list", f"Non-preview capability tests missing from required_release_suites: {sorted(missing_required)}", "evals/test-catalog.yaml")

    # Agent Skills.
    for skill_name in ("uca-audit", "uca-simplify"):
        path = root / "skills" / skill_name / "SKILL.md"
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        if not text.startswith("---\n"):
            error("skill-frontmatter", "SKILL.md must start with YAML frontmatter", path.relative_to(root).as_posix())
            continue
        try:
            _, fm, _body = text.split("---", 2)
            meta = yaml.safe_load(fm)
        except Exception as exc:
            error("skill-frontmatter", str(exc), path.relative_to(root).as_posix())
            continue
        if meta.get("name") != skill_name:
            error("skill-name", f"Skill name must equal directory name {skill_name}", path.relative_to(root).as_posix())
        if not meta.get("description"):
            error("skill-description", "Skill requires a description", path.relative_to(root).as_posix())
        for ref in re.findall(r"\]\((references/[^)#]+)", text):
            if not (path.parent / ref).is_file():
                error("skill-reference", f"Missing skill reference {ref}", path.relative_to(root).as_posix())

    # Transcript coverage.
    transcript = root / "reference/conversation-thread.md"
    if transcript.is_file():
        text = transcript.read_text(encoding="utf-8")
        turns = re.findall(r"^## Turn (\d{3})\s*$", text, re.M)
        if len(turns) < 20:
            error("transcript-incomplete", f"Expected at least 20 visible UCA turns; found {len(turns)}", "reference/conversation-thread.md")
        if turns and [int(x) for x in turns] != list(range(1, len(turns) + 1)):
            error("transcript-numbering", "Conversation turns are not contiguous from 001", "reference/conversation-thread.md")

    # Local Markdown links (conservative file-path check).
    link_re = re.compile(r"\[[^\]]*\]\(([^)]+)\)")
    for path in sorted(root.rglob("*.md")):
        rel = path.relative_to(root).as_posix()
        text = path.read_text(encoding="utf-8")
        for target in link_re.findall(text):
            target = target.strip().split("#", 1)[0]
            if not target or target.startswith(("http://", "https://", "mailto:", "uca://")):
                continue
            if any(ch in target for ch in "{}<>"):
                continue
            candidate = (path.parent / target).resolve()
            try:
                candidate.relative_to(root.resolve())
            except ValueError:
                error("markdown-link-escape", f"Local link escapes packet root: {target}", rel)
                continue
            if not candidate.exists():
                error("markdown-link-missing", f"Missing local link target: {target}", rel)

    # Manifest and checksums.
    manifest_path = root / MANIFEST_NAME
    if manifest_path.is_file():
        manifest = parsed_json.get(MANIFEST_NAME)
        if isinstance(manifest, dict):
            manifest_paths = [f.get("path") for f in manifest.get("files", [])]
            if len(manifest_paths) != len(set(manifest_paths)):
                error("manifest-duplicate-path", "Manifest contains duplicate paths", MANIFEST_NAME)
            expected_paths = [p.relative_to(root).as_posix() for p in all_packet_files(root, include_integrity=False)]
            if manifest_paths != expected_paths:
                missing = sorted(set(expected_paths) - set(manifest_paths))
                extra = sorted(set(manifest_paths) - set(expected_paths))
                error("manifest-paths", f"Manifest paths differ; missing={missing}, extra={extra}", MANIFEST_NAME)
            by_path = {f.get("path"): f for f in manifest.get("files", [])}
            for rel in expected_paths:
                rec = by_path.get(rel)
                if not rec:
                    continue
                path = root / rel
                if rec.get("sha256") != sha256_file(path):
                    error("manifest-hash", "Manifest hash mismatch", rel)
                if rec.get("bytes") != path.stat().st_size:
                    error("manifest-size", "Manifest size mismatch", rel)

    checksum_path = root / CHECKSUM_NAME
    if checksum_path.is_file():
        records: dict[str, str] = {}
        for line_no, line in enumerate(checksum_path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
            if not match:
                error("checksum-format", f"Invalid checksum line {line_no}", CHECKSUM_NAME)
                continue
            digest, rel = match.groups()
            if rel in records:
                error("checksum-duplicate", f"Duplicate checksum path {rel}", CHECKSUM_NAME)
            records[rel] = digest
        expected_paths = [p.relative_to(root).as_posix() for p in all_packet_files(root, include_integrity=True) if p.name != CHECKSUM_NAME]
        if set(records) != set(expected_paths):
            error("checksum-paths", f"Checksum paths differ; missing={sorted(set(expected_paths)-set(records))}, extra={sorted(set(records)-set(expected_paths))}", CHECKSUM_NAME)
        for rel, digest in records.items():
            path = root / rel
            if path.is_file() and sha256_file(path) != digest:
                error("checksum-mismatch", "Checksum mismatch", rel)

    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--json", action="store_true", dest="json_output")
    parser.add_argument("--refresh-derived", action="store_true")
    parser.add_argument("--write-manifest", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()

    if args.refresh_derived:
        refresh_capability_gate_table(root)
    if args.write_manifest:
        # Manifest must be written after derived documents; checksums include it.
        write_manifest_and_checksums(root)

    findings = validate(root)
    counts = Counter(f.level for f in findings)
    result = {
        "packet": PACKET_NAME,
        "version": PACKET_VERSION,
        "root": str(root),
        "validated_at": datetime.now(timezone.utc).isoformat(),
        "passed": counts["error"] == 0,
        "counts": {"errors": counts["error"], "warnings": counts["warning"], "info": counts["info"]},
        "findings": [f.as_dict() for f in findings],
    }
    if args.json_output:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        for f in findings:
            where = f" [{f.path}]" if f.path else ""
            print(f"{f.level.upper():7} {f.code}{where}: {f.message}")
        print(f"Packet validation: {'PASS' if result['passed'] else 'FAIL'} — {counts['error']} error(s), {counts['warning']} warning(s).")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
