# UCA Evaluation Fixtures

This directory is reserved for executable evaluation subjects and fixture manifests. The build packet intentionally does not vendor large third-party repositories or executable analyzer toolchains.

## Required fixture groups

```text
fixtures/
├── golden/             known positive and negative UCA outcomes
├── near-miss/          finding-shaped cases that must be rejected or retained
├── adversarial/        hostile repository and input cases
├── partial/            unavailable, denied, timeout, unsupported, stale cases
├── bundles/            valid and corrupted Audit Bundles
├── histories/          synthetic Git histories for churn/co-change/ownership
├── languages/          Rust, Python, TypeScript/JavaScript, and Go subjects
├── skills/             Agent Skill behavioral repositories and prompts
└── real-repositories/  manifest-only references to pinned external repositories
```

## Fixture manifest contract

Every fixture group MUST identify:

- fixture ID and version;
- source and license;
- exact content digest or repository commit;
- intended capability and test-catalog IDs;
- expected observations, candidates, rejections, findings, and completion;
- permitted project execution and network behavior;
- cleanup requirements;
- sensitivity classification;
- known limitations.

Real external repositories SHOULD be fetched into an isolated evaluation cache from an exact commit and verified against a manifest digest. They SHOULD NOT be copied into this specification packet without a deliberate licensing and size decision.

## Ground-truth ownership

Expected results are governed test data. Changes require review from the capability owner and Evaluation Lead. A detector regression MUST NOT be “fixed” by silently weakening fixture expectations.
