# Completion and Claims

## Audit states

- `complete`: required capabilities and accepted scope completed without material undeclared limitation.
- `complete_with_limitations`: required work completed, but optional omissions/blind spots qualify interpretation.
- `partial`: required scope/capability/evidence did not complete; partial evidence is usable.
- `failed`: no trustworthy usable result for the request.
- `cancelled`: execution ended by cancellation.

## Node states

`succeeded`, `failed`, `unavailable`, `skipped`, `timed_out`, `cancelled` are distinct. Only `succeeded` means the operation ran and its output passed protocol validation.

## Truthful language

Use:

- “No findings were produced in the analyzed changed-code scope.”
- “The audit completed with limitations: runtime evidence was not requested.”
- “The result is partial because the required Python indexer timed out.”

Do not use:

- “The repository is clean.”
- “The scanner passed” when it was missing, disabled, denied, or timed out.
- “All issues were found.”
- “UCA verified performance” when only static evidence exists.

A finding count of zero never substitutes for completion and coverage review.
