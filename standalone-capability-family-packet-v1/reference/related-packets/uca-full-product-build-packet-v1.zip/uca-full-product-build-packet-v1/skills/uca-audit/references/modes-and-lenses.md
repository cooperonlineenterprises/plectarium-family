# Modes and Lenses

## Continuous

Use for diffs, pull requests, branches, and local changes. Scope changed and affected entities. Keep execution/network denied unless explicitly required. Deterministic selected regressions may be gateable.

## Periodic

Use for repository/subsystem health. Includes broader history, graphs, temporal coupling, ownership, near duplication, dead weight, dependency lifecycle, tests, architecture drift, and simplification.

## Investigative

Use for an explicit finding or hypothesis. Name the workload/subject, required evidence, permissions, resource budget, and success/stop conditions. Profiling, tracing, race detection, fuzzing, mutation, fault injection, or semantic analysis may be appropriate only after authorization.

## Lenses

A lens changes planning and report emphasis over shared evidence. It is not a separate engine. Available or expected lenses include full-spectrum, Reduction, architecture, dependency health, testing, reliability, security, performance, dead weight, API/domain modeling, and state/concurrency.

Every focused audit must say what it did not analyze. A complete Reduction audit is not a complete security audit.
