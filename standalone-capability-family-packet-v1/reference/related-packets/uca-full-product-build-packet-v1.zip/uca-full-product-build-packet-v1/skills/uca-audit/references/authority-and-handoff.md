# Authority and Handoff

UCA may recommend, but it cannot:

- edit or commit code;
- install dependencies/tools;
- create issues/tasks/waivers;
- approve a design;
- merge, deploy, publish, or communicate externally.

A project or harness may separately use UCA evidence in its governance. With Octon Mini:

```text
Octon task decides audit need and authority
→ exact UCA provider request/plan
→ UCA Audit Bundle
→ Octon validates revision, digest, completion, provenance
→ human/agent reviews finding
→ separate decision/task authorizes implementation if accepted
```

Keep the bundle reference canonical. Do not copy a finding into harness state as new independent truth when a durable reference is sufficient.
