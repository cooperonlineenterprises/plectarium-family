# Finding Cards

Present the audit qualification first, then cards ordered by UCA priority and project relevance.

```text
P1 · concise label

Finding
<what was established>

Evidence
<finding ID and observation/validation references>

Scope
<coverage, revision, external-consumer or workload limits>

Consequence
<why it matters here>

Recommendation
<smallest plausible response; no authority implied>

Expected benefit
<measured or clearly labeled estimate>

Confidence
<strength, coverage, freshness, reproducibility, conflicts>

Risk
<change/migration/regression risk>

Validate
<how remediation would be proven>
```

For Reduction findings include applicable safety floors. `retain` and `investigate` are valid cards. Do not paste raw evidence when a reference and focused explanation suffice.
