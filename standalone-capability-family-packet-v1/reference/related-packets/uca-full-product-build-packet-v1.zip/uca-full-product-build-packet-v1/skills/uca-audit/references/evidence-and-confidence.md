# Evidence and Confidence

## Evidence classes

Keep deterministic static/contract, external tool, heuristic, historical, runtime, imported human, AI interpretation, derived fusion, and unavailability evidence distinct.

## Read a finding in this order

1. Finding statement.
2. Repository identity and scope.
3. Direct observations and producer identities.
4. Candidate validation/refutation outcome.
5. Supporting and contradicting evidence.
6. Confidence vector: strength, precision, coverage, freshness, reproducibility, inference distance, independent sources, conflicts.
7. Consequence and recommendation.
8. Validation strategy and change risk.

AI model self-confidence is not UCA evidence strength. Runtime evidence proves only the declared workload/environment. A deterministic detector proves only what its extraction model sees.

When evidence conflicts, state the conflict. Do not average it into “medium confidence.”
