---
name: uca-simplify
description: Use when asked what code, behavior, dependencies, state, configuration, compatibility machinery, abstractions, layers, build steps, deployment units, or concepts a codebase can safely stop carrying.
license: License decision pending; see ../../OPEN-QUESTIONS.md
compatibility: Requires a compatible Universal Code Audit CLI or UCA MCP server. Produces evidence and recommendations only; it does not refactor or mutate repositories.
metadata:
  author: Universal Code Audit project
  version: "1.0.0-spec"
---

# Use UCA's Reduction Lens

The Reduction lens identifies removable conceptual and operational weight while preserving required behavior and non-reducible safety floors. It is not code golf and it does not apply changes.

## Boundary

- Understand before recommending removal.
- A smaller implementation is not automatically simpler or safer.
- Unknown high-impact safety evidence means investigate, not delete.
- Necessary correctness, security, privacy, accessibility, reliability, compatibility, observability, performance, legal, and operational mechanisms are justified complexity.
- Do not install replacement dependencies or edit code.

## Workflow

### 1. Establish exact scope and required behavior

Determine whether the request concerns changed code, a subsystem, or a repository-wide Periodic audit. Identify current requirements, consumers, supported versions/platforms, project decisions, and migration state.

### 2. Invoke the canonical Reduction lens

CLI shape:

```bash
uca plan --repo . --tier periodic --lens reduction --output reduction-plan.json
uca audit \
  --plan reduction-plan.json \
  --accept-plan-digest sha256:... \
  --bundle-out /explicit/output/path
```

Use equivalent MCP operations when appropriate. Review execution rights before running.

### 3. Inspect completion and capability coverage

Reduction conclusions may require history, graphs, dependency inventory, reachability, tests, runtime evidence, or semantic validation. Missing capability is not proof of removability.

### 4. Apply the decision ladder

Read [the Reduction ladder](references/reduction-ladder.md). Stop at the earliest evidence-supported outcome. `retain` and `investigate` are successful outcomes.

### 5. Evaluate the safety floor

Read [the safety floor](references/safety-floor.md). A violated floor rejects the candidate. An unknown high-impact floor produces investigation.

### 6. Inspect evidence requirements

Use [Reduction evidence](references/reduction-evidence.md). Do not recommend:

- dead-code deletion without dynamic/public/config/reflection uncertainty;
- de-abstraction without checking independent boundaries;
- standard-library/native replacement without version and semantic compatibility;
- dependency removal without build/runtime/operational use;
- state removal without ownership, source-of-truth, migration, and rollback.

### 7. Present the highest-value removable weight first

Use [Reduction cards](references/reduction-cards.md). Rank conceptual/operational reduction with UCA priority—not raw lines deleted.

### 8. Hand off rather than implement

State that findings are recommendations. Remediation must enter the project's normal decision, implementation, migration, and validation workflow.

## Stop conditions

Stop at `investigate` or reject when:

- required behavior/consumer status is unknown;
- a security/correctness/compatibility/operational floor is unknown at high impact;
- the proposed replacement changes semantics;
- performance evidence contradicts the simpler version;
- duplication is intentionally independent;
- an abstraction carries a demonstrated boundary;
- UCA completion is partial for required Reduction evidence.
