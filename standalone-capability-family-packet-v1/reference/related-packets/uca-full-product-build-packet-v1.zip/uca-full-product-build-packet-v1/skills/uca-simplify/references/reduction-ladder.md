# Reduction Ladder

Evaluate in order:

```text
0. Establish required behavior, consumers, invariants, and safety floors.
1. Remove behavior no longer required.
2. Delete unreachable, obsolete, duplicated, or superseded implementation.
3. Reuse an existing project capability.
4. Use standard-library/runtime capability where appropriate.
5. Use native platform capability where appropriate.
6. Reuse an already-adopted dependency when it lowers total ownership.
7. Consolidate duplicated rules, schemas, transforms, knowledge, or config.
8. Remove dependencies made unnecessary.
9. Remove unnecessary, duplicate, or derivable state.
10. Remove unnecessary configuration.
11. Collapse pass-through layers lacking independent responsibility.
12. De-abstract concepts whose separation creates cost without value.
13. Simplify the remaining implementation.
14. Retain the current design when complexity is justified.
15. Add new machinery only when evidence warrants it.
```

Actions are `remove`, `reuse`, `consolidate`, `collapse`, `simplify`, `retain`, or `investigate`. Targets and replacements are recorded separately; concise labels are only presentation.
