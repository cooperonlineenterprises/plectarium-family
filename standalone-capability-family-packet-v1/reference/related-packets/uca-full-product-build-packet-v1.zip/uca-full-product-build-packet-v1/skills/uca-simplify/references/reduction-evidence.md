# Reduction Evidence Requirements

| Proposed reduction | Minimum evidence |
|---|---|
| Remove behavior | Requirement, consumer, compatibility, usage and ownership/policy evidence |
| Delete dead code | Static reachability plus reflection/config/public/external/runtime uncertainty |
| Reuse project capability | Semantic equivalence, support contract, ownership and behavior differences |
| Standard/runtime/native replacement | Supported versions/platforms, semantics, errors, security, performance, operations |
| Remove dependency | Direct/transitive/build/test/runtime/operational use, SBOM, security/license and artifact effects |
| Remove state | Source of truth, writers/readers, derivability, consistency, migration and rollback |
| Remove configuration | Environment/consumer inventory, defaults, rollout and compatibility |
| Collapse/de-abstract | Caller topology, implementations, pass-through evidence, independent security/test/runtime/ownership/compatibility/policy roles |
| Remove compatibility | Consumer/traffic evidence, support policy, migration status and fallback |

A missing evidence source is a limitation, not affirmative proof.
