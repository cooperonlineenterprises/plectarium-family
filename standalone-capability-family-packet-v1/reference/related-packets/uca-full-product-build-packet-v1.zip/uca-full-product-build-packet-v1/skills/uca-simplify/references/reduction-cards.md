# Reduction Finding Cards

Use the ordinary UCA card plus:

```text
Action / target / replacement
Expected reduction vector
Safety-floor status
Justified-complexity result when retained
```

Useful reduction dimensions include files/lines, dependencies and transitives, public symbols, configuration keys, mutable state stores, serialization boundaries, layers, build steps, deployment units, duplicated rules, concepts, and change surface.

Never imply these estimates were achieved unless a post-remediation audit measured them.
