# Reduction Safety Floor

Evaluate applicable dimensions:

- required behavior;
- correctness;
- data integrity;
- security;
- privacy;
- accessibility;
- reliability;
- compatibility;
- observability;
- performance;
- legal/regulatory obligations;
- operational safety.

Statuses:

```text
verified_preserved
strongly_indicated_preserved
unknown
violated
not_applicable
```

Rules:

```text
violated → reject reduction
unknown + high impact → investigate
strongly indicated → recommend only with explicit validation
verified → strongest basis, still validate implementation
```

AI-only interpretation cannot mark a high-impact floor verified.
