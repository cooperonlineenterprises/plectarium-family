# Universal Code Audit Target Architecture

**Authority:** Reference architecture constrained by normative specifications  
**Status:** `ACCEPTED`  
**Implementation direction:** Rust 2024 workspace, one engine, thin interfaces

## 1. Architectural objective

The architecture must support a powerful full product without turning UCA into a mega-analyzer, agent platform, or governance system. The stable center is an authoritative audit engine and durable Audit Bundle. Interfaces, adapters, language packs, and semantic providers attach around that center.

```mermaid
flowchart TB
    subgraph Consumers
      Human[Human developer]
      Agent[Coding agent]
      CIPlatform[CI platform]
      Harness[Harness / Octon Mini]
    end

    subgraph Interfaces
      CLI[Canonical CLI]
      CI[CI adapter]
      MCP[MCP server]
      OCI[OCI entrypoint]
      HTTP[Future HTTP service]
      Skills[Agent Skills]
    end

    subgraph Engine[Authoritative UCA Engine]
      App[Application services]
      Kernel[Audit kernel]
      Repo[Repository intelligence]
      Graph[Graph intelligence]
      Evidence[Evidence + candidate + finding system]
      Bundle[Audit Bundle writer / reader]
    end

    subgraph Providers
      Native[Built-in deterministic analyses]
      Lang[Language packs]
      Adapters[External analyzer adapters]
      Runtime[Runtime evidence importers]
      Semantic[Optional AI providers]
    end

    subgraph Storage
      CAS[Content-addressed store]
      Index[SQLite metadata index]
      Artifacts[Bundles / baselines / reports]
    end

    Human --> CLI
    Agent --> Skills --> CLI
    Agent --> MCP
    CIPlatform --> CI --> CLI
    Harness --> CLI
    Harness --> OCI
    CLI --> App
    MCP --> App
    OCI --> App
    HTTP --> App
    App --> Kernel
    Kernel --> Repo
    Kernel --> Graph
    Kernel --> Native
    Kernel --> Lang
    Kernel --> Adapters
    Kernel --> Runtime
    Kernel --> Semantic
    Repo --> Evidence
    Graph --> Evidence
    Native --> Evidence
    Lang --> Evidence
    Adapters --> Evidence
    Runtime --> Evidence
    Semantic --> Evidence
    Evidence --> Bundle
    Bundle --> CAS
    Bundle --> Index
    Bundle --> Artifacts
```

## 2. Layer model

### 2.1 Interfaces

Interfaces translate user or protocol requests into canonical engine requests and project canonical results into interface-specific forms. They do not implement audit meaning.

- **CLI:** canonical human and automation surface.
- **CI:** thin setup/invocation/artifact integration.
- **MCP:** typed read-only protocol surface over engine operations and bundles.
- **OCI/container:** reproducible execution boundary and distribution form.
- **Future HTTP:** queued remote execution using the same request and bundle contracts.
- **Agent Skills:** teach agents when and how to invoke UCA and interpret completion; they do not contain analyzer logic.

### 2.2 Application services

Application services expose stable operations:

```text
discover
plan
audit
inspect
explain
compare
report
doctor
schema
adapter management
cache management
```

They coordinate the kernel and are reusable from CLI, MCP, OCI, and future HTTP interfaces.

### 2.3 Audit kernel

The kernel owns:

- request validation;
- repository identity and scope binding;
- capability resolution;
- deterministic audit planning;
- execution DAG and policy checks;
- analyzer-run state;
- normalization dispatch;
- evidence-graph construction;
- candidate generation;
- validation and attempted refutation;
- stable finding generation;
- confidence and priority calculation;
- waiver application;
- comparison and completion;
- bundle finalization.

The kernel does not own domain-specific deep static analysis already provided by stronger external tools.

### 2.4 Repository intelligence

Repository intelligence owns language-neutral and broadly applicable facts:

- file and content inventory;
- manifests and lockfiles;
- generated, vendor, test, fixture, migration, and binary classification;
- Git history, churn, authorship, ownership concentration, reverts, and co-change;
- exact duplication;
- file/module dependency structure where reliably extractable;
- repository topology and project boundaries;
- baseline and revision comparison.

### 2.5 Graph intelligence

UCA maintains typed graphs rather than one universal dependency graph:

- file;
- module;
- package;
- symbol;
- call;
- type;
- data-flow;
- co-change;
- ownership;
- evidence.

Every node and edge records its producer, resolution method, subject revision, and confidence. A heuristic syntax-derived call edge must remain distinguishable from a compiler-resolved edge.

### 2.6 Language packs

Language packs supply detection, syntax and semantic extraction, native-tool integration, entry-point roots, framework knowledge, and known blind spots. They conform to a common capability contract without claiming equal depth.

Initial target depth:

- Rust: deep.
- Python: deep within the limits of dynamic behavior.
- TypeScript/JavaScript: useful v1, with stronger semantics when TypeScript indexing is available.
- Go: useful v1, with strong native tooling integration.

### 2.7 External adapters

Adapters run out of process or in OCI boundaries. They declare capabilities, versions, required access, network use, project execution, resource needs, cache semantics, output formats, and limitations. UCA never loads arbitrary analyzer libraries into its trusted core process.

### 2.8 Evidence, candidate, and finding system

This subsystem owns the canonical transition:

```text
raw evidence
→ normalized observation
→ evidence graph
→ candidate
→ validation / attempted refutation
→ rejected candidate or finding
→ consequence / recommendation / confidence / priority
```

It preserves contradictory and rejected evidence instead of erasing it.

### 2.9 Persistence

- **Content-addressed blob store:** immutable evidence and bundle content.
- **SQLite index:** mutable local lookup and cache metadata, not canonical evidence.
- **Audit Bundles:** durable, portable results.
- **Baselines:** references to compatible prior bundles.
- **Reports:** projections derived from bundles.

## 3. Canonical control flow

```mermaid
sequenceDiagram
    participant C as Caller
    participant A as Application Service
    participant R as Repository Identity
    participant P as Planner
    participant E as Executor
    participant N as Normalizers
    participant F as Evidence/Finding Engine
    participant B as Bundle Store

    C->>A: AuditRequest
    A->>R: Identify repository + scope
    R-->>A: RepositoryIdentity + Scope
    A->>P: Resolve capabilities and plan
    P-->>A: Immutable AuditPlan + digest
    C->>A: Accept exact plan / run
    A->>E: Execute DAG under policy
    E-->>N: Raw evidence + run outcomes
    N-->>F: Normalized observations
    F->>F: candidates, validation, refutation, findings
    F-->>B: completion + evidence graph + findings
    B-->>C: Audit Bundle reference and digest
```

## 4. Component ownership and forbidden leakage

| Component | Owns | Must not own |
|---|---|---|
| CLI | command parsing, I/O projection, exit mapping | audit semantics, analyzer-specific logic |
| CI integration | setup, invocation, artifact publication | finding identity, bundle semantics |
| MCP | protocol translation, pagination, tasks | separate planner or cache |
| Planner | capability selection, DAG, permissions, budgets | execution side effects |
| Executor | bounded task execution | finding interpretation |
| Adapter | exact tool invocation and normalization | UCA policy or authority |
| Language pack | language semantics and native tools | global priority policy |
| Evidence engine | observation relationships and derivations | project decisions |
| Finding engine | stable findings and lifecycle | remediation execution |
| Report engine | projections | canonical evidence storage |
| Octon integration | provider invocation governance | UCA analysis implementation |

## 5. Minimum Complete Architecture

The Minimum Complete Architecture proves all fundamental relationships:

```text
repository identity
→ discovery
→ capability resolution
→ request
→ deterministic plan
→ constrained execution
→ raw evidence
→ normalized observation
→ candidate
→ validation/refutation
→ finding
→ truthful completion
→ Audit Bundle
→ inspect
→ compare
```

This is not the release ambition. Once proven, repository intelligence, language packs, adapters, Reduction, CI, MCP, OCI, Agent Skills, and production hardening may proceed rapidly in parallel according to the dependency graph.

## 6. Technology direction

The accepted implementation direction is a Rust 2024 workspace because UCA needs portable native binaries, memory safety, predictable resource use, typed contracts, and cross-platform process control. JSON Schema 2020-12 defines external data contracts; TOML defines human-authored project configuration; SHA-256 and RFC 8785 canonical JSON provide public content identity; SQLite indexes local metadata; zstd compresses large graph and bundle artifacts.

Crate boundaries remain implementation suggestions until actual coupling is understood. Normative semantics live in `spec/` and `spec/schemas/`, not in a speculative crate diagram.

## 7. Future hosted architecture

A hosted service may later provide queues, managed toolchains, organization baselines, shared caches, and centralized reporting. It must execute the same engine and produce the same bundle model. Local operation remains first-class and must not become a degraded client of the service.

## 8. Standalone-capability reference role

UCA is the first proving ground for a reusable standalone-capability pattern. The project may extract provisional conventions for manifests, planning, completion, durable results, Agent Skills, OCI, and harness providers. It must not prematurely create a universal platform before a second independent capability demonstrates which conventions are genuinely generic.
