# UCA AI Engineering Team Build Directive

**Authority:** Governance  
**Status:** `ESTABLISHED`

## Mission

Build the mature Universal Code Audit v1 defined by this packet. Do not re-discover or silently redefine the product. Validate the authority set, surface genuine conflicts, and implement the full production-shaped capability in dependency order.

## Governing product position

> UCA is an independent, harness-agnostic code-audit and repository-intelligence product. It produces evidence and recommendations, not authority.

The implementation must remain useful without Octon Mini, an agent harness, MCP, AI, network, or hosted service.

## Authority hierarchy

```text
CHARTER.md
→ spec/invariants.md
→ normative specifications and schemas
→ accepted ADRs
→ capability matrix and release criteria
→ workstreams
→ task packet
→ local implementation choice
```

When instructions conflict, stop at the conflict boundary and open an architecture-change proposal. Never solve an implementation inconvenience by quietly weakening a higher-level contract.

## Development philosophy

Build the full-capability product in dependency order. The Minimum Complete Architecture proves the entire vertical lifecycle and unlocks parallel breadth; it is not the final product target.

```text
stabilize contracts
→ Minimum Complete Architecture
→ parallel repository/language/adapter intelligence
→ fusion and Reduction depth
→ CLI/CI/MCP/OCI equivalence
→ Agent Skills and integrations
→ production hardening and release proof
```

## Required workflow

1. Read the assigned task packet and all authority it references.
2. Confirm dependencies are complete and compatible.
3. Restate the task’s product claim and the test that would falsify it.
4. Produce a design note when public semantics or cross-workstream interfaces are involved.
5. Implement only within the permitted architectural surface.
6. Add claim-oriented tests, including near-miss and failure cases.
7. Run the required validations freshly.
8. Record exact evidence: commands, versions, exit results, artifacts, benchmarks, limitations.
9. Check no higher-level contract was weakened.
10. Submit a handoff identifying changed interfaces, residual risks, and dependent work now unblocked.

## Completion truth

An agent may not claim a task complete because code was written or tests “should” pass. Completion requires:

- required outputs exist;
- acceptance criteria are demonstrably satisfied;
- required tests and validators ran freshly;
- no unexplained failures or skipped required checks;
- evidence artifacts are attached or referenced;
- documentation/schemas/fixtures are synchronized;
- integration consumers are not broken;
- limitations are stated.

## Architectural freedom

Agents may choose internal algorithms, crate decomposition, libraries, storage representation, optimization, and test implementation where not normatively constrained. Changes to evidence meaning, completion, finding identity, bundle, permissions, adapter protocol, public CLI/MCP, or provider contracts require explicit change control.

## Prohibited shortcuts

- Reimplementing UCA logic in a skill, CI wrapper, or MCP server.
- Treating unavailable tools as passing.
- Installing dependencies or enabling network silently.
- Using AI output as deterministic evidence.
- Mutating audit targets to simplify implementation.
- Creating a global health score because it is easy to display.
- Dropping rejected candidates or conflicting evidence.
- Adding broad abstractions for hypothetical future capabilities.
- Marking a capability supported without its named proof gate.

## Technology direction

Current accepted direction is a Rust 2024 workspace with ordinary files for durable bundle artifacts, a content-addressed blob store, SQLite for local metadata/indexing, JSON Schema 2020-12, RFC 8785 canonical JSON, SHA-256 identities, and out-of-process/OCI adapters. Internal crate boundaries are reference architecture, not immutable law.

## Dogfooding with Octon Mini

Octon Mini may govern tasks, decisions, evidence, and resumability for the UCA development process. UCA source and runtime must not depend on Octon. The independence thought experiment in `CHARTER.md` is a release requirement.
