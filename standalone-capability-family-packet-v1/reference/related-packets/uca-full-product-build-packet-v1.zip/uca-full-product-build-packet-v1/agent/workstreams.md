# UCA Workstreams

**Authority:** Governance / implementation ownership  
**Machine source:** [`workstreams.yaml`](workstreams.yaml)

| ID | Workstream | Owner role | Depends on |
|---|---|---|---|
| `WS-ARCH` | Architecture and Integration | Architecture / Integration Lead | None |
| `WS-SCHEMA` | Schemas and Compatibility | Evidence/Schema Lead | WS-ARCH |
| `WS-KERNEL` | Audit Kernel | Audit Kernel Lead | WS-SCHEMA, WS-SECURITY |
| `WS-EVIDENCE` | Evidence, Candidates, Findings | Evidence / Finding Lead | WS-SCHEMA |
| `WS-REPO` | Repository Identity and Discovery | Repository Intelligence Lead | WS-SCHEMA, WS-SECURITY |
| `WS-INTEL` | Repository/Graph/History Intelligence | Repository Intelligence Lead | WS-REPO, WS-EVIDENCE |
| `WS-LANG-RUST` | Rust Language Pack | Rust Language Specialist | WS-REPO, WS-SCHEMA |
| `WS-LANG-PY` | Python Language Pack | Python Language Specialist | WS-REPO, WS-SCHEMA |
| `WS-LANG-JSGO` | TypeScript/JavaScript and Go Packs | Language Pack Specialists | WS-REPO, WS-SCHEMA |
| `WS-ADAPTER` | Adapters and External Evidence | Adapter Lead | WS-SCHEMA, WS-SECURITY, WS-KERNEL |
| `WS-SECURITY` | Execution and Product Security | Execution / Security Lead | WS-ARCH |
| `WS-REDUCTION` | Reduction and Simplification | Reduction Lead | WS-EVIDENCE, WS-INTEL |
| `WS-INTERFACE` | CLI, CI, MCP, Reporting | Interface Lead | WS-KERNEL, WS-EVIDENCE, WS-BUNDLE |
| `WS-BUNDLE` | Bundle, Cache, and Provenance | Artifact Lead | WS-SCHEMA, WS-EVIDENCE |
| `WS-OCI` | OCI and Release Supply Chain | Distribution Lead | WS-SECURITY, WS-INTERFACE |
| `WS-SKILLS` | Agent Skills and Portability | Agent Skill Lead | WS-INTERFACE |
| `WS-EVAL` | Verification and Evaluation | Verification Lead | WS-SCHEMA |
| `WS-INTEGRATION` | External Provider and Octon Integration | Integration Lead | WS-INTERFACE, WS-OCI, WS-SKILLS |

Workstreams own implementation and evidence within their declared boundary. They do not own the right to redefine higher-level contracts. `synchronizes_with: all` means the Architecture or Evaluation workstream maintains cross-cutting checkpoints, not that all tasks are serial.

## Synchronization points

1. **Foundation contract freeze:** schema IDs, repository/scope, permissions, completion, evidence, candidate, finding, bundle identity.
2. **Minimum Complete Architecture:** one vertical request-to-bundle path with validation/refutation and compare.
3. **Native intelligence integration:** repository/history/graph/language observations normalize through the same model.
4. **External evidence integration:** adapters demonstrate unavailability, malicious output, and provenance behavior.
5. **Interface equivalence:** CLI, CI, MCP, and OCI produce semantically equivalent results.
6. **Release proof freeze:** capability matrix and claim-proof matrix agree.
