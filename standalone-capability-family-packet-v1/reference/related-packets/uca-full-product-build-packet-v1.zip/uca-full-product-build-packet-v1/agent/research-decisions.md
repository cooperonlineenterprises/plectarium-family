# Research-Derived Decisions

**Classification:** Governance synthesis  
**Canonical authority:** `DECISIONS.md`, accepted ADRs, and normative specifications.

## Distilled workflow

```text
understand before judging
→ produce candidates
→ attempt to refute them
→ preserve rejected evidence
→ inspect completion before claiming success
→ load only the context needed
→ present highest-value findings concisely
→ separate recommendation from authority
```

## Mechanism dispositions

| Mechanism | Disposition | UCA location | Rationale |
|---|---|---|---|
| Candidate → validation/refutation → finding | **ADOPT** | Engine evidence/finding lifecycle | Reduces false positives and preserves inference boundaries. |
| Rejected candidate evidence | **ADOPT** | Audit Bundle and evaluation | Supports detector improvement and explains absence of final finding. |
| First-class Reduction lens | **ADOPT** | Planner, fusion, findings, reports, skill | Unifies deletion, reuse, de-abstraction, state/config/dependency reduction. |
| Non-reducible safety floor | **ADOPT** | Reduction validation | Prevents negligent simplification. |
| Completion-truth gate | **ADOPT** | Completion schema, interfaces, skills | Prevents clean/pass claims after partial analysis. |
| No-skill-controlled skill evaluation | **ADOPT** | Agent Skill release gates | Measures behavioral contribution instead of prompt existence. |
| Stable rule/taxonomy IDs and fixtures | **ADOPT** | Finding taxonomy and evaluation | Enables comparison and conformance. |
| Concise finding cards | **ADOPT** | Reporting projection | Improves scanability while retaining canonical evidence. |
| Reconsideration triggers | **ADOPT** | Waivers/accepted debt | Prevents permanent debt by inertia. |
| Canonical skill source → generated adapters | **ADOPT** | Skill packaging | Reduces platform drift. |
| Artifact reduction vs process overhead | **ADOPT** | Evaluation reports | Prevents misleading efficiency claims. |
| Graph-ranked budgeted context | **ADAPT** | Evidence graph/context projection | Use UCA evidence relevance rather than chat-specific repository mapping. |
| Independent verification of high-impact heuristic/AI findings | **ADAPT** | Candidate validation | Treat independence as evidence strategy, not mandatory subagent topology. |
| Focused lenses | **ADAPT** | Audit plans/report views | Share evidence and disclose omissions. |
| Root-cause-guided variant analysis | **DEFER** | Investigative mode | High value after known defects; requires noise controls and stable adapter base. |
| Versioned native/stdlib alternatives | **ADAPT** | Language/framework packs | Avoid a static universal prompt catalog that becomes stale. |
| Positive/healthy pattern reporting | **ADAPT** | Reports | Use selectively to explain justified complexity, not bloat every audit. |
| Separate uca-explain/review/investigate/compare skills | **DEFER** | Agent Skills | Only if routing evidence justifies additional surface. |
| Always-on persistent mode | **REJECT** | None | Conflicts with explicit bounded audit invocation. |
| Repeated full-rule prompt injection | **REJECT** | None | Consumes context and creates hidden behavioral state. |
| Prompt-only UCA | **REJECT** | None | Cannot satisfy repository/evidence/bundle contracts. |
| Automatic fixes/refactoring | **REJECT** | Initial product boundary | Violates evidence-not-authority and read-only defaults. |
| Hidden tool installation | **REJECT** | None | Violates trust and reproducibility. |
| Hand-maintained host copies | **REJECT** | None | Creates semantic drift. |
| Flat taxonomy explosion | **REJECT** | None | Use compositional ontology with concise projections. |
| Raw LOC optimization | **REJECT** | None | Does not represent conceptual/operational value. |
| Mandatory subagents | **REJECT** | None | Would turn UCA into an agent framework. |
| Hooks that rewrite repositories | **REJECT** | None | Violates read-only subject integrity. |
| AI-only blocking findings | **REJECT** | None | AI remains advisory evidence absent independent proof. |

## Source-to-UCA boundary

UCA borrows mechanisms, not external product architectures wholesale. The UCA engine retains stronger repository identity, evidence classes, history/graph/runtime intelligence, provenance, partial-completion semantics, stable findings, and harness neutrality. Agent Skills contribute routing and interpretation protocols; they do not become the analysis implementation.
