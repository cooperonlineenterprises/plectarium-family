# Implementation Validation Contract

## Evidence before claims

Before claiming a task or capability complete:

1. identify the exact product claim;
2. identify a change that would make the claim false;
3. run the tests/validators that would detect that failure;
4. inspect full results and exit status;
5. verify required adverse and near-miss cases;
6. preserve the output artifact/reference;
7. report actual state, including limitations.

## Required proof classes

- **Structural:** schemas, APIs, IDs, static contract conformance.
- **Behavioral:** real execution against representative fixtures.
- **Negative:** near-miss cases that must not produce findings.
- **Failure:** unavailable, denied, timeout, malformed, corrupt, cancelled.
- **Security:** malicious repository/output, path/network/write boundaries.
- **Determinism:** repeatability and stable identity where promised.
- **Compatibility:** previous schema/bundle/tool/interface versions.
- **Performance:** published workload/environment and distribution.
- **Integration:** downstream consumer and cross-interface equivalence.

Tests that assert only that required words or files exist do not establish behavior.
