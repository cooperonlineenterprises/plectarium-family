# AI Task Packet Contract

Every implementation task packet **MUST** contain:

```text
task ID and status
objective
product claim being established
architectural context and authority
prerequisites/dependencies
authoritative inputs
permitted files/interfaces
forbidden changes
required outputs
acceptance criteria
required tests and adverse cases
required evidence/commands/artifacts
handoff requirements
open risks and escalation path
```

## Task completion record

The implementing agent returns:

- exact files changed;
- interface/schema changes;
- tests added and why they establish the claim;
- commands executed, versions, exit codes, and summary;
- benchmark/evaluation artifacts where required;
- unresolved failures, skipped checks, and limitations;
- compatibility/migration impact;
- downstream tasks unblocked or invalidated;
- confirmation that no prohibited surface was changed.

A narrative “done” is not a valid handoff.
