# Implementation Dependency Graph

**Authority:** Governance / sequencing  
**Machine source:** [`implementation-dependency-graph.yaml`](implementation-dependency-graph.yaml)

```mermaid
flowchart TD
    S0[Stage 0: Constitution and contract stabilization] --> S1[Stage 1: Foundational schemas and identities]
    S1 --> S2[Stage 2: Minimum Complete Architecture]
    S2 --> S3[Stage 3: Native repository intelligence]
    S2 --> S4[Stage 4: Language intelligence]
    S3 --> S5[Stage 5: Adapters, fusion, Reduction]
    S4 --> S5
    S5 --> S6[Stage 6: CLI / CI / MCP / OCI]
    S6 --> S7[Stage 7: Agent Skills and integrations]
    S6 --> S8[Stage 8: Production hardening and evaluation]
    S7 --> S8
    S8 --> S9[Stage 9: Mature UCA v1]
```

## Foundational blockers

Repository identity, scope, execution permission, completion, evidence, candidate validation, finding identity, and bundle identity block dependent semantic breadth. They must be implemented through a complete vertical slice before parallel capability teams stabilize public outputs.

## Safe parallel branches after the Minimum Complete Architecture

- Git history and graph algorithms.
- Rust and Python language packs.
- TypeScript/JavaScript and Go packs.
- Generic import adapters and external tool conformance.
- Reduction fixture/evaluation design.
- OCI hardening and Agent Skill evaluation scaffolding that does not freeze interface semantics prematurely.

## Synchronization points

- Foundation contract freeze.
- Request-to-bundle vertical proof.
- Evidence normalization conformance across native and external producers.
- Interface equivalence.
- Capability-depth/release-proof reconciliation.
