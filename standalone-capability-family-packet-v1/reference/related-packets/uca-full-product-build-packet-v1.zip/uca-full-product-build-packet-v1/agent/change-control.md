# Architectural Change Control

## Protected surfaces

Changes to these require an ADR or explicit architecture-change record:

- Product Charter or invariants;
- evidence classes or observation meaning;
- confidence or completion semantics;
- candidate/finding lifecycle or fingerprinting;
- Audit Bundle required content/identity;
- execution permission model;
- adapter protocol;
- public CLI exit/command semantics;
- MCP tool/resource semantics;
- capability/provider manifest;
- production-v1 capability depth/release gates.

## Process

```text
detect conflict or need
→ create proposed ADR
→ identify affected contracts, code, tasks, migrations, security, and users
→ provide evidence and alternatives
→ architecture review
→ human product approval where required
→ update normative truth, schemas, tests, matrix, and tasks atomically
→ resume dependent implementation
```

A workstream may continue only around unaffected surfaces. It must not implement an unpublished local dialect of a foundational contract.

## Compatibility

A proposal must state:

- source and target versions;
- reader/writer compatibility;
- bundle/schema migration;
- rollout and rollback;
- cache invalidation;
- finding comparison/fingerprint impact;
- Agent Skill/interface impact;
- external provider impact.
