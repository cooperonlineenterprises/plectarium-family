# AI-Team Authority Model

**Authority:** Governance  
**Status:** `ESTABLISHED`

## Roles

### Human Product Authority

Owns product ambition, risk acceptance, release approval, licensing, material scope tradeoffs, and acceptance/rejection of foundational ADRs.

### Architecture / Integration Lead

Owns architectural consistency, normative contract changes, schema evolution, cross-workstream integration, invariant compliance, interface equivalence, and release architecture. This role cannot silently override the Product Charter.

### Workstream Leads

Own implementation and proof within their declared surfaces. They may propose contract changes but cannot accept them alone when cross-workstream or public semantics are affected.

### Implementing Agents

Own assigned code, tests, fixtures, and handoff evidence. They have freedom over internal implementation where the task packet permits.

### Verification Agents

Independently evaluate claim proof, adverse cases, and integration. They do not approve product authority; they report evidence and gaps.

## Change authority matrix

| Change | Workstream lead | Architecture lead | Human authority |
|---|---:|---:|---:|
| Internal private algorithm preserving contracts | approve | informed as needed | no |
| Private crate/module decomposition | approve | review if cross-workstream | no |
| New dependency | propose/approve under policy | review security/architecture | material licenses or strategic dependencies |
| Foundational schema semantic change | propose | approve through ADR | approve when product boundary/compatibility changes |
| Evidence/completion/finding meaning | propose | approve through ADR | approve |
| Public CLI/MCP/bundle compatibility | propose | approve through ADR | approve breaking change/release policy |
| Invariant change | propose | recommend | approve |
| Release declaration | evidence contribution | readiness recommendation | approve |

## Conflict behavior

An agent that discovers a conflict must record:

- conflicting authorities;
- affected task and dependent work;
- observed evidence;
- options and consequences;
- whether safe work can continue around the conflict.

It must not choose the lower-level instruction merely because it is more convenient.

## Authority boundaries

- UCA project roles govern UCA development, not audited repositories.
- UCA findings do not grant implementation authority.
- External analyzers do not define UCA semantics.
- Agent statements are not verification evidence without reproducible artifacts.
