# INTEL-003 — Duplication, complexity, and hotspots

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-INTEL`  
**Dependencies:** `INTEL-001`, `INTEL-002`

## Objective

Implement exact clones, bounded near clones, structural metrics, and cross-signal hotspots.

## Product claim

UCA ranks consequential candidates rather than threshold warnings.

## Authoritative inputs

- `capability matrix`

## Permitted architectural surface

- Analysis modules

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Observations/candidates/hotspot policy

## Acceptance criteria

- Generated code separated
- metric components visible
- top-k bounded

## Required tests and adverse cases

- Clone TP/TN, nested-loop negatives, maintainer ranking fixture

## Required evidence

- Precision and performance results

## Handoff requirements

- Unblocks Reduction and periodic audit

## Open risks

- Noise and metric gaming.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
