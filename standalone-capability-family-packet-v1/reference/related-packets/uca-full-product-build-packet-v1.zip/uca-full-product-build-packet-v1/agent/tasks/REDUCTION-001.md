# REDUCTION-001 — Reduction lens and safety floor

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-REDUCTION`  
**Dependencies:** `INTEL-001`, `INTEL-002`, `INTEL-003`, `FOUNDATION-007`

## Objective

Implement compositional taxonomy, decision ladder, floor validators, benefit vectors, retain/investigate outcomes, and triggers.

## Product claim

UCA finds safe removable weight without weakening justified complexity.

## Authoritative inputs

- `spec/reduction-model.md`
- `spec/safety-floor.md`

## Permitted architectural surface

- Reduction modules/fixtures

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Candidate/finding generators
- floor records
- benefit projections

## Acceptance criteria

- Violations rejected
- high-impact unknown investigates
- retain supported

## Required tests and adverse cases

- Safe/unsafe/dependency/state/compatibility/observability/performance cases

## Required evidence

- Top-k precision and safety report

## Handoff requirements

- Unblocks uca-simplify and v1

## Open risks

- Over-simplification and duplicated findings.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
