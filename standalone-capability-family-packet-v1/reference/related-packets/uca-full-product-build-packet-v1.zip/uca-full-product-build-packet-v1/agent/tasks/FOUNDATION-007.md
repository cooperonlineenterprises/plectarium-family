# FOUNDATION-007 — Candidate validation model

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-EVIDENCE`  
**Dependencies:** `FOUNDATION-006`

## Objective

Implement candidate, deduplication, validation/refutation, and rejection records.

## Product claim

Heuristic/AI suspicion cannot bypass validation.

## Authoritative inputs

- `spec/candidate-validation.md`
- `candidate schemas`

## Permitted architectural surface

- Candidate/validator framework

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Lifecycle state machine
- rejection store
- independent-verification hooks

## Acceptance criteria

- Rejected evidence retained
- unavailable required validation remains unresolved

## Required tests and adverse cases

- TP/TN/duplicate/conflict/unavailable validation fixtures

## Required evidence

- Ablation-ready result artifacts

## Handoff requirements

- Unblocks finding generation

## Open risks

- Validator becoming a second arbitrary rule engine.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
