# LANG-001 — Rust deep language pack

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-LANG-RUST`  
**Dependencies:** `KERNEL-004`, `INTEL-002`

## Objective

Implement deep Rust discovery, semantic identities, metrics, graphs, reachability roots, native diagnostics, tests, and coverage integration.

## Product claim

Rust depth matches capability matrix with declared blind spots.

## Authoritative inputs

- `spec/language-packs.md`

## Permitted architectural surface

- Rust pack and adapters/fixtures

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Pack manifest
- semantic graph producers
- fixtures

## Acceptance criteria

- Compiler semantic edges distinct from parser
- supported versions documented

## Required tests and adverse cases

- Cargo workspaces/features/macros/generated/async/unsafe fixtures

## Required evidence

- Language conformance matrix

## Handoff requirements

- Unblocks production v1 language claim

## Open risks

- Macro/generated semantics.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
