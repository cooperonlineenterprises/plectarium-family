# FOUNDATION-006 — Evidence model

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-EVIDENCE`  
**Dependencies:** `FOUNDATION-002`

## Objective

Implement observation/evidence class/provenance primitives.

## Product claim

Evidence classes, scope, freshness, and provenance remain distinguishable.

## Authoritative inputs

- `spec/evidence-model.md`
- `observation/evidence schemas`

## Permitted architectural surface

- Evidence model crates/modules

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Typed envelopes
- evidence graph primitives
- provenance

## Acceptance criteria

- AI cannot serialize as deterministic
- raw/normalized identity preserved

## Required tests and adverse cases

- Every evidence class
- conflicting evidence
- sensitivity/redaction

## Required evidence

- Round-trip and invariant tests

## Handoff requirements

- Unblocks normalization and findings

## Open risks

- Overgeneric payloads eroding typed meaning.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
