# KERNEL-001 — Audit request validation and planning

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-KERNEL`  
**Dependencies:** `FOUNDATION-003`, `FOUNDATION-004`, `FOUNDATION-005`, `FOUNDATION-010`

## Objective

Implement request validation, capability resolution, and deterministic plan DAG.

## Product claim

Equivalent inputs yield an inspectable plan with exact effects and digest.

## Authoritative inputs

- `audit request/plan/node schemas`
- `spec/audit-lifecycle.md`

## Permitted architectural surface

- Kernel planner modules

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Request API
- capability resolver
- plan digest

## Acceptance criteria

- Required/optional/prohibited states correct
- no execution before plan

## Required tests and adverse cases

- Plan determinism
- budget
- capability selection
- permission refusal

## Required evidence

- Plan fixtures/digests

## Handoff requirements

- Unblocks execution and MCA

## Open risks

- Analyzer-specific leakage.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
