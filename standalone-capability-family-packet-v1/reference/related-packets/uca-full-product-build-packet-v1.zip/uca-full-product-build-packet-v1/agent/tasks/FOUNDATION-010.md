# FOUNDATION-010 — Execution permission model

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-SECURITY`  
**Dependencies:** `FOUNDATION-001`, `FOUNDATION-002`

## Objective

Implement policy precedence, permissions, safe paths, and refusal semantics.

## Product claim

No node gains undeclared repository, process, network, write, or credential rights.

## Authoritative inputs

- `spec/execution-security.md`
- `execution-permission schema`

## Permitted architectural surface

- Policy/sandbox abstraction

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Effective permission engine
- reasoned refusals

## Acceptance criteria

- Lower policy cannot widen denial
- default network/write/project execution denied

## Required tests and adverse cases

- Policy matrix
- symlink/path
- environment stripping
- fork profile

## Required evidence

- Security test report

## Handoff requirements

- Unblocks planner/executor/adapters

## Open risks

- Platform sandbox variance.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
