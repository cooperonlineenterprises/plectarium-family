# FOUNDATION-008 — Finding and fingerprint model

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-EVIDENCE`  
**Dependencies:** `FOUNDATION-006`, `FOUNDATION-007`

## Objective

Implement findings, stable fingerprints, lifecycle, and comparison primitives.

## Product claim

Stable conditions survive line movement without colliding materially different findings.

## Authoritative inputs

- `spec/finding-model.md`
- `finding schemas`

## Permitted architectural surface

- Finding/fingerprint/comparison modules

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Fingerprint methods
- finding lifecycle
- comparison compatibility

## Acceptance criteria

- No line/message/time-primary identity
- taxonomy preserved

## Required tests and adverse cases

- Line movement
- file rename
- nearby refactor
- collision negatives

## Required evidence

- Fingerprint corpus results

## Handoff requirements

- Unblocks reports, ratchets, CI

## Open risks

- Language packs lack semantic identity early.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
