# FOUNDATION-002 — Schema framework and versioning

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-SCHEMA`  
**Dependencies:** `FOUNDATION-001`

## Objective

Establish Rust/schema generation/validation framework for JSON Schema 2020-12 contracts.

## Product claim

Foundational documents can be parsed, validated, versioned, and migrated consistently.

## Authoritative inputs

- `spec/schemas`
- `spec/bundle-format.md`
- `design/adr`

## Permitted architectural surface

- Schema framework crate/tools, test vectors, schema catalog

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Schema registry
- validation API
- positive/negative vectors
- compatibility policy implementation

## Acceptance criteria

- All packet schemas pass metaschema checks
- Unknown/duplicate-key policy is enforced
- IDs and versions resolve

## Required tests and adverse cases

- Malformed JSON
- duplicate keys
- unknown required version
- round trip

## Required evidence

- Fresh test output and schema catalog digest

## Handoff requirements

- Unblocks all contract implementations

## Open risks

- Binding too tightly to a specific Rust schema library.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
