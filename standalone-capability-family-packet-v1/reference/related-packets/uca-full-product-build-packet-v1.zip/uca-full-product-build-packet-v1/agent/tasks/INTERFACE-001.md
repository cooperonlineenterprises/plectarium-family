# INTERFACE-001 — Canonical CLI

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-INTERFACE`  
**Dependencies:** `KERNEL-004`

## Objective

Implement CLI commands, JSON/human output, progress, exit codes, and doctor without analyzer logic.

## Product claim

CLI is complete canonical local interface and truthful about partiality.

## Authoritative inputs

- `spec/cli-contract.md`

## Permitted architectural surface

- CLI crate/binary/docs/tests

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- CLI commands and fixtures

## Acceptance criteria

- stdout/stderr clean
- noninteractive no prompt/install
- exit codes correct

## Required tests and adverse cases

- Golden CLI, malformed, partial, cancellation

## Required evidence

- CLI conformance report

## Handoff requirements

- Unblocks CI/MCP/skills

## Open risks

- CLI leaking engine logic.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
