# KERNEL-003 — Normalization and evidence graph

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-EVIDENCE`  
**Dependencies:** `KERNEL-002`, `FOUNDATION-006`

## Objective

Implement producer output normalization and graph/reference integrity.

## Product claim

Native and external evidence enters one traceable model without class strengthening.

## Authoritative inputs

- `spec/evidence-model.md`
- `adapter protocol`

## Permitted architectural surface

- Normalizer registry/evidence graph

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Versioned normalizers
- graph store/API

## Acceptance criteria

- Raw identity retained
- invalid output rejected
- conflicts preserved

## Required tests and adverse cases

- Golden outputs
- malicious JSON
- unknown types
- conflict edges

## Required evidence

- Normalizer conformance report

## Handoff requirements

- Unblocks MCA candidate/finding path

## Open risks

- Schema evolution.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
