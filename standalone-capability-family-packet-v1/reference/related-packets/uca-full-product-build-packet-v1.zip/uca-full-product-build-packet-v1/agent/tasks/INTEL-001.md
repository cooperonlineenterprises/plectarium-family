# INTEL-001 — Git history intelligence

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-INTEL`  
**Dependencies:** `KERNEL-004`

## Objective

Implement churn, ownership, reverts, co-change, filters, and history cache.

## Product claim

UCA produces reproducible history evidence after excluding non-semantic noise.

## Authoritative inputs

- `capability matrix history entries`

## Permitted architectural surface

- History modules/fixtures

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- History observations/graphs/cache

## Acceptance criteria

- Renames/bots/format/generated policies explicit

## Required tests and adverse cases

- Synthetic histories and large-history benchmark

## Required evidence

- Capability proof refs

## Handoff requirements

- Unblocks hotspots/reduction

## Open risks

- Commit hygiene ambiguity.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
