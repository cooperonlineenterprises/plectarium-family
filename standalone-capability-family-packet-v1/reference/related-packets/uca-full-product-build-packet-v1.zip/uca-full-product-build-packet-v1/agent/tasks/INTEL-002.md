# INTEL-002 — Graph and architecture intelligence

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-INTEL`  
**Dependencies:** `KERNEL-004`

## Objective

Implement file/module graph, SCCs, centrality, reachability, architecture rules, and context projection base.

## Product claim

Graph observations preserve extraction strength and do not become unsupported verdicts.

## Authoritative inputs

- `spec/graph-intelligence.md`

## Permitted architectural surface

- Graph algorithms/storage/rules

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Graphs/metrics/rule evaluator

## Acceptance criteria

- Edge producer/resolution explicit
- large graph bounded

## Required tests and adverse cases

- Cycles, communities, centrality near misses, graph integrity

## Required evidence

- Graph benchmark/proof

## Handoff requirements

- Unblocks language semantic graphs and Reduction

## Open risks

- Graph scale and identity.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
