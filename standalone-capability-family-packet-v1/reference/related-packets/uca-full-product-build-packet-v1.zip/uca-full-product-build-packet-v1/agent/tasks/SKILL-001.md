# SKILL-001 — Canonical UCA Agent Skills

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-SKILLS`  
**Dependencies:** `INTERFACE-001`, `INTERFACE-002`, `REDUCTION-001`

## Objective

Implement uca-audit/uca-simplify packages, generator, structural/routing/behavioral evals.

## Product claim

Agents invoke and interpret UCA truthfully without becoming the engine or authority.

## Authoritative inputs

- `skills specs`
- `eval specification`

## Permitted architectural surface

- Canonical skills/generators/evals

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Skill packages
- host adapters
- eval cases

## Acceptance criteria

- Completion inspected before claims
- no install/mutation
- correct mode/lens

## Required tests and adverse cases

- Positive/negative/collision/pressure/no-skill controls

## Required evidence

- Skill evaluation report

## Handoff requirements

- Unblocks external agent consumers

## Open risks

- Prompt drift/model variance.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
