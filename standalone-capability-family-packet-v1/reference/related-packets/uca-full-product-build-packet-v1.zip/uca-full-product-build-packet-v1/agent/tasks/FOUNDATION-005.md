# FOUNDATION-005 — Completion semantics

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-KERNEL`  
**Dependencies:** `FOUNDATION-002`

## Objective

Implement node/audit completion derivation independent of findings.

## Product claim

Unavailable or partial analysis cannot appear complete or passed.

## Authoritative inputs

- `spec/completion-semantics.md`
- `completion schema`

## Permitted architectural surface

- Completion engine/tests

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Completion derivation API
- reason codes

## Acceptance criteria

- All required condition distinctions are represented
- zero findings does not affect state

## Required tests and adverse cases

- Unavailable/disabled/denied/failed/partial/stale/timeout/unsupported/cancelled

## Required evidence

- Truth-table test output

## Handoff requirements

- Unblocks vertical audit lifecycle and interfaces

## Open risks

- Conflating optional limitation with partial failure.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
