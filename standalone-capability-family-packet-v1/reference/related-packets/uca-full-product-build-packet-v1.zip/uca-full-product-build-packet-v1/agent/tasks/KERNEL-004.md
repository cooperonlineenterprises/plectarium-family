# KERNEL-004 — Minimum Complete Architecture vertical slice

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-ARCH`  
**Dependencies:** `KERNEL-001`, `KERNEL-002`, `KERNEL-003`, `FOUNDATION-007`, `FOUNDATION-008`, `FOUNDATION-009`

## Objective

Integrate repository-to-bundle lifecycle with a small native analysis.

## Product claim

UCA proves identity→plan→execute→evidence→candidate→refute→finding→completion→bundle→inspect→compare.

## Authoritative inputs

- `All foundation contracts`

## Permitted architectural surface

- Cross-workstream integration only

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Runnable vertical slice
- golden bundles
- inspect/compare API

## Acceptance criteria

- One surviving and one rejected candidate
- partial path truthful
- repeatable content identity

## Required tests and adverse cases

- End-to-end golden/partial/corrupt/compare cases

## Required evidence

- MCA acceptance packet

## Handoff requirements

- Unblocks native intelligence, language packs, adapters, and interface implementation

## Open risks

- Prematurely freezing weak internal algorithms.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
