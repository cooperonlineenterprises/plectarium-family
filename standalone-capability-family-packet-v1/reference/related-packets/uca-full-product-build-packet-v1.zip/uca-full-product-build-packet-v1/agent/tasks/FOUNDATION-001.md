# FOUNDATION-001 — Product authority validation

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-ARCH`  
**Dependencies:** None

## Objective

Validate packet coherence before implementation begins.

## Product claim

The authority hierarchy is internally consistent and sufficient to guide work.

## Authoritative inputs

- `CHARTER.md`
- `spec/invariants.md`
- `DECISIONS.md`
- `RELEASE-CRITERIA.md`

## Permitted architectural surface

- Documentation, ADR proposals, validation findings

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Authority review report
- accepted corrections or explicit open questions

## Acceptance criteria

- All required concepts have one canonical home
- No unresolved contradiction is hidden

## Required tests and adverse cases

- Cross-document consistency checks
- source precedence review

## Required evidence

- Validation report and exact changed artifacts

## Handoff requirements

- Unblocks FOUNDATION-002 through FOUNDATION-010

## Open risks

- Over-editing settled product meaning without evidence.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
