# EVAL-001 — Foundation contract conformance suite

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-EVAL`  
**Dependencies:** `FOUNDATION-002`, `KERNEL-004`

## Objective

Implement claim-oriented corpus and runner for all foundation gates.

## Product claim

Passing tests establish foundational product claims rather than document presence.

## Authoritative inputs

- `evals/claim-proof-matrix.md`
- `evals/test-catalog.yaml`

## Permitted architectural surface

- Test runner/fixtures/results schema

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Deterministic foundation suite
- result artifacts

## Acceptance criteria

- Every CP-FOUNDATION gate has positive, negative, failure evidence

## Required tests and adverse cases

- Mutation/falsifiability check on tests

## Required evidence

- Machine-readable proof report

## Handoff requirements

- Unblocks parallel maturity promotion

## Open risks

- Tautological tests.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
