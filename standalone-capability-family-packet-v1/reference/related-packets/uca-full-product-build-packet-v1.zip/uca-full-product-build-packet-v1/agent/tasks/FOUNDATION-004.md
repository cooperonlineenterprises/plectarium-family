# FOUNDATION-004 — Scope model

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-REPO`  
**Dependencies:** `FOUNDATION-002`, `FOUNDATION-003`

## Objective

Implement secure scope resolution and classification.

## Product claim

Every observation is bound to explicit analyzed and excluded populations.

## Authoritative inputs

- `spec/repository-identity.md`
- `scope schema`

## Permitted architectural surface

- Scope resolver/classifier/config inputs

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Effective scope record
- coverage population
- classification evidence

## Acceptance criteria

- Generated/vendor/test/sensitive policies are explicit
- lower config cannot widen host policy

## Required tests and adverse cases

- Glob conflicts
- ignored/untracked
- symlink escape
- nested repo
- limits

## Required evidence

- Scope fixtures and coverage report

## Handoff requirements

- Unblocks discovery and execution

## Open risks

- Misclassification creating misleading metrics.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
