# ADAPTER-001 — Adapter protocol and first generic importers

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-ADAPTER`  
**Dependencies:** `KERNEL-004`, `FOUNDATION-010`

## Objective

Implement manifest/probe/run protocol, SDK, conformance harness, SARIF/SBOM/coverage importers.

## Product claim

External evidence is safely invoked/imported without tool-specific core coupling.

## Authoritative inputs

- `spec/adapter-protocol.md`

## Permitted architectural surface

- Adapter protocol/SDK/importers

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Mock adapter
- generic importers
- version matrix

## Acceptance criteria

- Missing tool explicit
- malicious output bounded
- no auto-install

## Required tests and adverse cases

- Protocol/version/timeout/network/output/redaction

## Required evidence

- Conformance report

## Handoff requirements

- Unblocks specialist adapters

## Open risks

- External format variation.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
