# FOUNDATION-009 — Audit Bundle identity

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-BUNDLE`  
**Dependencies:** `FOUNDATION-002`, `FOUNDATION-005`, `FOUNDATION-006`, `FOUNDATION-008`

## Objective

Implement canonical bundle layout, JCS/SHA-256 identity, atomic finalization, reader, and verifier.

## Product claim

A bundle is durable, inspectable, corruption-detectable, and reproducible where promised.

## Authoritative inputs

- `spec/bundle-format.md`
- `bundle manifest schema`

## Permitted architectural surface

- Bundle/CAS/provenance modules

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Writer/reader/verifier
- content identity
- checksums
- staging/finalization

## Acceptance criteria

- Corruption cannot appear valid
- archive identity distinct

## Required tests and adverse cases

- Truncation
- hash mismatch
- reference mismatch
- canonicalization
- atomic interruption

## Required evidence

- Golden bundle and verifier output

## Handoff requirements

- Unblocks Minimum Complete Architecture

## Open risks

- Self-referential identity design.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
