# KERNEL-002 — Execution DAG and constrained runner

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-KERNEL`  
**Dependencies:** `KERNEL-001`, `FOUNDATION-010`

## Objective

Implement resource-aware scheduling, direct argv, process trees, cancellation, and node outcomes.

## Product claim

The engine executes the accepted plan and contains failures/effects.

## Authoritative inputs

- `spec/adapter-protocol.md`
- `spec/execution-security.md`

## Permitted architectural surface

- Executor/scheduler/process runner

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- DAG scheduler
- node state store
- cancellation

## Acceptance criteria

- No shell default
- full process tree killed
- independent nodes continue per policy

## Required tests and adverse cases

- Timeout
- memory/output
- cancel
- malicious child
- partial failure

## Required evidence

- Execution trace/test artifacts

## Handoff requirements

- Unblocks MCA and adapters

## Open risks

- Cross-platform process semantics.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
