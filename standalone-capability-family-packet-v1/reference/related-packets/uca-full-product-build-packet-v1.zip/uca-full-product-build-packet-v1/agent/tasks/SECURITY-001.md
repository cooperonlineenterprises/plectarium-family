# SECURITY-001 — Read-only and sandbox threat tests

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-SECURITY`  
**Dependencies:** `KERNEL-002`, `FOUNDATION-009`

## Objective

Build hostile repository/output corpus and verify native/copy/OCI boundaries.

## Product claim

Read-only/network/credential/resource promises are demonstrably enforced.

## Authoritative inputs

- `SECURITY.md`
- `spec/execution-security.md`

## Permitted architectural surface

- Security harness and fixtures

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Threat fixtures
- mutation detector
- network test harness

## Acceptance criteria

- Files/index/HEAD/refs unchanged
- no undeclared network
- resource exits correct

## Required tests and adverse cases

- Symlink/archive/parser/Git/output/prompt/cache/DoS cases

## Required evidence

- Threat-test report

## Handoff requirements

- Unblocks production hardening

## Open risks

- Platform-specific false confidence.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
