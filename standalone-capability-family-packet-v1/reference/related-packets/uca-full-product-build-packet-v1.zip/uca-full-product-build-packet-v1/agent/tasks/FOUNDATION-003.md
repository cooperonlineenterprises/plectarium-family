# FOUNDATION-003 — Repository identity

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-REPO`  
**Dependencies:** `FOUNDATION-002`

## Objective

Implement exact Git/worktree/content identity.

## Product claim

UCA can state exactly which repository state it audited.

## Authoritative inputs

- `spec/repository-identity.md`
- `repository-identity schema`

## Permitted architectural surface

- Repository identity module and fixtures

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Clean/dirty/index/untracked/submodule/nested identity
- content manifest

## Acceptance criteria

- Equivalent state produces stable identity
- material state changes identity
- no path escape

## Required tests and adverse cases

- Clean/dirty Git
- renames/deletes
- submodules
- symlinks
- Unicode
- large files

## Required evidence

- Fixture results and deterministic digests

## Handoff requirements

- Unblocks scope, discovery, planning, cache

## Open risks

- Platform path differences.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
