# INTERFACE-002 — CI and MCP thin interfaces

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-INTERFACE`  
**Dependencies:** `INTERFACE-001`

## Objective

Implement thin CI wrapper examples and MCP server with semantic equivalence.

## Product claim

Equivalent requests yield equivalent engine results and no extra authority.

## Authoritative inputs

- `spec/ci-contract.md`
- `spec/mcp-contract.md`

## Permitted architectural surface

- CI integration/MCP binary/tests

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- GitHub Action/generic CI
- MCP tools/resources

## Acceptance criteria

- Fork safety
- no generic shell/write
- content identity equivalence

## Required tests and adverse cases

- Fork PR, shallow history, MCP roots/cancel/pagination/equivalence

## Required evidence

- Interface proof report

## Handoff requirements

- Unblocks productization/skills

## Open risks

- Platform API drift.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
