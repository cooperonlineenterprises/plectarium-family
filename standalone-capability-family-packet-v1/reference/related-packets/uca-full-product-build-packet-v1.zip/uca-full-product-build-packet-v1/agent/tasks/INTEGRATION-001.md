# INTEGRATION-001 — Octon Mini external-provider conformance

**Status:** `READY WHEN DEPENDENCIES COMPLETE`  
**Workstream:** `WS-INTEGRATION`  
**Dependencies:** `INTERFACE-001`, `INTERFACE-002`, `SECURITY-001`

## Objective

Produce and test narrow read-only evidence-provider integration without UCA dependency on Octon.

## Product claim

Octon can govern exact UCA invocation and durable evidence reference; UCA remains standalone.

## Authoritative inputs

- `integrations/octon-mini.md`

## Permitted architectural surface

- Provider example schemas/fixtures/docs; Octon-side work separately

## Forbidden changes

- Do not weaken Charter or invariants.
- Do not silently change another foundational schema or public interface.
- Do not install tools or enable network in tests without explicit test policy.

## Required outputs

- Conformance fixtures and example manifest

## Acceptance criteria

- Digest/trust/revision/mutation/partial result cases pass
- no finding auto-task

## Required tests and adverse cases

- Provider lifecycle fixtures

## Required evidence

- Cross-repo conformance report

## Handoff requirements

- Demonstrates standalone capability pattern

## Open risks

- Provider contract over-generalization.

## Escalation

If implementation reveals a conflict with a higher-level authority or requires a protected contract change, stop that portion of work and open an ADR/change record under `agent/change-control.md`. Continue only on unaffected surfaces.
