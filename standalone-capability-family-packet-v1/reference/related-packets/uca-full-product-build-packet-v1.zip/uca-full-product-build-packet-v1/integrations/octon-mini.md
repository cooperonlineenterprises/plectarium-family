# Octon Mini Integration Boundary

**Authority:** Normative integration boundary for UCA; proposed Octon-side contract  
**Status:** `ACCEPTED` for the boundary, `PROPOSED` for exact Octon implementation details

## 1. Governing separation

> **UCA determines what appears risky, costly, complicated, inconsistent, or removable. Octon Mini determines whether that evidence matters to the project, who may act on it, and what governed work happens next.**

UCA core MUST NOT depend on Octon Mini. Octon Mini MAY govern UCA development and later invoke UCA, but it is one consumer rather than UCA’s runtime.

```mermaid
flowchart TD
    T[User or agent task] --> O[Octon Mini task and authority]
    O --> P[Reviewed external-provider plan]
    P --> U[Exact UCA CLI or OCI artifact]
    U --> B[UCA Audit Bundle]
    B --> V[Octon validates digest, provenance, revision, completion]
    V --> E[Octon records durable evidence reference]
    E --> D[Human or governed project decision]
    D --> W[Separate implementation work if authorized]
```

## 2. Provider class

The initial generic provider class SHOULD be deliberately narrow:

```text
read_only_evidence_producer
```

It is not a universal plugin/action runtime.

### Allowed v1 effects

- read declared repository scope;
- read declared Git history;
- execute the exact trusted provider artifact and declared analyzer tools;
- use declared network access when separately authorized;
- write to approved output, cache, and temporary locations;
- return an immutable result reference.

### Prohibited v1 effects

- repository or Git mutation;
- commit, push, merge, publish, deploy, or communicate;
- create issues, tasks, decisions, waivers, or authority records;
- install UCA or analyzers;
- widen scope, network, credentials, or execution rights;
- convert findings into implementation work automatically.

## 3. Provider contracts

The packet provides proposed Octon-owned schemas under `integrations/octon-mini-schemas/`:

- `harness.external-provider-manifest.v1`;
- `harness.external-provider-registry.v1`;
- `harness.external-provider-request.v1`;
- `harness.external-provider-result-ref.v1`.

These schemas are integration examples and MUST NOT become dependencies of the UCA engine. UCA owns only its normal request, plan, completion, and Audit Bundle contracts.

## 4. Provider manifest example

```json
{
  "schema_version": "harness.external-provider-manifest.v1",
  "provider_class": "read_only_evidence_producer",
  "id": "universal-code-audit",
  "version": "1.0.0",
  "artifact": {
    "kind": "oci_image",
    "reference": "ghcr.io/cooperonlineenterprises/uca@sha256:...",
    "sha256": "..."
  },
  "interfaces": [
    {
      "kind": "cli_json_process",
      "command": ["uca", "audit"],
      "request_schema": "uca.audit-request.v1",
      "completion_schema": "uca.completion.v1",
      "bundle_manifest_schema": "uca.audit-bundle-manifest.v1"
    }
  ],
  "capabilities": [
    "audit.continuous",
    "audit.periodic",
    "audit.investigative",
    "audit.compare",
    "finding.explain"
  ],
  "access": {
    "repository": "read_only",
    "git_history": "read_only",
    "network": "denied_by_default",
    "repository_writes": "prohibited",
    "external_output_write": "required"
  },
  "authority_effect": "none"
}
```

## 5. Octon-side lifecycle

1. An existing Octon task identifies why audit evidence is needed.
2. The UCA provider package is installed through Octon’s content-addressed package process; provider installation does not activate or trust it.
3. A project-owned trust/adoption record accepts an exact provider identity, version, digest, provenance, and access envelope.
4. Octon plans an invocation against an exact repository revision and UCA request.
5. Planning declares native or OCI execution, network, project execution, output path, cache policy, budget, and expected schemas.
6. A reviewed plan digest is accepted under task-scoped authority.
7. Octon invokes the exact artifact; UCA performs its ordinary audit lifecycle.
8. Octon validates the Audit Bundle manifest, checksum, repository identity, completion state, and provenance.
9. Octon records a durable result reference rather than copying UCA findings into its kernel as new canonical truth.
10. Reviewers inspect UCA evidence. Any remediation enters the normal Octon decision and task lifecycle.

## 6. Example downstream handoff

```text
UCA finding
  P1 · de-abstract PaymentProvider
        ↓
Octon decision candidate
  Should the project remove this abstraction?
        ↓
Project evidence, owner review, compatibility decision
        ↓
Separate implementation task if authorized
        ↓
Normal validation and a later UCA comparison
```

The UCA priority band does not grant Octon authority and does not determine the project decision.

## 7. Evidence freshness

The result reference MUST record:

- provider and artifact digest;
- UCA version;
- repository identity and analyzed revision;
- request and plan digest;
- audit content identity;
- completion state;
- produced and reused evidence timestamps;
- limitations;
- location and digest of the bundle;
- policy for determining stale, current, or incompatible evidence.

Octon MUST NOT present evidence as current after the subject revision, scope, relevant capability version, or material policy has changed beyond the declared reuse rules.

## 8. Native and OCI execution

The contract supports:

- `local_process` for trusted developer environments;
- `oci_image` for reproducible or high-assurance execution.

Projects MAY require OCI. Native mode requires direct argv, sanitized environment, declared writes, and before/after repository mutation detection. Neither mode may silently inherit credentials or network authority.

## 9. Minimal Octon additions

The anticipated minimal Octon work is:

- four provider schemas;
- a provider registry and trust/adoption record;
- a trigger-installed external-evidence-provider workflow capability;
- plan/run/resume/status command routing;
- native and OCI execution backends;
- exact result-reference and bundle validation;
- provider-run state separate from immutable package content;
- acceptance fixtures for absent, untrusted, incompatible, mutating, stale, malformed, partial, and successful providers.

No UCA analyzer implementation belongs in Octon Mini.

## 10. Conformance requirement

The integration passes only when UCA can be removed from the machine or replaced by another compatible external evidence producer without breaking the Octon kernel, and when UCA remains fully usable without Octon Mini.
