# Universal Code Audit Product Charter

**Authority:** Normative product constitution  
**Status:** `ESTABLISHED`  
**Version:** `1.0`

## 1. Product name

**Universal Code Audit**, abbreviated **UCA**.

## 2. Purpose

Universal Code Audit exists to help humans, engineering teams, coding agents, CI systems, and external harnesses answer:

> Where is this codebase unnecessarily difficult, expensive, risky, slow, coupled, duplicated, fragile, or conceptually heavy—and what evidence supports the highest-value way to improve it?

UCA does this by identifying an exact repository state, discovering applicable capabilities, planning bounded analyses, collecting internal and external evidence, normalizing that evidence, generating and attempting to refute candidates, producing stable findings, and emitting a durable UCA Audit Bundle.

## 3. Target users and consumers

UCA serves:

- developers auditing their own repositories locally;
- staff and principal engineers performing architectural maintenance;
- maintainers reviewing pull requests or releases;
- CI pipelines applying explicit evidence-based gates;
- security, reliability, performance, dependency, and test specialists contributing tool evidence;
- coding agents that need structured repository evidence rather than an unbounded prompt review;
- agent harnesses such as Octon Mini that govern invocation and downstream work;
- future hosted services that execute the same authoritative engine semantics remotely.

No consumer is required for UCA to function. The canonical local CLI remains a complete first-class interface.

## 4. Mature product ambition

A mature UCA v1 is a production-grade, local-first developer capability with:

- a single authoritative engine;
- canonical CLI operation;
- deterministic repository identity and scope;
- Continuous, Periodic, and Investigative audit tiers;
- repository history, topology, dependency, graph, duplication, hotspot, and ownership intelligence;
- deep Rust and Python language support;
- useful TypeScript/JavaScript and Go support;
- explicit external analyzer adapters;
- candidate validation and attempted refutation;
- stable findings and comparison across audits;
- a first-class Reduction/Simplification lens and safety floor;
- durable, content-addressed Audit Bundles;
- CI, MCP, and OCI/container interfaces over the same engine semantics;
- canonical Agent Skills that orchestrate UCA without becoming UCA;
- signed, provenance-rich release artifacts;
- explicit limitations and honest completion semantics.

## 5. Product philosophy

### 5.1 Evidence before conclusions

UCA **MUST** preserve the path from source observations to interpretations, candidates, validation outcomes, findings, and recommendations. A recommendation without inspectable evidence is not a valid UCA finding.

### 5.2 Understanding before judgment

The system **SHOULD** establish repository identity, scope, architecture, consumers, history, execution context, and relevant safety floors before making consequential claims.

### 5.3 Candidate before finding

Heuristic and AI-generated suspicions **MUST NOT** bypass validation or attempted refutation merely because they are plausible.

### 5.4 Deletion is a first-class optimization

UCA **SHOULD** identify when behavior, code, dependencies, state, configuration, abstractions, layers, processes, or concepts can be removed safely. It **MUST NOT** equate reduction with raw line-count minimization.

### 5.5 External specialization over weak reinvention

UCA **SHOULD** integrate mature specialist analyzers where they are stronger than a lightweight in-house implementation. UCA owns orchestration, evidence normalization, fusion, comparison, and decision support—not every domain analyzer.

### 5.6 Local first

Core use **MUST** remain possible without a hosted service, an agent, or network access. Remote providers and services are optional extensions.

### 5.7 Capability depth must be honest

Language and analyzer support **MUST** state actual depth and limitations. “Supported” is not sufficient when semantics differ materially by language or tool availability.

### 5.8 Full product in dependency order

The project **SHOULD** build aggressively toward the mature product while stabilizing foundational contracts before dependent breadth. The Minimum Complete Architecture is a proof checkpoint, not a deliberately limited end product.

## 6. Independence and harness neutrality

UCA **MUST** remain independently usable without Octon Mini or any other harness. UCA core **MUST NOT** import, depend upon, or require Octon Mini concepts.

The required thought experiment is:

> If Octon Mini disappeared tomorrow, could someone still clone UCA, build or install it, run `uca audit`, inspect and verify an Audit Bundle, use UCA in CI, invoke it through MCP or an OCI image, and integrate it with another harness?

A compliant implementation answers **yes**.

Octon Mini may govern the process of building UCA and may later consume UCA through a narrow external-provider contract. It remains one consumer, not UCA's runtime.

## 7. Relationship to AI

AI may assist with:

- semantic duplication;
- responsibility analysis;
- architecture interpretation;
- obsolete compatibility identification;
- de-abstraction and simplification candidates;
- stale documentation and terminology analysis;
- API usability interpretation.

AI is optional. AI output is an evidence class, not the canonical engine, an authority source, a repository mutation mechanism, or a substitute for deterministic or runtime evidence.

## 8. Relationship to external analyzers

Compilers, linters, CodeQL, Semgrep, OSV, Syft, Trivy, coverage systems, mutation tools, profilers, race detectors, fuzzers, architecture-test systems, and commercial analyzers remain independently owned capabilities. UCA invokes or imports them through explicit adapters, records exact identities and limitations, and normalizes their evidence.

UCA **MUST NOT** silently install, update, or trust arbitrary analyzers.

## 9. Relationship to human reviewers

UCA improves human judgment; it does not eliminate it. Humans retain responsibility for:

- intended product behavior;
- domain and organizational boundaries;
- compatibility commitments;
- risk acceptance;
- remediation decisions;
- architecture changes;
- release and deployment authority.

## 10. Relationship to CI

UCA owns audit semantics, bundle output, comparison, finding identity, and configured gate evaluation. CI owns checkout, scheduling, credentials, permissions, infrastructure isolation, artifact persistence, merge protection, and notifications.

## 11. Authority limits

UCA has no inherent authority to:

- modify source or configuration;
- write Git state;
- commit, push, merge, publish, or deploy;
- create issues or tasks;
- change policy;
- install dependencies or analyzers;
- enable network access;
- obtain credentials;
- accept debt or create waivers;
- approve or reject a project change.

A finding is evidence and recommendation only, even when labeled `P0`.

## 12. Non-goals

UCA is not:

- an autonomous software engineer;
- an agent harness;
- a governance or command-and-control plane;
- an automatic refactoring system;
- a repository or source-control authority;
- a deployment system;
- a replacement for mature specialist analyzers;
- an opaque AI reviewer;
- a hidden dependency installer;
- a system that treats unavailable tools as passing checks;
- a system optimized for maximizing finding count;
- a system optimized primarily for reducing raw LOC;
- a speculative universal capability framework.

## 13. Safety posture

UCA is read-only by default, network-denied by default, and project-execution-denied by default. Wider execution rights require explicit, inspectable declarations and must remain constrained to the accepted audit plan.

## 14. Extensibility philosophy

Extension occurs through:

- versioned capability declarations;
- language packs;
- out-of-process or OCI adapters;
- imported evidence formats;
- report projections;
- thin interfaces over the authoritative engine.

Arbitrary in-process plugins are not part of v1 because they weaken isolation and compatibility.

## 15. Compatibility philosophy

Foundational contracts are independently versioned. UCA should read the current and previous major bundle versions during a defined support window. Breaking semantic changes require explicit migration and architecture review.

## 16. Release philosophy

A release is not mature because it has many features. UCA v1 is complete only when the promised capability depths are coherently integrated, security defaults are demonstrated, completion is truthful, bundles are verifiable, cross-interface semantics agree, and the claim-proof matrix is satisfied.
