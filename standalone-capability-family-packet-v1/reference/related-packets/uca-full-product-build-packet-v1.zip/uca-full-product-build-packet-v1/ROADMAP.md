# UCA Full Product Roadmap

**Authority:** Governance and implementation sequencing  
**Status:** `ACCEPTED`

UCA will be built as the full product in dependency order. Stages are integration and proof gates, not reductions in product ambition.

## Stage 0 — Constitution and contract stabilization

Deliver the authority hierarchy, accepted ADRs, terminology, schemas, capability matrix, claim-proof matrix, security model, workstream ownership, and packet validation. Implementation may not redefine foundational meaning silently.

## Stage 1 — Minimum Complete Architecture

Prove the end-to-end lifecycle:

```text
repository identity
→ discovery
→ capability resolution
→ request
→ deterministic plan
→ constrained execution
→ evidence
→ candidate
→ validation/refutation
→ finding
→ completion
→ Audit Bundle
→ inspect
→ compare
```

The vertical slice may use a small number of native observations and a mock adapter, but it must use production-shaped contracts.

## Stage 2 — Native repository intelligence

Build repository inventory, Git history, churn, reverts, ownership, co-change, exact duplication, dependency topology, SCC/cycles, centrality, and complexity × churn hotspots.

## Stage 3 — Language intelligence

Build deep Rust and Python support, then useful TypeScript/JavaScript and Go support. Publish a depth matrix and limitations rather than a binary support claim.

## Stage 4 — External adapters and evidence fusion

Stabilize the adapter protocol and integrate generic SARIF, CycloneDX, SPDX, coverage, Semgrep, OSV, Syft, and selected native compiler/test adapters. Demonstrate missing-tool and incompatible-version behavior.

## Stage 5 — Reduction/Simplification depth

Implement the compositional Reduction taxonomy, safety-floor evaluation, benefit vectors, reconsideration triggers, and high-signal finding projections.

## Stage 6 — Product interfaces and equivalence

Stabilize CLI behavior, generic CI integration, GitHub Action, MCP, and OCI images. Prove equivalent requests produce semantically equivalent results.

## Stage 7 — Agent Skills and harness integrations

Release `uca-audit` and `uca-simplify`, generated platform adapters, behavioral evals, and the Octon Mini read-only evidence-provider integration.

## Stage 8 — Production hardening

Complete hostile-repository tests, fuzzing, cross-platform process behavior, signed releases, SBOM, provenance, performance budgets, compatibility, migration, troubleshooting, and real-project validation.

## Stage 9 — Mature UCA v1

Declare v1 only when [`RELEASE-CRITERIA.md`](RELEASE-CRITERIA.md) and [`evals/claim-proof-matrix.md`](evals/claim-proof-matrix.md) are satisfied.

## Parallelism

After the Stage 1 contract freeze, safe branches include:

- history and graph intelligence;
- language packs against frozen graph/evidence contracts;
- adapters against the frozen adapter protocol;
- report projections;
- evaluation corpus construction;
- OCI hardening;
- Agent Skill routing fixtures.

Synchronization points are identified in `agent/implementation-dependency-graph.*`.
