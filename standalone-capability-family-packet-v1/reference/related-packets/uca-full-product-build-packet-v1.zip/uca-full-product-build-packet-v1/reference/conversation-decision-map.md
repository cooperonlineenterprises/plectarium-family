# Conversation Decision Map

**Classification:** Historical-to-normative provenance map

This map lets contributors understand where major visible conversation decisions became repository authority without treating the transcript itself as the current specification.

| Conversation decision | Status | Canonical destinations | Notes |
|---|---|---|---|
| UCA is an independent, separately versioned audit system rather than functionality embedded in Octon Mini | ESTABLISHED | `CHARTER.md`, `spec/invariants.md`, `design/adr/adr-0001.md` | Core product boundary |
| UCA is an audit engine exposed through skills, not merely a prompt skill | ESTABLISHED | `CHARTER.md`, `ARCHITECTURE.md`, `skills/` | Skill remains an orchestration layer |
| One authoritative engine serves CLI, CI, MCP, OCI and future HTTP | ESTABLISHED | `spec/invariants.md`, `design/adr/adr-0002.md`, interface contracts | Cross-interface equivalence is release proof |
| The durable result is a UCA Audit Bundle | ESTABLISHED | `spec/bundle-format.md`, schemas, ADR-0003 | SARIF/SBOM/profile formats are imported or projected evidence |
| Outputs are evidence and recommendations, never authority | ESTABLISHED | `CHARTER.md`, invariants, finding and integration specs | Applies even to P0 findings |
| Read-only, network-denied, project-execution-denied defaults | ESTABLISHED | `SECURITY.md`, `spec/execution-security.md`, ADR-0004 | Wider rights require an explicit plan |
| Specialized analyzers should be integrated rather than weakly reimplemented | ACCEPTED | `spec/adapter-protocol.md`, capability matrix, ADR-0009 | UCA differentiates through evidence integration and decision support |
| Deterministic, heuristic, historical, runtime, human and AI evidence remain distinguishable | ESTABLISHED | `spec/evidence-model.md`, `spec/confidence-model.md`, ADR-0005 | Prevents AI or heuristic evidence from masquerading as fact |
| Candidate generation is separated from validation and attempted refutation | ESTABLISHED | `spec/candidate-validation.md`, lifecycle, schemas, ADR-0006 | Heuristic suspicion is not automatically a finding |
| Rejected candidates and rejection evidence are preserved | ACCEPTED | candidate-validation, bundle format, ADR-0007 | Supports false-positive control and evaluator learning |
| Stable findings survive line movement and wording changes | ESTABLISHED | `spec/finding-model.md`, fingerprint schema, ADR-0008 | Comparison relies on semantic identity |
| Reduction/Simplification is a first-class lens | ACCEPTED | `spec/reduction-model.md`, `skills/uca-simplify`, ADR-0010 | Includes deletion, reuse, state/config reduction and de-abstraction |
| Reduction is constrained by a non-reducible safety floor | ESTABLISHED | `spec/safety-floor.md`, safety-floor schema, ADR-0011 | Required complexity may produce `retain` |
| Accepted debt carries current ceilings and reconsideration triggers | ACCEPTED | waiver and reconsideration schemas, `spec/reduction-model.md` | Reopens decisions when evidence changes |
| AI is optional, advisory by default, and not the canonical engine | ESTABLISHED | `spec/ai-semantic-analysis.md`, ADR-0012 | Local/offline UCA remains complete without AI |
| The canonical CLI is the foundational interface | ACCEPTED | `spec/cli-contract.md`, ADR-0013 | Other interfaces remain thin |
| MCP is a thin interface rather than a second audit engine | ESTABLISHED | `spec/mcp-contract.md`, ADR-0014 | No arbitrary write/shell/installation operations |
| Agent-facing portability uses one canonical skill source and generated adapters | ACCEPTED | `skills/`, evaluation spec, ADR-0015 | Avoids divergent host copies |
| Initial skill family is `uca-audit` plus `uca-simplify` | ACCEPTED | `skills/` | Additional skills require routing evidence |
| Octon Mini uses a narrow external evidence-provider boundary | ACCEPTED | `integrations/octon-mini.md`, ADR-0016 | No UCA analyzer code in Octon |
| UCA can be developed under Octon Mini without depending on it | ESTABLISHED | charter, integration spec, build directive | Development governance and runtime dependency are distinct |
| UCA should prove a future standalone-capability pattern | ACCEPTED | `docs/standalone-capability-pattern.md` | No premature universal framework |
| Build the full product in dependency order rather than targeting a tiny MVP | ESTABLISHED | `README.md`, `ROADMAP.md`, build directive | Minimum Complete Architecture is an integration checkpoint |
| No-finding is not equivalent to clean, and unavailable is not passed | ESTABLISHED | completion semantics, skill references, evaluation | Completion-truth gate |
| Skill evaluation requires no-skill controls, routing tests, behavioral fixtures and pressure cases | ACCEPTED | `evals/EVALUATION-SPEC.md`, test catalog | Engine and skill evaluations remain separate |
| Artifact reduction and agent/process overhead are reported separately | ACCEPTED | evaluation spec, research decisions | Prevents misleading benchmark claims |
