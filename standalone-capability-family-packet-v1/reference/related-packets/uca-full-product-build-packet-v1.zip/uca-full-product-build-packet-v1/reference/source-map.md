# Canonical Artifact Source Map

**Classification:** Provenance index

| Canonical artifact | Primary conversation source | External research contribution | Authority class |
|---|---|---|---|
| `CHARTER.md` | Product boundary, standalone capability, development philosophy decisions | None required | Normative constitution |
| `spec/invariants.md` | Repeated architectural constraints across UCA and Octon discussions | Security and skill research reinforced several constraints | Normative |
| `ARCHITECTURE.md` | Complete Development Blueprint | Aider context projection; Agent Skills packaging; analyzer ecosystem | Reference architecture |
| `spec/audit-lifecycle.md` | Blueprint plus later candidate-validation decision | Trail of Bits, Cloudflare, SecPriv | Normative |
| `spec/evidence-model.md` | Universal audit framework and product blueprint | SARIF/SBOM/OTel/tool-format research | Normative |
| `spec/confidence-model.md` | Blueprint and skill research | SecPriv cautioned against uncalibrated scalar confidence | Normative |
| `spec/completion-semantics.md` | UCA blueprint and completion-truth discussion | Superpowers verification; Addy floor-guard state distinction | Normative |
| `spec/finding-model.md` | Universal audit and blueprint | Common Code Reviewer stable IDs; Cloudflare validation | Normative |
| `spec/reduction-model.md` | Universal audit plus Ponytail inquiry | Ponytail, Addy simplification | Normative |
| `spec/safety-floor.md` | Ponytail-derived adaptation and UCA safety architecture | Ponytail, Addy constraint floor | Normative |
| `spec/bundle-format.md` | Complete Development Blueprint | SARIF, CycloneDX, SPDX, OpenTelemetry concepts | Normative |
| `spec/adapter-protocol.md` | Complete Development Blueprint | CodeQL, Semgrep, OSV, Syft and related tool interfaces | Normative |
| `spec/graph-intelligence.md` | Universal audit and blueprint | Aider repository map | Normative/reference mix as labeled |
| `spec/ai-semantic-analysis.md` | Complete Development Blueprint and skill research | Agent-skill prompt-injection and validation lessons | Normative |
| `spec/cli-contract.md` | Complete Development Blueprint | None material | Normative |
| `spec/ci-contract.md` | Complete Development Blueprint | GitHub SARIF integration research | Normative |
| `spec/mcp-contract.md` | Complete Development Blueprint | Current MCP architecture considerations | Normative |
| `spec/capability-matrix.*` | Universal audit taxonomy plus product blueprint | Tool and skill research | Machine-readable normative |
| `skills/uca-audit` | Agent-skill architecture decision | Agent Skills spec, Superpowers, Trail of Bits, Addy | Agent interface contract |
| `skills/uca-simplify` | Reduction-lens decision | Ponytail and Addy | Agent interface contract |
| `evals/*` | Evaluation honesty and release-proof decisions | Ponytail, SecPriv, Superpowers, Addy, Trail of Bits | Normative verification |
| `integrations/octon-mini.md` | UCA/Octon external-provider discussion | Current Octon repository verification | Normative boundary/proposed integration |
| `docs/standalone-capability-pattern.md` | UCA as reference project for future capabilities | None required | Reference architecture |
| `agent/*` | Full Product Build Packet directive and full-product development philosophy | Agent-skill workflow lessons | Governance |
| `design/decision-ledger.md` | Consolidated visible conversation decisions | Current source verification | Governance |
| `reference/conversation-thread.md` | Visible project conversation | None | Historical |
