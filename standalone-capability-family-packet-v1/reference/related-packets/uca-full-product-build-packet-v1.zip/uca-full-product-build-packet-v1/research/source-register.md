# Research Source Register

**Classification:** Historical/current research provenance; non-normative except where a decision ledger explicitly adopts a mechanism.  
**Current verification date:** 2026-08-31

## Verification method

Each repository below was verified against its public primary GitHub repository and current default branch during packet generation. Commit hashes record the verification point. External repositories may change after this date; UCA decisions are independently specified in this packet and do not float with upstream behavior.

| ID | Source | Verified revision | License | UCA research use |
|---|---|---|---|---|
| `SRC-001` | Ponytail | `2ed6c52c9d7e5e56942508591085fd45dea277d3` | MIT | Reduction ladder, safety floor, concise reduction labels, debt ceilings/revisit triggers, portability and benchmark-honesty lessons. |
| `SRC-002` | Trail of Bits Skills | `d1f1575cff97816e5cc08af66cd2506099c681d3` | CC BY-SA 4.0 | Context before verdicts, exact source references, false-positive checking, differential review, root-cause-guided variant analysis, eval caveats. |
| `SRC-003` | Cloudflare Security Audit Skill | `8bac42001ddd90a4dcd8d5a5045199283a8eba75` | MIT | Reconnaissance → hunting → validation → reporting → independent verification and rejected-result discipline. |
| `SRC-004` | Meta SecPriv Skill | `f2c37778bd85ea9d0e5c510d4d741c3c2b766b27` | MIT | Detector/validator decomposition, near-miss negatives, ablation, cached rescoring, limits on static claims. |
| `SRC-005` | Aider | `5dc9490bb35f9729ef2c95d00a19ccd30c26339c` | Apache-2.0 | Token-bounded graph-ranked repository map with deterministic context selection, caching, and explicit relevance. |
| `SRC-006` | Superpowers | `b36e0829c6d0140e93cfef2ca599b1b07d4a7797` | MIT | Evidence-before-completion and skill TDD with controls, pressure cases, repeated runs, and rationalization-resistant instructions. |
| `SRC-007` | Common Code Reviewer | `435dbd6d1620411750816924ee0f3463920fa312` | Apache-2.0 | Stable rule IDs, canonical language registry, generated tables, deterministic fixtures, and live conformance. |
| `SRC-008` | Agent Skills specification | `69ef37e9424c0a7ea9dd2293b559e43ec8176379` | Apache-2.0 | Portable SKILL.md package, progressive disclosure, compatibility/license metadata, references/scripts/assets, validation. |
| `SRC-009` | Addy Osmani Agent Skills | `d2c37ef6225dd8726cdd369a8030307f48592d26` | MIT | Behavior-preserving simplification, safety-floor guard concepts, three-tier skill evals, trigger collision tests, host portability experience. |
| `SRC-010` | Anthropic Skills examples | `3b3fad96af16a10759d930941b4520ba0c40edae` | Mixed; inspect per skill | Production-oriented skill examples and explicit warning to test skills in the target environment. Agent Skills spec source is tracked separately. |
| `SRC-011` | Octon Mini | `5e2d3025aea6b1574ab984e5ebb89b5602a38535` | Repository license controls reuse | Current consumer/development-orchestrator context; UCA integration remains external and non-dependent. |

## Pinned source links

- **SRC-001 — Ponytail:** https://github.com/DietrichGebert/ponytail/tree/2ed6c52c9d7e5e56942508591085fd45dea277d3
- **SRC-002 — Trail of Bits Skills:** https://github.com/trailofbits/skills/tree/d1f1575cff97816e5cc08af66cd2506099c681d3
- **SRC-003 — Cloudflare Security Audit Skill:** https://github.com/cloudflare/security-audit-skill/tree/8bac42001ddd90a4dcd8d5a5045199283a8eba75
- **SRC-004 — Meta SecPriv Skill:** https://github.com/facebookresearch/secpriv-skill/tree/f2c37778bd85ea9d0e5c510d4d741c3c2b766b27
- **SRC-005 — Aider:** https://github.com/Aider-AI/aider/tree/5dc9490bb35f9729ef2c95d00a19ccd30c26339c
- **SRC-006 — Superpowers:** https://github.com/obra/superpowers/tree/b36e0829c6d0140e93cfef2ca599b1b07d4a7797
- **SRC-007 — Common Code Reviewer:** https://github.com/William-Yeh/common-code-reviewer/tree/435dbd6d1620411750816924ee0f3463920fa312
- **SRC-008 — Agent Skills specification:** https://github.com/agentskills/agentskills/tree/69ef37e9424c0a7ea9dd2293b559e43ec8176379
- **SRC-009 — Addy Osmani Agent Skills:** https://github.com/addyosmani/agent-skills/tree/d2c37ef6225dd8726cdd369a8030307f48592d26
- **SRC-010 — Anthropic Skills examples:** https://github.com/anthropics/skills/tree/3b3fad96af16a10759d930941b4520ba0c40edae
- **SRC-011 — Octon Mini:** https://github.com/cooperonlineenterprises/octon-mini/tree/5e2d3025aea6b1574ab984e5ebb89b5602a38535

## Historical basis versus current verification

The visible UCA conversation analyzed these projects before or during packet generation. Current verification confirmed that the repositories remain public and identified their default-branch revisions and licenses as shown above. A source's later changes do not silently amend UCA. Any new mechanism must be evaluated through the decision process.

Notable current observations:

- Ponytail continues to expand host portability, reinforcing the need for generated thin adapters rather than semantic copies. UCA rejects Ponytail's always-on mode despite borrowing reduction and evaluation ideas.
- Trail of Bits continues adding explicit routing evaluations and documents what a green score does not establish, reinforcing UCA's no-skill controls and evaluation honesty.
- Common Code Reviewer continues using stable rule IDs and conformance fixtures, supporting UCA taxonomy proof.
- The Agent Skills specification continues to support progressive disclosure and validation, supporting the canonical UCA skill package.

## Use limits

This packet records mechanisms and independent UCA adaptations. It does not vendor external source, prompts, benchmark corpora, or license text. Exact text or code reuse requires a separate source-level license and attribution review.
