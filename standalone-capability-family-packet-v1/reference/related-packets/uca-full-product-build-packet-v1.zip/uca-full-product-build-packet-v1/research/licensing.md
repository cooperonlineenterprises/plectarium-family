# Research Licensing and Intellectual-Property Boundary

**Classification:** Governance/reference  
**Status:** `ACCEPTED`

## Principle

UCA independently implements adopted mechanisms. General ideas, workflows, and architectural patterns may inspire UCA without copying expressive source text or code. Direct reuse of code, skill prose, tests, benchmarks, configuration, assets, or generated packages requires an explicit license review and attribution plan.

## Verified licenses

| Source | Verified license | Practical UCA rule |
|---|---|---|
| Ponytail | MIT | Concepts may be independently implemented. Preserve notice for substantial copied code/text; default is no direct copy. |
| Cloudflare security-audit-skill | MIT | Same: independent implementation preferred. |
| Meta SecPriv | MIT | Benchmark ideas may be adapted; do not copy corpus/runners without notice and review. |
| Superpowers | MIT | Skill-evaluation concepts may be adapted; do not copy prose wholesale. |
| Addy Osmani agent-skills | MIT | Portability/eval patterns may be adapted; direct scripts require notice. |
| Aider | Apache-2.0 | Independent graph-context implementation preferred; direct reuse requires Apache notice/patent compliance. |
| Common Code Reviewer | Apache-2.0 | Stable-ID/fixture concepts may be adapted; direct reuse requires Apache compliance. |
| Agent Skills specification | Apache-2.0 | UCA may implement the public specification; preserve required notices if vendoring validator code. |
| Trail of Bits Skills | CC BY-SA 4.0 | Avoid close textual adaptation or copied assets unless attribution and ShareAlike consequences are intentionally accepted. Implement mechanisms independently. |
| Anthropic Skills | Mixed by subdirectory | Inspect each skill's license; repository-level assumptions are insufficient. |
| Octon Mini | Project repository license | Integration docs may reference public contracts; copying implementation requires its license review. |

## Artifact classes requiring review

```text
general idea or principle              normally independently implementable
workflow/interaction mechanism         independently restate and implement
interface/protocol pattern              independently design; standards may govern
source code                             license and notice required
distinctive skill text                  copyright/license review required
benchmark/test corpus                   license, data rights, and attribution review
configuration/rules/queries             may be copyrighted/licensed; inspect source
logos/trademarks                        separate trademark permission
```

## Contribution rule

Every contribution derived from an external source must record:

- source repository and immutable revision;
- file or asset;
- license;
- whether copied, modified, translated, or independently implemented;
- required notices;
- compatibility with UCA's eventual project license;
- reviewer approval.

## UCA project license

The final UCA project license remains `OPEN-QUESTION-001`. Until resolved, contributors should avoid incorporating source whose obligations could constrain the intended distribution model.
