# Detailed Decision Ledger

**Authority:** Governance / accepted product decisions

## DEC-001 — Standalone harness-agnostic product

**Status:** `ESTABLISHED`

**Decision**

UCA is an independently usable product and has no Octon Mini or agent-harness runtime dependency.

**Rationale**

Portability, local-first use, and reusable capability boundaries require independent operation.

**Alternatives considered**

- Embed auditing in Octon Mini
- Make an agent skill the product

**Consequences**

- UCA needs its own engine, CLI, contracts, releases, and storage.

**Affected specifications**

- `CHARTER.md`
- `spec/invariants.md`
- `integrations/octon-mini.md`

**Source / provenance**

Latest explicit user/assistant architectural decision.

## DEC-002 — Evidence and recommendations are non-authorizing

**Status:** `ESTABLISHED`

**Decision**

UCA findings never authorize repository or project actions.

**Rationale**

Audit truth and project authority are different lifecycles.

**Alternatives considered**

- Allow critical findings to auto-fix
- Let UCA create tasks/issues

**Consequences**

- Consumers must use separate governance for remediation.

**Affected specifications**

- `CHARTER.md`
- `spec/invariants.md`
- `spec/finding-model.md`

**Source / provenance**

Established throughout UCA/Octon discussion.

## DEC-003 — One authoritative engine

**Status:** `ESTABLISHED`

**Decision**

CLI, CI, MCP, OCI, and future HTTP use one engine semantics.

**Rationale**

Prevents divergent product meanings and duplicate implementations.

**Alternatives considered**

- Independent interface implementations

**Consequences**

- All interfaces become thin application/protocol surfaces.

**Affected specifications**

- `ARCHITECTURE.md`
- `spec/invariants.md`

**Source / provenance**

Full blueprint decision.

## DEC-004 — Canonical local CLI

**Status:** `ACCEPTED`

**Decision**

The CLI is the canonical human and automation interface.

**Rationale**

Local-first use, scripting, CI, containers, and harness invocation all benefit from one stable process contract.

**Alternatives considered**

- MCP-first
- HTTP-first
- library-only

**Consequences**

- CLI contract and exit semantics are public compatibility commitments.

**Affected specifications**

- `spec/cli-contract.md`

**Source / provenance**

Full blueprint decision.

## DEC-005 — Audit Bundle as durable canonical result

**Status:** `ESTABLISHED`

**Decision**

The content-addressed UCA Audit Bundle is the canonical audit result; reports and SARIF are projections.

**Rationale**

Durable evidence, provenance, comparison, and portability require more than conversational output.

**Alternatives considered**

- SARIF-only
- database-only
- chat report

**Consequences**

- Bundle schemas, verification, migration, and storage are foundational.

**Affected specifications**

- `spec/bundle-format.md`

**Source / provenance**

Full blueprint decision.

## DEC-006 — Read-only repository default

**Status:** `ESTABLISHED`

**Decision**

UCA does not mutate the target repository or Git state by default.

**Rationale**

Auditing must not alter its subject and must remain safe for unfamiliar repositories.

**Alternatives considered**

- In-place analyzer execution
- Auto-cleanup/refactoring

**Consequences**

- Build/test work requires copied or read-only/sandbox boundaries.

**Affected specifications**

- `spec/invariants.md`
- `spec/execution-security.md`

**Source / provenance**

Established architecture.

## DEC-007 — No hidden tool installation

**Status:** `ESTABLISHED`

**Decision**

UCA diagnoses but never silently installs or updates analyzers or dependencies.

**Rationale**

Supply-chain trust and reproducibility require explicit operator ownership.

**Alternatives considered**

- Automatic package-manager setup

**Consequences**

- OCI toolboxes and documented setup provide convenience without hidden effects.

**Affected specifications**

- `spec/adapter-protocol.md`
- `spec/invariants.md`

**Source / provenance**

Established architecture.

## DEC-008 — Explicit execution and network rights

**Status:** `ESTABLISHED`

**Decision**

Project execution, network, credentials, processes, and writable paths are declared in the plan and bounded by policy.

**Rationale**

Security and consent require inspectable effects.

**Alternatives considered**

- Implicit permission based on tier

**Consequences**

- Audit planning becomes an effect declaration.

**Affected specifications**

- `spec/execution-security.md`
- `spec/audit-lifecycle.md`

**Source / provenance**

Established architecture.

## DEC-009 — Truthful completion semantics

**Status:** `ESTABLISHED`

**Decision**

Unavailable, denied, timed-out, stale, unsupported, or incomplete analysis never appears complete/passed.

**Rationale**

Developer trust depends on distinguishing absence of evidence from evidence of absence.

**Alternatives considered**

- Treat missing optional checks as pass
- Findings count as completion

**Consequences**

- Completion is independent of findings.

**Affected specifications**

- `spec/completion-semantics.md`

**Source / provenance**

Established architecture and skill research.

## DEC-010 — Evidence-class separation

**Status:** `ESTABLISHED`

**Decision**

Deterministic, heuristic, historical, runtime, human, AI, fusion, and unavailability evidence remain distinct.

**Rationale**

Each class supports different claims and reproducibility.

**Alternatives considered**

- Normalize all output into one generic confidence score

**Consequences**

- Schemas and reports preserve producer and class.

**Affected specifications**

- `spec/evidence-model.md`
- `spec/confidence-model.md`

**Source / provenance**

Established architecture.

## DEC-011 — AI is optional evidence

**Status:** `ESTABLISHED`

**Decision**

AI is an optional structured interpretation source, not the canonical engine, executor, or authority.

**Rationale**

UCA must work offline and preserve evidence integrity.

**Alternatives considered**

- AI-first auditor
- Model-generated final verdicts

**Consequences**

- AI-only findings are advisory and validated like other candidates.

**Affected specifications**

- `spec/ai-semantic-analysis.md`
- `spec/invariants.md`

**Source / provenance**

Established architecture.

## DEC-012 — Integrate mature specialist analyzers

**Status:** `ACCEPTED`

**Decision**

UCA owns orchestration and evidence fusion and integrates mature tools rather than recreating deep specialist engines.

**Rationale**

Capability-to-weight and quality are higher when proven tools remain independently owned.

**Alternatives considered**

- Build a mega-analyzer

**Consequences**

- Adapter protocol and normalization become core differentiators.

**Affected specifications**

- `spec/adapter-protocol.md`
- `spec/capability-matrix.yaml`

**Source / provenance**

Universal audit research conclusion.

## DEC-013 — Candidate before finding

**Status:** `ESTABLISHED`

**Decision**

Heuristic and AI suspicions enter a candidate lifecycle and cannot bypass validation/refutation.

**Rationale**

False-positive control and honest inference require separation.

**Alternatives considered**

- Direct model/tool output to findings

**Consequences**

- Candidate and validation schemas are foundational.

**Affected specifications**

- `spec/candidate-validation.md`
- `spec/audit-lifecycle.md`

**Source / provenance**

Agent-skill research and UCA blueprint.

## DEC-014 — Preserve rejected candidates

**Status:** `ACCEPTED`

**Decision**

Rejected candidates and rejection evidence are stored in the Audit Bundle.

**Rationale**

They support detector evaluation, recurring-noise suppression, and explainability.

**Alternatives considered**

- Discard rejected candidates

**Consequences**

- Bundle grows modestly; retention may be configurable.

**Affected specifications**

- `spec/candidate-validation.md`
- `spec/bundle-format.md`

**Source / provenance**

Cloudflare/SecPriv-inspired UCA adaptation.

## DEC-015 — Stable semantic finding identity

**Status:** `ESTABLISHED`

**Decision**

Finding fingerprints use taxonomy/entity/rule/context/evidence signatures rather than line/message/time.

**Rationale**

Comparison, ratchets, and lifecycle require resilient identity.

**Alternatives considered**

- Line-based identity only

**Consequences**

- Language packs must provide stable entity identity where possible.

**Affected specifications**

- `spec/finding-model.md`

**Source / provenance**

Established blueprint.

## DEC-016 — Vector confidence model

**Status:** `ESTABLISHED`

**Decision**

Confidence remains a transparent vector, not an invented universal probability.

**Rationale**

Coverage, freshness, reproducibility, conflicts, and inference distance must remain visible.

**Alternatives considered**

- Single confidence number

**Consequences**

- Priority may derive a versioned weight but cannot hide components.

**Affected specifications**

- `spec/confidence-model.md`

**Source / provenance**

Established blueprint.

## DEC-017 — Transparent priority, no health score

**Status:** `ACCEPTED`

**Decision**

Priority uses visible benefit/confidence/burden inputs and bands; UCA has no default single health score.

**Rationale**

Opaque scores are gameable and conceal critical dimensions.

**Alternatives considered**

- Global maintainability score

**Consequences**

- Calibration remains empirical and versioned.

**Affected specifications**

- `spec/prioritization.md`

**Source / provenance**

Universal audit research conclusion.

## DEC-018 — First-class Reduction lens

**Status:** `ACCEPTED`

**Decision**

UCA has an explicit Reduction/Simplification lens over shared evidence.

**Rationale**

Deletion, reuse, state/configuration reduction, and de-abstraction are high-leverage and were underemphasized.

**Alternatives considered**

- Scattered simplification rules only
- Separate simplifier product

**Consequences**

- Reduction taxonomy, benefit vector, and reports are required.

**Affected specifications**

- `spec/reduction-model.md`

**Source / provenance**

Ponytail research adaptation.

## DEC-019 — Non-reducible safety floor

**Status:** `ESTABLISHED`

**Decision**

Every material reduction candidate evaluates applicable behavior, correctness, integrity, security, privacy, accessibility, reliability, compatibility, observability, performance, legal, and operational floors.

**Rationale**

Simpler must not mean negligent.

**Alternatives considered**

- Trust tests alone
- LOC-first simplification

**Consequences**

- Unknown high-impact floors produce investigation; violations reject reduction.

**Affected specifications**

- `spec/safety-floor.md`

**Source / provenance**

Ponytail/Addy research adaptation.

## DEC-020 — Reconsideration triggers

**Status:** `ACCEPTED`

**Decision**

Accepted debt and retained complexity support explicit ceilings, triggers, successor action, and expiry.

**Rationale**

Decisions justified today may become unjustified later.

**Alternatives considered**

- Permanent waivers

**Consequences**

- Periodic audits evaluate triggers and reopen findings.

**Affected specifications**

- `spec/reconsideration-trigger schema`
- `spec/reduction-model.md`

**Source / provenance**

Ponytail debt pattern adaptation.

## DEC-021 — Three audit tiers

**Status:** `ESTABLISHED`

**Decision**

Continuous, Periodic, and Investigative tiers define bounded defaults; escalation is recommendation only.

**Rationale**

Different evidence costs and contexts require executable modes without permission escalation.

**Alternatives considered**

- One all-purpose audit

**Consequences**

- Tier-specific budgets and completeness language are required.

**Affected specifications**

- `spec/audit-tiers.md`

**Source / provenance**

Universal audit methodology.

## DEC-022 — Focused lenses share one evidence model

**Status:** `ACCEPTED`

**Decision**

Architecture, security, performance, testing, reduction, and other lenses change planning/reporting but not engine truth.

**Rationale**

Focus improves precision while shared evidence prevents fragmentation.

**Alternatives considered**

- Separate independent skill/engine per lens

**Consequences**

- Every lens discloses omitted areas and cross-checks.

**Affected specifications**

- `spec/audit-tiers.md`

**Source / provenance**

Agent-skill research adaptation.

## DEC-023 — Language maturity strategy

**Status:** `ACCEPTED`

**Decision**

Rust and Python target deep v1 support; TypeScript/JavaScript and Go target useful v1 support; generic fallback remains useful.

**Rationale**

This spans static/dynamic languages while avoiding false equal-depth claims.

**Alternatives considered**

- Many shallow languages first
- One-language product

**Consequences**

- Capability matrix defines per-language depth.

**Affected specifications**

- `spec/language-packs.md`
- `spec/capability-matrix.yaml`

**Source / provenance**

Full blueprint decision.

## DEC-024 — Out-of-process/OCI adapter boundary

**Status:** `ESTABLISHED`

**Decision**

External adapters run as explicit processes or OCI artifacts, not arbitrary in-process dynamic plugins.

**Rationale**

Isolation, language neutrality, and engine stability outweigh in-process convenience.

**Alternatives considered**

- Shared-library plugin ABI

**Consequences**

- Adapter protocol, digest, limits, and conformance suite required.

**Affected specifications**

- `spec/adapter-protocol.md`

**Source / provenance**

Full blueprint decision.

## DEC-025 — OCI high-assurance distribution

**Status:** `ACCEPTED`

**Decision**

UCA ships hardened minimal/toolbox OCI images; OCI is preferred/required by policy, not universally mandatory.

**Rationale**

Containers improve reproducibility and isolation but are not available/appropriate for every local profiler/platform.

**Alternatives considered**

- OCI always mandatory
- Native only

**Consequences**

- Provider manifest can require OCI; native remains supported under policy.

**Affected specifications**

- `ARCHITECTURE.md`
- `spec/execution-security.md`

**Source / provenance**

Full blueprint decision.

## DEC-026 — MCP as thin interface

**Status:** `ESTABLISHED`

**Decision**

MCP exposes typed UCA operations/resources over the engine and no generic shell/write authority.

**Rationale**

Agent-native use must not become a second engine/control plane.

**Alternatives considered**

- Prompt-only MCP audit
- MCP-only product

**Consequences**

- CLI/MCP semantic equivalence is a release gate.

**Affected specifications**

- `spec/mcp-contract.md`

**Source / provenance**

Full blueprint decision.

## DEC-027 — CI as thin invocation/presentation layer

**Status:** `ESTABLISHED`

**Decision**

CI owns checkout/permissions/infrastructure; UCA owns audit semantics and gates.

**Rationale**

Prevents platform-specific reinterpretation.

**Alternatives considered**

- CI Action implements findings

**Consequences**

- Fork safety and artifact sensitivity are explicit.

**Affected specifications**

- `spec/ci-contract.md`

**Source / provenance**

Full blueprint decision.

## DEC-028 — Two canonical Agent Skills initially

**Status:** `ACCEPTED`

**Decision**

Ship `uca-audit` and `uca-simplify`; keep review/investigate/explain/compare as modes unless routing evidence justifies more skills.

**Rationale**

Fewer concepts reduce routing collision; simplification has a genuinely distinct workflow.

**Alternatives considered**

- Six specialized UCA skills
- One overloaded skill only

**Consequences**

- Skills remain thin and progressively disclosed.

**Affected specifications**

- `skills/uca-audit`
- `skills/uca-simplify`

**Source / provenance**

Agent-skill research decision.

## DEC-029 — Generated platform adapters

**Status:** `ACCEPTED`

**Decision**

One canonical Agent Skills source generates thin host-specific packages with drift/conformance tests.

**Rationale**

Hand-maintained copies diverge.

**Alternatives considered**

- Independent skill copies per platform

**Consequences**

- Generators may adapt metadata/paths, not semantics.

**Affected specifications**

- `agent/BUILD-DIRECTIVE.md`
- `skills/`

**Source / provenance**

Agent-skill research decision.

## DEC-030 — Octon Mini external evidence-provider boundary

**Status:** `ESTABLISHED`

**Decision**

Octon consumes UCA through a narrow read-only evidence-provider workflow and durable bundle reference.

**Rationale**

Octon governs trust and downstream work without absorbing UCA.

**Alternatives considered**

- Embed UCA in Octon
- Universal action plugin now

**Consequences**

- Provider class remains narrow and non-authorizing.

**Affected specifications**

- `integrations/octon-mini.md`

**Source / provenance**

Explicit user decision.

## DEC-031 — Use Octon Mini to help build UCA

**Status:** `ACCEPTED`

**Decision**

Octon Mini may govern UCA development tasks/decisions/evidence while UCA repository remains independent.

**Rationale**

Dogfooding stresses Octon on a real standalone capability.

**Alternatives considered**

- Do not use Octon
- Make UCA an Octon package

**Consequences**

- Removing Octon must not affect UCA build/use.

**Affected specifications**

- `agent/BUILD-DIRECTIVE.md`
- `integrations/octon-mini.md`

**Source / provenance**

Explicit user/assistant decision.

## DEC-032 — UCA as standalone-capability proving ground

**Status:** `ACCEPTED`

**Decision**

UCA should validate reusable outer conventions for future standalone capabilities.

**Rationale**

UCA exercises planning, permissions, artifacts, skills, CI, MCP, OCI, and harness consumption.

**Alternatives considered**

- Treat UCA as one-off tool

**Consequences**

- Generic patterns are documented but not prematurely productized.

**Affected specifications**

- `docs/standalone-capability-pattern.md`

**Source / provenance**

Explicit user decision.

## DEC-033 — Do not prebuild universal capability framework

**Status:** `ESTABLISHED`

**Decision**

Generalize only after UCA and a second real capability demonstrate stable common needs.

**Rationale**

Speculative framework abstractions risk over-engineering.

**Alternatives considered**

- Build universal capability SDK first

**Consequences**

- UCA may define only conventions it presently needs.

**Affected specifications**

- `docs/standalone-capability-pattern.md`

**Source / provenance**

Explicit user/assistant decision.

## DEC-034 — Build full product in dependency order

**Status:** `ESTABLISHED`

**Decision**

Target a comprehensive production-shaped v1; Minimum Complete Architecture is an integration checkpoint, not product ambition.

**Rationale**

AI lowers breadth cost, while contracts/security still require sequencing.

**Alternatives considered**

- Tiny conventional MVP
- Big-bang simultaneous build

**Consequences**

- Foundations freeze before parallel capability breadth.

**Affected specifications**

- `ROADMAP.md`
- `agent/implementation-dependency-graph.md`

**Source / provenance**

Latest explicit user decision superseding tiny-MVP framing.

## DEC-035 — Rust 2024 engine direction

**Status:** `ACCEPTED`

**Decision**

Use a Rust 2024 workspace for the authoritative engine, CLI, schemas/types, execution, bundle, and interfaces unless an ADR proves a better choice.

**Rationale**

Portable native binaries, memory safety, performance, and strong contracts suit a developer tool.

**Alternatives considered**

- Go
- Python
- TypeScript

**Consequences**

- Internal crate boundaries remain implementation-flexible.

**Affected specifications**

- `ARCHITECTURE.md`
- `agent/BUILD-DIRECTIVE.md`

**Source / provenance**

Full blueprint recommendation accepted as current direction.

**Reconsideration trigger**

Evidence that Rust materially blocks language/tool integration or portability.

## DEC-036 — Graph-guided context projection

**Status:** `ACCEPTED`

**Decision**

Provide deterministic budgeted evidence-graph context projections for agents/semantic providers.

**Rationale**

Reduces indiscriminate repository loading and preserves inclusion rationale.

**Alternatives considered**

- Entire-repository prompt
- Chat-specific map only

**Consequences**

- Projection remains a view with omission limits.

**Affected specifications**

- `spec/graph-intelligence.md`

**Source / provenance**

Aider/Trail of Bits research adaptation.

## DEC-037 — No-skill controlled Agent Skill evaluation

**Status:** `ESTABLISHED`

**Decision**

Agent Skills require structural, routing, and behavioral tests with no-skill controls and pressure cases.

**Rationale**

Skill existence does not prove behavioral value.

**Alternatives considered**

- Example prompts only

**Consequences**

- Skill releases carry exact digest/model/harness evaluation evidence.

**Affected specifications**

- `evals/EVALUATION-SPEC.md`

**Source / provenance**

Ponytail/Superpowers/Addy/SecPriv research conclusion.

## DEC-038 — Separate artifact reduction from process overhead

**Status:** `ACCEPTED`

**Decision**

Evaluation reports code/concept reduction separately from turns, tokens, tool calls, latency, and human review burden.

**Rationale**

Fewer lines can require more agent effort; claims must match measurements.

**Alternatives considered**

- One efficiency number

**Consequences**

- Benchmark reports preserve matched-arm context.

**Affected specifications**

- `evals/EVALUATION-SPEC.md`

**Source / provenance**

Benchmark-honesty research conclusion.

## DEC-039 — Hosted service

**Status:** `DEFERRED`

**Decision**

Design local abstractions that permit a future hosted service, but do not require or build it before local product maturity.

**Rationale**

Local-first product value and contracts must be proven first.

**Alternatives considered**

- Service-first architecture

**Consequences**

- Queue/object-store/tenant implementations are later.

**Affected specifications**

- `ARCHITECTURE.md`
- `ROADMAP.md`

**Source / provenance**

Full blueprint decision.

**Reconsideration trigger**

Stable local v1 with sustained organizational demand.

## DEC-040 — Remote AI verifier in production v1

**Status:** `DEFERRED`

**Decision**

Schemas support remote providers, but production-v1 inclusion awaits privacy/evaluation evidence.

**Rationale**

Provider drift, data handling, and marginal value are unresolved.

**Alternatives considered**

- Require remote AI
- Ban all remote AI permanently

**Consequences**

- Local/offline operation remains complete.

**Affected specifications**

- `spec/ai-semantic-analysis.md`
- `OPEN-QUESTIONS.md`

**Source / provenance**

Research decision.

**Reconsideration trigger**

Evaluation shows material incremental precision and security review passes.

## DEC-041 — Root-cause-guided variant analysis

**Status:** `DEFERRED`

**Decision**

Add exact-to-general variant search in Investigative mode after core findings/adapters are stable.

**Rationale**

High value after known defects, but potential noise and tooling complexity.

**Alternatives considered**

- Broad variant search in v1 core

**Consequences**

- Protocol reserves investigative relationships.

**Affected specifications**

- `ROADMAP.md`
- `agent/research-decisions.md`

**Source / provenance**

Trail of Bits research disposition.

**Reconsideration trigger**

Production v1 foundation and known-root-cause corpus.

## DEC-042 — Additional UCA Agent Skills

**Status:** `DEFERRED`

**Decision**

Do not add `uca-review`, `uca-investigate`, `uca-explain`, or `uca-compare` unless routing/behavioral evaluation demonstrates benefit.

**Rationale**

Skill proliferation increases collision and maintenance.

**Alternatives considered**

- Create full skill family now

**Consequences**

- Modes remain discoverable through uca-audit.

**Affected specifications**

- `skills/`
- `evals/EVALUATION-SPEC.md`

**Source / provenance**

Agent-skill research decision.

**Reconsideration trigger**

Measured trigger/routing failures not fixable through canonical skill wording.

## DEC-043 — Always-on persistent audit mode

**Status:** `REJECTED`

**Decision**

UCA will not inject audit behavior into every coding turn.

**Rationale**

Hidden persistent behavior conflicts with explicit, bounded auditing.

**Alternatives considered**

- Ponytail-like activation modes

**Consequences**

- Invocation is explicit through skill, CLI, MCP, CI, or harness.

**Affected specifications**

- `spec/invariants.md`

**Source / provenance**

Agent-skill research rejection.

## DEC-044 — Prompt-only UCA

**Status:** `REJECTED`

**Decision**

A prompt or skill cannot substitute for the engine and Audit Bundle.

**Rationale**

It cannot provide exact identity, execution, evidence normalization, stable findings, or reproducibility.

**Alternatives considered**

- Make SKILL.md the implementation

**Consequences**

- Skills orchestrate only.

**Affected specifications**

- `spec/invariants.md`
- `skills/`

**Source / provenance**

Established boundary.

## DEC-045 — Automatic remediation

**Status:** `REJECTED`

**Decision**

Initial UCA does not edit, refactor, commit, issue, publish, or deploy.

**Rationale**

Recommendations and authority are separate.

**Alternatives considered**

- Auto-fix findings

**Consequences**

- Future remediation would be a separate governed capability.

**Affected specifications**

- `CHARTER.md`
- `spec/invariants.md`

**Source / provenance**

Established boundary.

## DEC-046 — Mandatory multi-agent topology

**Status:** `REJECTED`

**Decision**

UCA semantics do not require specialist subagents; independent verification is a capability, not an agent topology.

**Rationale**

Avoid becoming an agent framework and unnecessary cost.

**Alternatives considered**

- One subagent per lens

**Consequences**

- Agents may parallelize implementation or optional review externally.

**Affected specifications**

- `agent/BUILD-DIRECTIVE.md`

**Source / provenance**

Agent-skill research rejection.

## DEC-047 — Raw LOC as simplification objective

**Status:** `REJECTED`

**Decision**

LOC is one descriptive observation, never the governing Reduction objective.

**Rationale**

Smaller code can be less clear or less safe.

**Alternatives considered**

- Maximize deleted lines

**Consequences**

- Benefit vector includes concepts, state, dependencies, surfaces, and operations.

**Affected specifications**

- `spec/reduction-model.md`

**Source / provenance**

Research conclusion.

## DEC-048 — Single aggregate code-health score

**Status:** `REJECTED`

**Decision**

UCA does not default to one opaque repository health score.

**Rationale**

Critical risk can be hidden by unrelated positive dimensions and scores are gameable.

**Alternatives considered**

- Maintainability index as product score

**Consequences**

- Dimension/finding evidence remains inspectable.

**Affected specifications**

- `CHARTER.md`
- `spec/prioritization.md`

**Source / provenance**

Universal audit research conclusion.

## DEC-049 — Tiny MVP as product target

**Status:** `SUPERSEDED`

**Decision**

The earlier smallest non-throwaway kernel is retained only as the Minimum Complete Architecture integration checkpoint.

**Rationale**

The user explicitly chose a production-shaped full product enabled by AI, built in dependency order.

**Alternatives considered**

- Stop after minimal kernel

**Consequences**

- Roadmap continues aggressively after checkpoint.

**Affected specifications**

- `ROADMAP.md`

**Source / provenance**

Latest explicit user decision supersedes earlier framing.
