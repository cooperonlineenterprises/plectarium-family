# Mature UCA v1 Definition of Done

**Authority:** Normative release gate  
**Status:** `ESTABLISHED`

UCA v1 is finished only when the promised product is coherent, verifiable, secure by default, independently usable, and honest about limitations. A high feature count does not satisfy this definition.

## 1. Product boundary

- UCA runs without Octon Mini or another harness.
- UCA runs without MCP, AI, hosted services, or network access.
- UCA has no autonomous remediation, deployment, issue-creation, or repository-authority path.
- All public interfaces use one authoritative engine semantics.

## 2. Foundational contracts

- Current schemas parse and pass meta-schema validation.
- Request, repository identity, scope, plan, execution, evidence, candidate, validation, finding, confidence, completion, bundle, waiver, comparison, provenance, and adapter semantics are documented and tested.
- Breaking schema changes have migration and compatibility rules.
- Stable taxonomy IDs and finding fingerprints have conformance fixtures.

## 3. Functional capability

- Exact repository identity and dirty state are reported.
- Continuous, Periodic, and Investigative tiers are implemented.
- Repository history, graph, duplication, hotspot, ownership, and comparison capabilities meet the v1 depths in the capability matrix.
- Reduction/Simplification and safety-floor evaluation meet the v1 depth.
- Candidate validation and rejected-candidate preservation are operational.
- Required language depths are met: deep Rust and Python; useful TypeScript/JavaScript and Go.
- The selected stable adapters meet their contract and compatibility matrices.

## 4. Audit Bundle

- Bundles are complete, inspectable, portable, and content-addressed.
- Required files and hashes are validated.
- Corruption, truncation, invalid references, and incompatible schemas are detected.
- Raw and normalized evidence remain distinguishable.
- Archive identity is not confused with semantic bundle identity.
- Provenance, limitations, and completion are preserved.

## 5. Completion truth

- No findings cannot be rendered as “clean” without qualifying scope and completion.
- Unavailable, disabled, denied, timed-out, failed, unsupported, stale, and partial analyses remain distinguishable.
- CLI, CI, MCP, reports, and Agent Skills expose material completion limitations.

## 6. Security

- Read-only, network-denied, project-execution-denied defaults are demonstrated.
- Source files, Git index, HEAD, refs, and worktree metadata remain unchanged in read-only tests.
- Hostile path, symlink, archive, Git, analyzer-output, cache, and prompt-injection tests pass.
- OCI images run non-root, drop capabilities, deny network by default, expose only controlled mounts, and do not inherit credentials.
- Fork-PR guidance and examples avoid secrets and trusted-cache writes.

## 7. CLI

- Command and exit semantics are stable and documented.
- JSON and human output are separated from progress and diagnostics.
- Noninteractive execution accepts an exact plan digest.
- Partial results are still recoverable and inspectable.
- `doctor`, `schema`, adapter, and cache diagnostics are usable.

## 8. CI

- Generic CI and first-party GitHub integration are documented and tested.
- Baseline and ratchet behavior is deterministic.
- SARIF output is a projection, not the canonical result.
- Artifact sensitivity and retention are documented.
- Only configured, evidence-qualified findings or required-analysis failures can gate.

## 9. MCP

- MCP operations remain a thin interface to the engine.
- Equivalent CLI and MCP requests produce equivalent semantic results.
- No arbitrary shell, write, install, credential, waiver, issue, or remediation capability is exposed.
- Long-running tasks support progress, result references, and cancellation.

## 10. OCI and supply chain

- Platform binaries and OCI images are immutable and signed.
- Checksums, CycloneDX and SPDX SBOMs, and provenance attestations are published.
- Toolboxes pin analyzer versions or document external-tool requirements.
- Reproducibility status and known deviations are documented.

## 11. Agent Skills

- `uca-audit` and `uca-simplify` comply with the Agent Skills format.
- Structural, trigger/routing, and behavioral evaluations pass the accepted release floors.
- Completion-truth, authority-pressure, missing-tool, and safety-floor cases pass.
- Platform variants are generated or verified from one canonical source.

## 12. Performance and scale

- Tier-specific reference budgets are published and met on the benchmark corpus or deviations are accepted through ADR.
- Cache correctness is established before cache-hit performance is claimed.
- Large repositories, large histories, large graphs, large SARIF/SBOM inputs, and cancellation are tested.
- Sampling, when used, is disclosed and cannot support incompatible blocking conclusions.

## 13. Evaluation

- Golden, adversarial, near-miss, partial-analysis, corrupted-bundle, fingerprint, cross-interface, Reduction, and security test classes exist.
- Top-k finding precision and reviewer burden are measured on real repositories.
- Candidate validation has an ablation or equivalent proof of value.
- Artifact reduction and agent/process overhead are reported separately.
- No external benchmark is presented as UCA’s own result.

## 14. Documentation and operations

- Architecture, concepts, CLI, schemas, adapters, language packs, CI, MCP, OCI, skills, security, troubleshooting, compatibility, release, and Octon integration documentation are complete.
- Known limitations and unsupported claims are explicit.
- Installation, upgrade, rollback, cache recovery, and bundle migration are documented.
- A security disclosure process and supported-version policy exist.

## 15. Final release review

The Architecture/Integration Lead, Security Lead, Evaluation Lead, and Release Owner must each produce a signed or content-addressed review record. Release may proceed only when all mandatory claims in the claim-proof matrix reference passing evidence.
