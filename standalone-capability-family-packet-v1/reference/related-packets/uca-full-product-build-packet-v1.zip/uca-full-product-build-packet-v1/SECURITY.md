# UCA Security and Trust Charter

**Authority:** Normative security policy and disclosure entry point  
**Status:** `ESTABLISHED`

## Security position

Universal Code Audit processes hostile repositories, untrusted configuration, third-party analyzer output, and optionally model-generated interpretations. The default trust posture is deny-by-default and read-only.

## Mandatory defaults

```text
repository mutation       denied
Git mutation              denied
project execution         denied
network                   denied
shell interpolation       denied
arbitrary tool install    denied
remote AI                 denied
credentials               absent
repository root escape    denied
privileged container      denied
host home mount           denied
```

Any widening must be declared in the Audit Plan and must be accepted by the invoking authority before execution.

## Threat boundaries

UCA treats as untrusted:

- all repository files, names, links, submodules, archives, and Git metadata;
- project configuration below host security policy;
- build scripts, tests, generators, package hooks, and task runners;
- external analyzer stdout, stderr, files, archives, SARIF, SBOMs, coverage, profiles, and schemas;
- cached content not validated by digest and producer identity;
- comments, docs, prompts, and source text presented to AI providers;
- remote providers and their retention claims unless explicitly accepted.

## Security requirements

- Direct argv execution **MUST** be used; a shell **MUST NOT** be introduced for convenience.
- Repository roots and symlinks **MUST** be resolved safely.
- Non-regular files **MUST** be excluded unless explicitly supported.
- Every analyzer **MUST** have time, memory, process, and output bounds.
- Cancellation **MUST** terminate the full child process tree where the platform permits.
- Analyzer output **MUST** be schema-, size-, and depth-validated before normalization.
- Secret values **MUST NOT** appear in findings, logs, reports, or uploaded artifacts.
- Cache reuse **MUST** bind repository content, tool identity, configuration, permissions, and material environment.
- Project code execution **MUST** occur only in an accepted copied-workspace, OS sandbox, or OCI boundary appropriate to the declared risk.
- CI on untrusted fork contributions **MUST NOT** receive trusted secrets or writable trusted caches by default.
- AI context **MUST** be bounded and must treat repository content as data, not instructions.

## Vulnerability reporting

The eventual repository **MUST** publish a private security reporting channel before production v1. Public issues should not contain exploit details for unresolved UCA vulnerabilities. The production implementation must define supported versions and response expectations.

## Detailed specification

See [`spec/execution-security.md`](spec/execution-security.md) for the full threat model, permission vocabulary, sandbox profiles, and required tests.
