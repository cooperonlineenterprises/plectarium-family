# Standalone Capability Pattern Proven by UCA

**Authority:** Reference architecture and extraction policy  
**Status:** `ACCEPTED`

## 1. Purpose

Universal Code Audit is the first real project intended to demonstrate that sophisticated capabilities can remain independently versioned and useful while being consumable by humans, CI, agents, and harnesses through narrow contracts.

The reusable outer shape is:

```text
Standalone Capability
│
├── Core Engine
├── Canonical CLI
├── Durable Result Contract
├── Capability Manifest
├── Agent Skill
├── MCP Adapter
├── CI Adapter
├── OCI Packaging
└── Harness Provider Adapter
```

A likely common lifecycle is:

```text
discover capabilities
        ↓
plan
        ↓
execute
        ↓
completion
        ↓
durable result
        ↓
inspect / compare
```

UCA proves this shape through a production-grade repository audit product. It does not create a universal capability runtime.

## 2. What is deliberately generic in UCA

The following concepts are designed with likely reuse in mind because UCA already needs them:

- independently versioned engine and interfaces;
- explicit capability discovery;
- immutable request and reviewed plan;
- declared permissions and effects;
- direct process or OCI execution boundaries;
- truthful completion states;
- content-addressed durable result artifacts;
- provenance and exact producer identity;
- thin Agent Skill, CI, MCP, and harness adapters;
- non-authorizing evidence output;
- cache identity bound to subject, capability, version, config, and permissions.

## 3. What remains UCA-specific

The following MUST NOT be generalized merely to create a framework:

- repository and revision identity semantics;
- audit evidence taxonomy;
- candidate validation and finding model;
- code graphs and language packs;
- Reduction/Simplification lens;
- analyzer adapters;
- code-quality prioritization;
- UCA Audit Bundle content.

## 4. Extraction policy

Use this progression:

```text
Build UCA
   ↓
observe what is truly generic
   ↓
extract provisional capability conventions
   ↓
build capability #2
   ↓
identify what survives both
   ↓
stabilize a broader capability specification
```

A generic convention may be extracted only when:

1. UCA uses it in a real production path.
2. A second independent capability demonstrates the same semantic need.
3. The common contract is smaller than the two domain contracts it replaces.
4. It does not create a second harness or universal action runtime.
5. Its authority and security effects are explicit.
6. It can be versioned independently.

## 5. Anti-patterns

UCA MUST NOT become:

- a plugin marketplace;
- a general workflow engine;
- an agent orchestration platform;
- a universal policy language;
- an installer for arbitrary tools;
- a capability framework whose abstractions precede demonstrated use.

## 6. Evidence expected from UCA

Before extracting a broader specification, UCA should demonstrate:

- one engine serving CLI, CI, MCP, and OCI;
- a harness invoking UCA without embedding it;
- permission declarations that prevent hidden effects;
- durable result consumption by a non-UCA system;
- version and schema compatibility in practice;
- absence of UCA-specific assumptions in the thin provider boundary;
- at least one real operational lesson that changes the provisional convention.
